# Data Processing Agreement (DPA)
**All India Taxes (AIT) · allindiataxes.com**
Version 1.0 · Effective 7 March 2026

---

## Applicability

This DPA automatically applies when:
- You (the Subscriber / Workspace Owner) use AIT to process personal data of your employees, vendors, or clients
- CA firms use AIT to process their clients' personal or business data
- EU, UK, or EEA personal data is processed (GDPR / UK GDPR Article 28)
- Indian personal data is processed (DPDP Act 2023 — Data Intermediary obligations)

This DPA supplements the Terms of Service (Document 02) and prevails over it in respect of data protection matters.

**For executed DPA copies or signed EU/UK SCC schedules:** info@allindiataxes.com with subject `DPA REQUEST`

---

## Parties

| Role | Party |
|---|---|
| **Data Controller / Data Fiduciary / Data Principal's Fiduciary** | The Subscriber (Workspace Owner) |
| **Data Processor / Data Intermediary** | All India Taxes (AIT) |

---

## 1. Definitions

| Term | Meaning |
|---|---|
| **Personal Data** | Any data relating to an identified or identifiable natural person processed under this DPA |
| **Controller** | The Subscriber who determines the purposes and means of processing |
| **Processor** | AIT, which processes Personal Data on behalf of the Controller |
| **Data Intermediary** | AIT's role under DPDP Act 2023, processing data on behalf of the Data Fiduciary |
| **Sub-Processor** | Any third party engaged by AIT to process Personal Data (Annex B) |
| **Data Subject / Data Principal** | The individual whose Personal Data is processed |
| **SCCs** | EU Standard Contractual Clauses — Commission Decision 2021/914 |
| **IDTA** | UK International Data Transfer Agreement (2022) |
| **Processing** | Any operation on Personal Data including collection, storage, use, disclosure, or deletion |

---

## 2. Controller Obligations

The Controller warrants that:

- It has a lawful basis for providing Personal Data to AIT for processing
- It has provided all required notices to Data Subjects and obtained necessary consents
- Its instructions to AIT are lawful and do not require AIT to violate applicable law
- It will notify AIT promptly of any change in applicable law affecting processing obligations
- It is responsible for the accuracy and completeness of data submitted to the Platform

---

## 3. AIT's Obligations as Processor

### 3.1 Processing Instructions
AIT processes Personal Data only on documented instructions from the Controller, unless required by applicable law. AIT will immediately inform the Controller if an instruction would infringe applicable data protection law.

### 3.2 Confidentiality
AIT ensures that all personnel authorised to process Personal Data are bound by confidentiality obligations or under a statutory duty of confidentiality (ISO 27001 A.6.6).

### 3.3 Security Measures
AIT implements and maintains technical and organisational measures including:

- TLS 1.2+ encryption in transit
- AES-256-GCM encryption at rest for sensitive credentials
- Row-level security and per-entity data isolation
- Role-based access controls and least-privilege enforcement
- MFA enforcement capabilities (workspace-level control)
- Comprehensive audit logging (SOC 2 CC7.2; ISO 27001 A.8.15)
- Regular third-party penetration testing
- Incident response procedures tested biannually

Full detail in Document 06 (Security Policy).

### 3.4 Sub-Processors
AIT uses the sub-processors listed in Annex B. AIT will:

- Impose data protection obligations on sub-processors equivalent to those in this DPA
- Remain fully liable to the Controller for sub-processor performance
- Provide 30 days' advance notice of intended changes to the sub-processor list via email and in-Platform notification
- Allow the Controller to object to new sub-processors within 14 days of notification

If the Controller objects and the objection cannot be resolved, the Controller may terminate the affected services without penalty.

### 3.5 Data Subject Rights Assistance
AIT will assist the Controller in responding to Data Subject rights requests through technical means where feasible. The self-serve Data Rights Portal (Settings → Privacy) is available for this purpose. For requests requiring manual action, contact info@allindiataxes.com.

### 3.6 DPIAs and Consultation
AIT will assist the Controller in conducting Data Protection Impact Assessments (DPIAs) where required, providing documentation of processing activities and security measures on reasonable request.

### 3.7 Breach Notification
On becoming aware of a Personal Data Breach affecting Controller data, AIT will:

1. Notify the Controller without undue delay and within 72 hours of becoming aware
2. Provide: nature of the breach; categories and approximate number of Data Subjects affected; categories and approximate number of records affected; likely consequences; measures taken or proposed
3. Cooperate with the Controller in any regulatory notification obligations

Breach notifications will be sent to the workspace owner's registered email address. For urgent security matters: info@allindiataxes.com with subject `SECURITY BREACH`.

### 3.8 Deletion and Return
At the Controller's instruction, or on termination of the Terms of Service, AIT will:

- Return all Personal Data in machine-readable format (JSON export) within 30 days of request
- Delete all Personal Data and provide written certification within 90 days of termination
- Retain only data required by applicable law (e.g., 7-year GST retention), notifying the Controller of such retention

### 3.9 Audit Rights
AIT will make available all information necessary to demonstrate compliance with this DPA and will contribute to audits conducted by the Controller or its designated auditor. Audits must be:

- Conducted with minimum 30 days' written notice to info@allindiataxes.com
- Conducted at the Controller's expense
- Limited to once per calendar year unless a breach is suspected
- Subject to confidentiality obligations protecting other customers' data

---

## 4. International Data Transfers

Where AIT transfers Personal Data outside India or the EEA, it does so using:

- **EU Standard Contractual Clauses (2021)** for EEA-originating data transferred to non-EEA countries
- **UK IDTA (2022)** for UK-originating data transferred outside the UK
- **DPDP-compliant mechanisms** for India-originating data

The location of each sub-processor and the applicable transfer mechanism are listed in Annex B and Document 09.

---

## 5. CA Firm-Specific Provisions

CA firms using AIT to manage client entities operate in a dual role:

- **As Controller:** for data about their own firm, staff, and workspace configuration
- **As Processor / Sub-Processor:** for their clients' personal and business data processed through the Platform

CA firms must ensure they have appropriate written data processing agreements with their own clients before processing client data through AIT. AIT's DPA with the CA firm covers AIT's role as sub-processor for that client data.

---

## 6. Duration

This DPA is effective from the date the Controller first uses the Platform. It remains in force for the duration of the Terms of Service. Obligations relating to data retained by law survive termination until that data is lawfully deleted.

---

## 7. Governing Law

This DPA is governed by the laws of India. For EU/UK data subjects, GDPR and UK GDPR also apply. In the event of conflict between this DPA and applicable law, applicable law prevails.

---

## Annex A — Categories of Personal Data Processed

| Category | Types of Data | Data Subjects |
|---|---|---|
| Identity Data | Name, email, mobile number, role | Workspace users, contact persons |
| Business Tax Data | GSTIN, TAN, PAN, invoice details, HSN codes, tax amounts, ITC records | Entity owners, vendors |
| Financial Data | Invoice values, payment terms, credit/debit notes | Businesses, vendors |
| Usage and Audit Data | Login events, feature usage, audit logs, IP addresses | All platform users |
| Credential Data (encrypted) | GSP credentials, TRACES credentials | Workspace owners using BYOGSP |
| Vendor Submission Data | Vendor GSTIN, invoice data submitted via Magic Link | Vendors |

---

## Annex B — Approved Sub-Processors

| Sub-Processor | Service | Location | Transfer Mechanism |
|---|---|---|---|
| Supabase, Inc. | Database and authentication | USA / EU | SCCs (2021) |
| Cloudflare, Inc. | CDN, hosting, R2 object storage | Global | SCCs (2021) / DPA |
| Render Services, Inc. | Application hosting | USA | SCCs (2021) |
| Upstash, Inc. | Redis cache and rate limiting | USA / EU | SCCs (2021) |
| Twilio / SendGrid | Transactional email | USA | SCCs (2021) |
| Twilio (WhatsApp) | WhatsApp notifications (opt-in only) | USA | SCCs (2021) |
| GSP Partners (India) | GSTN API access (BYOGSP entities) | India | Within India |
| GSTN / TRACES | Government tax portals | India | Within India (statutory) |

AIT will provide 30 days' advance notice before adding or replacing a sub-processor. The Controller may object within 14 days; if unresolved, affected services may be terminated without penalty.

Full sub-processor detail including security certifications and DPA links is in Document 09.

---

*All India Taxes · allindiataxes.com · info@allindiataxes.com*
*Version 1.0 · 7 March 2026*
