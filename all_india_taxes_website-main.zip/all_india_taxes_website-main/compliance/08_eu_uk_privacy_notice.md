# EU/UK Privacy Notice
**All India Taxes (AIT) · allindiataxes.com**
GDPR (EU) 2016/679 · UK GDPR · EU AI Act Supplement
Version 1.0 · Effective 7 March 2026

---

## Who This Notice Is For

This notice is specifically for individuals in the **European Union, European Economic Area (EEA), and United Kingdom** whose personal data is processed by AIT. It supplements our main Privacy Policy (Document 01) and provides the additional information required by GDPR Articles 13 and 14 and the EU AI Act.

If you are in India, please refer to Document 07 (DPDP Compliance Statement) instead.

---

## 1. Data Controller Identity (GDPR Art. 13(1)(a))

**Data Controller:**
All India Taxes (AIT)
All India Taxes, Senapati Bapat Marg, Mumbai, Maharashtra, India 400013, India
info@allindiataxes.com

**EU Representative (Article 27 GDPR):**
> AIT is in the process of appointing an EU Article 27 Representative. Until appointed, EU residents may direct all GDPR-related correspondence to info@allindiataxes.com. We will update this notice when the Representative is confirmed.

**UK Representative (Article 27 UK GDPR):**
> AIT is in the process of appointing a UK Article 27 Representative. Until appointed, UK residents may direct all UK GDPR-related correspondence to info@allindiataxes.com.

**Note on DPO:** AIT does not currently meet the mandatory DPO appointment thresholds under GDPR Article 37 (we are not a public authority and our core activities do not consist of large-scale systematic monitoring or processing of special category data). As our EU user base grows, we will reassess and appoint a DPO if required. EU/UK users may contact info@allindiataxes.com for all privacy matters.

---

## 2. Legal Bases for Processing (GDPR Art. 13(1)(c))

| Processing Activity | Legal Basis | Detail |
|---|---|---|
| Account creation and management | Art. 6(1)(b) — Contract | Necessary to provide the Platform service |
| GST/TDS compliance processing | Art. 6(1)(b) — Contract | Core service delivery |
| Legal obligation compliance | Art. 6(1)(c) — Legal obligation | GST Act, Income Tax Act retention requirements |
| Security and fraud detection | Art. 6(1)(f) — Legitimate interest | Protecting platform integrity and other users |
| Analytics | Art. 6(1)(a) — Consent | Only if you grant Analytics consent |
| AI model training | Art. 6(1)(a) — Consent | Only if you grant AI Training consent |
| Marketing | Art. 6(1)(a) — Consent | Only if you grant Marketing consent |

**Legitimate interest balancing:** Where we rely on legitimate interest (fraud detection, security), we have conducted a balancing test. Our interest in protecting the platform and its users is not overridden by your interests, as the processing is minimised, you are not targeted individually, and you can object at any time.

---

## 3. International Data Transfers (GDPR Art. 46)

AIT is based in India. India is not currently the subject of an EU adequacy decision under GDPR Article 45. For transfers of EU personal data to India and to our sub-processors, we rely on:

- **EU Standard Contractual Clauses (SCCs) — 2021** — for all transfers from the EEA to AIT in India, and from AIT to non-EEA sub-processors
- **UK International Data Transfer Agreement (IDTA 2022)** — for transfers from the UK

A copy of the SCCs governing our processing can be requested by emailing info@allindiataxes.com with subject `SCC REQUEST`. We respond within 30 days.

Sub-processor locations and transfer mechanisms are detailed in Document 09.

---

## 4. Your Rights Under GDPR (Arts. 15-22)

As an EU or UK resident, you have the following rights. All requests should be sent to info@allindiataxes.com with subject `GDPR DATA REQUEST`:

| Right | What It Means | How We Handle It |
|---|---|---|
| **Access (Art. 15)** | Receive a copy of your personal data and information about how it is processed | Self-serve JSON export via Data Rights Portal; or manual within 30 days |
| **Rectification (Art. 16)** | Correct inaccurate or incomplete personal data | Profile data: self-serve in Settings; tax record corrections: contact us |
| **Erasure (Art. 17)** | Request deletion where processing is no longer necessary or consent is withdrawn | Self-serve Request Erasure in Data Rights Portal; statutory retention (7yr) applies |
| **Restriction (Art. 18)** | Restrict processing while accuracy is contested or objection is pending | Contact us — we restrict within 72 hours of confirmed request |
| **Portability (Art. 20)** | Receive your data in a structured, machine-readable format (JSON) | Self-serve "Download My Data" in Data Rights Portal |
| **Object (Art. 21)** | Object to processing based on legitimate interest or for direct marketing | Contact us; marketing objections honoured immediately |
| **Withdraw consent (Art. 7(3))** | Withdraw consent at any time without affecting prior lawful processing | Settings → Privacy → Consent Management Centre |
| **Automated decision-making (Art. 22)** | Not be subject to solely automated decisions with significant effects | See Section 5 (AI Features) below |

**Response times:** We acknowledge requests within 72 hours and respond fully within 30 days. We may extend by 30 days for complex requests and will notify you.

**Identity verification:** We may ask you to verify your identity before fulfilling rights requests to prevent unauthorised access.

**Complaints:** If you are not satisfied with our response, you have the right to lodge a complaint with your national supervisory authority. Some examples: ICO (UK), CNIL (France), BfDI (Germany), Garante (Italy), AEPD (Spain).

---

## 5. AI Features — EU AI Act Transparency (Art. 13)

AIT uses AI and machine learning in several features. This section provides the transparency disclosures required under the EU AI Act and GDPR Article 22.

### 5.1 AI Features in Use

| Feature | What It Does | AI-Generated Output |
|---|---|---|
| Document Intelligence | OCR extraction of invoice fields from uploaded PDFs; confidence scoring | Extracted field values + confidence percentage per field |
| Auto-fill Predictions | Predicts custom field values (GL code, cost centre) from historical patterns | Pre-filled field values with "auto-filled" indicator |
| Vendor Trust Score | Composite score (0–100) assessing vendor GST compliance reliability | A numeric score with public and private signal components |

### 5.2 Human-in-the-Loop Guarantee
**No AIT AI feature operates autonomously for tax submissions.** Every return, every filing, every significant action requires explicit human review and authorisation. This is not a setting that can be disabled — it is a core architectural principle.

AI prepares. Humans approve. Always.

### 5.3 How to Identify AI-Generated Content
- Fields auto-filled by AI are displayed with a green "auto-filled" badge
- Confidence scores are shown per field: green (85-100%), amber (65-84%), red (0-64%)
- Vendor Trust Scores are labelled as AI-generated scores with a description of what signals they incorporate
- You can always see the original submitted document alongside the AI interpretation (LHS/RHS view)

### 5.4 Right to Human Review (GDPR Art. 22)
Where an AI-generated output (such as an auto-filled field or confidence score) influences a workflow decision (such as whether an invoice can advance to the next stage), you always have the ability to:
- Override the AI's output with your own value
- See the basis for the AI's output
- Have your correction fed back into future predictions

AIT does not make solely automated decisions with legal or similarly significant effects. A human is always in the decision loop before any tax filing is submitted.

### 5.5 AI Training and Your Data
We only use identifiable data to improve or train AI models if you have granted AI Training consent. Withdrawing this consent is honoured within 24 hours. Anonymised and aggregated data may be used for model improvement without consent — no individual can be re-identified from such data.

### 5.6 Accuracy and Bias
- OCR confidence scores are probabilistic and may be inaccurate, particularly for non-standard invoice formats
- Auto-fill predictions are based on your own historical data — they reflect the patterns in your past invoices
- Vendor Trust Scores use public GSTN filing data and platform behaviour; they are indicative, not determinative
- Systematic extraction errors for a specific vendor format are learned and corrected over time as you make corrections
- Full transparency on training data, accuracy metrics, and bias assessment is provided in Document 09

---

## 6. Retention (GDPR Art. 5(1)(e))

Data is retained only as long as necessary for the purposes for which it was collected, or as required by law:

| Category | Retention | Basis |
|---|---|---|
| GST/TDS records | 7 years | GST Act, Income Tax Act (legal obligation) |
| Account data | Duration of account + 90 days | Contract |
| Audit logs | 5 years | SOC 2 / ISO 27001 / Legitimate interest |
| Deleted workspace data | 90 days in backup, then purged | Recovery |
| Marketing consent records | 3 years | Accountability (GDPR Art. 5(2)) |

---

## 7. Sub-Processors and International Transfers

Full list of sub-processors including their location, purpose, and transfer mechanism is in Document 09.

In summary: all EU/UK data transferred outside the EEA or UK is protected by SCCs (2021) or IDTA (2022) respectively. AIT will not transfer EU/UK personal data to a country that does not provide adequate protections.

---

## 8. Changes to This Notice

We will notify EU/UK users of material changes to this notice by email at least 14 days before the change takes effect. The version history is maintained in our legal documentation.

---

## 9. Contact

All EU/UK privacy requests, SCC requests, and GDPR complaints: info@allindiataxes.com

Please include in your email:
- Your name and workspace/account details
- The right you are exercising or the query you have
- Subject line: `GDPR REQUEST` or `UK GDPR REQUEST`

---

*All India Taxes · allindiataxes.com · info@allindiataxes.com*
*Version 1.0 · 7 March 2026*
*This notice will be updated when EU/UK Article 27 Representatives are appointed.*


