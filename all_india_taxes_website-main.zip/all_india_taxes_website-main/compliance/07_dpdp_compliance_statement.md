# DPDP Compliance Statement
**All India Taxes (AIT) · allindiataxes.com**
Digital Personal Data Protection Act, 2023 — India
Version 1.0 · Effective 7 March 2026

---

## Purpose

This statement explains how All India Taxes (AIT) complies with the Digital Personal Data Protection Act, 2023 (DPDP Act). It is an India-specific supplement to our Privacy Policy (Document 01) and is addressed to Data Principals (individuals) and Data Fiduciaries (businesses) using the AIT Platform.

---

## 1. Our Role Under the DPDP Act

The DPDP Act distinguishes between Data Fiduciaries (who determine the purpose and means of processing) and Data Intermediaries (who process data on behalf of Fiduciaries).

| AIT Role | Context |
|---|---|
| **Data Fiduciary** | When AIT collects and processes personal data of Users who register on the Platform (employees, accountants, workspace owners) |
| **Data Intermediary** | When AIT processes data on behalf of Subscribers (Workspace Owners) for their business compliance — e.g. an SMB's vendor invoices, or a CA firm's client entity data |

Where AIT acts as a Data Intermediary, the Subscriber is the Data Fiduciary and is responsible for ensuring lawful basis for the processing they instruct AIT to perform.

---

## 2. Significant Data Fiduciary

AIT processes financial and tax data for a large number of Indian businesses and individuals, which may include sensitive financial information. As the DPDP Act's Significant Data Fiduciary (SDF) thresholds are notified by the Government, AIT will assess and, if applicable, register as an SDF and implement additional requirements including:

- Appointment of a Data Protection Officer (DPO)
- Periodic Data Protection Impact Assessments (DPIAs)
- Annual audit of data processing activities
- Algorithmic accountability measures for AI-based features

Current status: AIT monitors regulatory guidance on SDF thresholds and will notify users of any SDF designation and associated obligations.

---

## 3. Notice (Section 5 of the DPDP Act)

When AIT collects personal data from you as a Data Principal, we provide notice of:

- The personal data being collected
- The purpose of processing
- The way you may exercise your rights
- How to make a complaint to the Data Protection Board of India

**Where notice is provided:**
- At registration: on the sign-up screen before any data is collected
- For consent-based processing: at the point of seeking each specific consent
- In this Privacy Policy and this DPDP Compliance Statement, always accessible at allindiataxes.com/legal

Notice is provided in clear and plain language. We do not use legalese to obscure what we are collecting or why.

---

## 4. Consent (Section 6 of the DPDP Act)

### 4.1 Consent Standards
All consent obtained by AIT for personal data processing is:

- **Free** — no conditional access; you are not required to consent to non-essential processing to use the Platform
- **Specific** — separate consent for each distinct purpose (Analytics, AI Training, Marketing)
- **Informed** — notice is provided before consent is requested
- **Unambiguous** — opt-in only; pre-ticked boxes are never used

### 4.2 Consent Manager
AIT's Consent Management Centre (Settings → Privacy) serves as the Consent Manager interface under the DPDP Act. From there you can:

- View all current consent states
- Grant or withdraw consent for each category independently
- See the date and time consent was last updated

### 4.3 Withdrawal of Consent
You may withdraw consent at any time. Withdrawal does not affect the lawfulness of processing before withdrawal. Effect of withdrawal:

| Consent Type | Effect of Withdrawal |
|---|---|
| Analytics | Takes effect within the current session — no page reload required |
| AI Training | Honoured in all data jobs within 24 hours |
| Marketing | Removed from marketing communications within 5 business days |
| Essential | Cannot be withdrawn — processing is necessary for Platform operation |

### 4.4 Consent for Minors
AIT does not knowingly collect personal data from individuals under 18 years of age. If it becomes apparent that a minor has provided data, we delete it promptly and notify the workspace owner.

---

## 5. Purposes of Processing

AIT processes personal data only for purposes that are specified, clear, and lawful. We do not process data for any purpose not disclosed in our Privacy Policy or this Statement without seeking fresh consent.

Primary purposes:
1. Creating and managing user accounts and workspaces
2. Providing GST and TDS compliance services (return preparation, reconciliation, filing workflow)
3. Invoice validation, submission, and document intelligence
4. Security, fraud prevention, and abuse detection
5. Product improvement (with Analytics consent)
6. AI model training (with AI Training consent)
7. Marketing communications (with Marketing consent)
8. Legal compliance and tax record retention (mandatory — 7 years under GST Act)

---

## 6. Rights of Data Principals (Section 11-14 of the DPDP Act)

### 6.1 Right to Access Information (Section 11)
You have the right to obtain:
- Confirmation of whether your personal data is being processed
- A summary of personal data processed and the processing activities undertaken

**How to exercise:** Settings → Privacy → Data Rights Portal → "Download My Data", or email info@allindiataxes.com with subject `ACCESS REQUEST`. We respond within 30 days.

### 6.2 Right to Correction and Erasure (Section 12)

**Correction:** You have the right to correct inaccurate personal data. For account data, you can edit most fields directly in Settings → Profile. For data embedded in tax records, contact info@allindiataxes.com — note that correction of filed return data may require an amendment return.

**Erasure:** You have the right to request deletion of personal data that is no longer necessary for the purposes for which it was collected, or where you withdraw consent and there is no other lawful basis.

**Important limitation — statutory retention:** GST records must be retained for 7 years under Section 36 of the GST Act. TDS records must be retained for 7 years under the Income Tax Act. These records cannot be deleted earlier regardless of an erasure request. We explain this clearly before you submit an erasure request.

**How to exercise:** Settings → Privacy → Data Rights Portal → "Request Erasure", or email info@allindiataxes.com with subject `ERASURE REQUEST`.

### 6.3 Right to Grievance Redressal (Section 13)

If you have a grievance related to our processing of your personal data:

**Grievance Officer:**
All India Taxes
info@allindiataxes.com
Subject: `PRIVACY GRIEVANCE`
All India Taxes, Senapati Bapat Marg, Mumbai, Maharashtra, India 400013

We acknowledge grievances within 48 hours and resolve them within 30 days. If your grievance is not resolved satisfactorily, you may complain to the Data Protection Board of India.

### 6.4 Right to Nominate (Section 14)
You have the right to nominate another individual to exercise your data rights on your behalf in the event of death or incapacity. Contact info@allindiataxes.com with subject `NOMINATION REQUEST` for the nomination form.

---

## 7. Obligations as Data Fiduciary (Section 8)

As a Data Fiduciary, AIT complies with the following obligations under the DPDP Act:

### 7.1 Accuracy
We take reasonable steps to ensure personal data is accurate and complete. We rely on you to provide accurate data at registration and to update it when it changes. We validate GSTIN data against GSTN in real time.

### 7.2 Data Minimisation
We collect only personal data that is necessary for the purposes described. We do not collect data speculatively.

### 7.3 Storage Limitation
We retain personal data only as long as necessary for the stated purposes, or as required by law. See the Retention table in Document 01 (Privacy Policy, Section 9).

### 7.4 Security
We implement appropriate technical and organisational security measures. See Document 06 (Security Policy) for full detail.

### 7.5 Breach Notification
In the event of a personal data breach, we notify:
- Affected workspace owners by email within 72 hours
- The Data Protection Board of India as required under the DPDP Act

Breach notifications state: what data was affected, what happened, what we are doing, and who to contact.

---

## 8. Data Intermediary Obligations (Section 8(2))

Where AIT acts as a Data Intermediary (processing on behalf of a Subscriber who is the Data Fiduciary), AIT:

- Processes data only on the instructions of the Fiduciary (Subscriber)
- Implements appropriate security measures
- Assists the Fiduciary in meeting their obligations to Data Principals
- Does not sub-engage another Data Intermediary without appropriate contractual protections
- Returns or deletes personal data as instructed by the Fiduciary on termination

These obligations are formalised in the Data Processing Agreement (Document 03).

---

## 9. Cross-Border Data Transfers

The DPDP Act empowers the Central Government to restrict transfer of personal data to certain countries. AIT will comply with any such restrictions as notified. Currently:

- Tax-sensitive data (GST records, TDS data) is processed and stored primarily in India
- Operational data (session tokens, usage logs) may flow through global CDN infrastructure (Cloudflare)
- Where data is transferred internationally, we ensure appropriate safeguards as listed in Document 01, Section 8

We will update this statement promptly when the Central Government notifies the list of countries to which personal data may or may not be transferred.

---

## 10. Exemptions We Rely On

The DPDP Act contains certain exemptions from specific obligations. We rely on:

- **Legal obligation exemption:** We retain GST and TDS records for 7 years as required by the GST Act and Income Tax Act, regardless of erasure requests
- **Security and fraud prevention:** We process data to detect and prevent fraud and abuse without requiring separate consent, as this is a legitimate security function
- **Research and statistics:** Where we generate aggregate, anonymised statistics from platform usage, this does not constitute personal data processing

---

## 11. Contact and Escalation

| Purpose | Contact |
|---|---|
| General privacy queries | info@allindiataxes.com |
| Data rights requests (access, erasure, correction) | info@allindiataxes.com — subject `DATA RIGHTS REQUEST` |
| Grievances | info@allindiataxes.com — subject `PRIVACY GRIEVANCE` |
| Nomination | info@allindiataxes.com — subject `NOMINATION REQUEST` |
| Data Protection Board of India | [dpboard.gov.in](https://dpboard.gov.in) (once portal is live) |

---

*All India Taxes · allindiataxes.com · info@allindiataxes.com*
*Version 1.0 · 7 March 2026*
*This statement will be updated as DPDP Act rules and regulations are notified by the Central Government.*


