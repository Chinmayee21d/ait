# Sub-Processors and AI Transparency
**All India Taxes (AIT) · allindiataxes.com**
Version 1.0 · Effective 7 March 2026 · Updated: 7 March 2026

---

## Purpose

This document provides:

1. **The complete list of AIT sub-processors** — third-party companies that process personal or business data on our behalf, with transfer mechanisms and security certifications
2. **AI feature transparency disclosures** — how our AI systems work, what data they use, known limitations, and accuracy information

This document is referenced by our DPA (Document 03), EU/UK Privacy Notice (Document 08), and Privacy Policy (Document 01).

**Notification of changes:** We will provide 30 days' advance notice of any sub-processor additions or replacements via email to workspace owners and via in-Platform notification. We update the "Updated" date above with every change.

---

## Part 1 — Sub-Processors

### How to Read This Table

- **Purpose:** what the sub-processor does for AIT
- **Personal data transferred:** categories of user data that flow to this sub-processor
- **Location:** where data is processed / stored
- **Transfer mechanism:** legal basis for international transfer of EU/UK/India data
- **Security certification:** independent security assurance the sub-processor holds

---

### 1.1 Infrastructure and Hosting

| Sub-Processor | Purpose | Personal Data | Location | Transfer Mechanism | Certifications |
|---|---|---|---|---|---|
| **Supabase, Inc.** | Relational database, authentication, row-level security | All platform user data, invoice data, audit logs | USA (primary), EU (optional region) | SCCs (2021) | SOC 2 Type II |
| **Cloudflare, Inc.** | CDN, DDoS protection, WAF, Cloudflare Pages (frontend hosting), R2 object storage (documents, exports) | IP addresses, request metadata, uploaded PDFs/documents | Global (edge); data stored in chosen region | SCCs (2021), Cloudflare DPA | ISO 27001, SOC 2 Type II |
| **Render Services, Inc.** | Application server hosting (backend API) | All data processed by the API during request handling | USA | SCCs (2021) | SOC 2 Type II |
| **Upstash, Inc.** | Redis — rate limiting, session state, Magic Link use-count enforcement | Session tokens, API rate counters, Magic Link metadata | USA / EU | SCCs (2021) | SOC 2 Type II |

### 1.2 Communications

| Sub-Processor | Purpose | Personal Data | Location | Transfer Mechanism | Certifications |
|---|---|---|---|---|---|
| **Twilio / SendGrid** | Transactional email (OTP magic links, workflow notifications, data breach notifications) | Email address, notification content | USA | SCCs (2021) | ISO 27001, SOC 2 Type II |
| **Twilio (WhatsApp Business API)** | WhatsApp notifications — opt-in only; highest-urgency events only (overdue filings, filing failures) | Mobile number, notification content | USA | SCCs (2021) | ISO 27001, SOC 2 Type II |

### 1.3 Payments

| Sub-Processor | Purpose | Personal Data | Location | Transfer Mechanism | Certifications |
|---|---|---|---|---|---|
| **Stripe, Inc.** | Payment processing, subscription billing | Payment card data (not stored by AIT), billing name, email, invoice history | USA / EU | SCCs (2021) | PCI DSS Level 1, SOC 2 Type II, ISO 27001 |

### 1.4 Tax and Compliance Infrastructure

| Sub-Processor | Purpose | Personal Data | Location | Transfer Mechanism | Certifications |
|---|---|---|---|---|---|
| **GSP Partners (India)** | GSTN API access — GST return filing, GSTR-2A/2B pull, e-invoice IRN generation. AIT uses its own GSP by default; BYOGSP users use their own. Supported GSPs: Masters India, IRIS Business Services, Cygnet Infotech, Tera Software | GSTIN, return data, invoice data | India | Within India (no international transfer) | GSTN-empanelled; varies by GSP |
| **GSTN (Goods and Services Tax Network)** | Statutory government portal — return filing, GSTR-2B, e-invoice registration | GSTIN, return data, invoice data | India | Within India (statutory obligation) | Government infrastructure |
| **TRACES / TIN-NSDL** | TDS compliance — Form 26AS, TDS returns (24Q, 26Q), TRACES verification | TAN, PAN, TDS deduction data | India | Within India (statutory obligation) | Government infrastructure |

### 1.5 Analytics and Monitoring

| Sub-Processor | Purpose | Personal Data | Location | Transfer Mechanism | Certifications |
|---|---|---|---|---|---|
| **PostHog** | Product analytics — feature usage, funnel analysis, error tracking. Analytics consent required; not activated without consent. | Pseudonymous user ID, event data, IP address (anonymised) | EU (self-hosted option available) | SCCs (2021) or EU-hosted | SOC 2 Type II |

---

### Requesting Sub-Processor DPAs

If you require a copy of the Data Processing Agreement we hold with any specific sub-processor, or the SCC schedule applicable to your data, email info@allindiataxes.com with subject `SUB-PROCESSOR DPA REQUEST`.

---

## Part 2 — AI Transparency

### Overview of AI Features

AIT uses AI and machine learning in three features: Document Intelligence, Auto-fill Predictions, and Vendor Trust Scoring. This section provides transparency on how each works, what data it uses, its known limitations, and what you can do to correct errors.

---

### 2.1 Document Intelligence — OCR and Confidence Scoring

**What it does:**
When a vendor submits an invoice as a PDF, or when a PDF is uploaded directly, Document Intelligence extracts structured fields (invoice number, date, GSTIN of supplier and buyer, HSN codes, taxable value, GST amounts, IRN) using Optical Character Recognition (OCR) and field classification models.

**What data it uses:**
- The submitted PDF document
- The extracted field values
- No data from other workspaces or other vendors is used to extract your documents

**Output:**
Each extracted field is assigned a confidence score:

| Confidence Band | Colour | Meaning | Action Required |
|---|---|---|---|
| 85%–100% | Green | Field is trusted; extraction is reliable | None — but reviewer may verify |
| 65%–84% | Amber | Soft flag; extraction may be inaccurate | Reviewer should verify before advancing |
| 0%–64% | Red | Hard flag; extraction is unreliable | Reviewer must confirm or correct before advancing |
| Not assessed | Grey | AI system unavailable during submission | Manual review required |

**Known limitations:**
- Non-standard invoice formats (handwritten, unusual layouts, low-resolution scans) produce lower confidence scores
- Multi-page invoices with totals on a different page from line items may produce extraction errors
- Non-English text within invoices may reduce accuracy for certain fields
- IRN validation requires GSTN API availability; if GSTN is unavailable, IRN is not verified in real time

**How to correct errors:**
In the LHS/RHS Confidence View, you can edit any field in the RHS (interpreted) panel. Your correction is:
1. Saved to the invoice record
2. Logged to the field correction history for that vendor and field combination
3. Used to improve future extractions from the same vendor's invoices

Over time, systematic extraction errors for a specific vendor's invoice format are learned and confidence improves.

**Human-in-the-loop guarantee:** No invoice can advance through a workflow stage with Red (hard-flagged) fields until a human reviewer confirms or corrects them. The system cannot be configured to bypass this requirement.

---

### 2.2 Auto-fill Predictions

**What it does:**
Auto-fill predicts custom field values (such as GL code, cost centre, department, or project code) when a new invoice arrives from a known supplier. It presents the predicted value with an "auto-filled" badge so reviewers can accept or override with one click.

**What data it uses:**
- The last 30 accepted invoices with the same supplier GSTIN and HSN code in your workspace
- Only your own workspace's data is used — cross-workspace learning does not occur
- No data from other customers' workspaces is used to generate predictions for yours

**Prediction threshold:**
A field is auto-filled only when ≥85% of the relevant historical invoices agree on the same value. Below 85% agreement, the field is left blank for manual entry.

**Known limitations:**
- Auto-fill is only as good as your historical data — if past invoices had incorrect GL codes, predictions will reflect those errors
- The 30-invoice lookback window means predictions for new suppliers or new HSN codes are not available until sufficient history exists
- Structural changes in your organisation (new GL code structure, restructured cost centres) will temporarily reduce prediction accuracy until the new patterns are established
- Auto-fill predictions do not incorporate knowledge of GST rules — they are pattern-matching, not rule-based

**How to correct predictions:**
Reviewers can override any auto-filled value by editing it directly. Overrides:
1. Take effect immediately for the current invoice
2. Are fed back into the prediction model — corrections shift future predictions

---

### 2.3 Vendor Trust Score

**What it does:**
The Vendor Trust Score is a composite score (0–100) assessing a vendor's GST compliance reliability. It helps buyers assess the risk that ITC claimed from a vendor may be disallowed due to vendor non-compliance.

**What data it uses:**

| Signal | Source | Weight |
|---|---|---|
| GSTN filing regularity (GSTR-1, GSTR-3B filing history) | Public GSTN data | High |
| GSTR-2A/2B match rate (what vendor declares vs what appears in buyer's 2B) | AIT platform data (your workspace transactions with this vendor) | High |
| Invoice accuracy rate (OCR errors, corrections made by reviewers) | AIT platform data | Medium |
| Active GSTIN status | Real-time GSTN validation | High |
| E-invoice compliance where applicable | GSTN / IRP data | Medium |

**Public vs private signals:**
- **Public signals** (GSTN filing history, GSTIN status) are available immediately for any vendor with a GSTIN
- **Private signals** (your transaction history with this vendor) build up over time as you process invoices through AIT. Scores based on private signals are more accurate but require sufficient transaction history.

**Score confidence:**
Scores with limited transaction history are displayed with a confidence indicator. A score based on 3 invoices is less reliable than one based on 300. This is clearly labelled on the score display.

**Known limitations and bias risks:**

- **New vendor bias:** Vendors with short GSTN filing history receive lower scores by default due to insufficient data. This may unfairly disadvantage new businesses.
- **Geographic variation:** GSTN system performance and filing patterns vary by state and GSP. Occasional technical filing failures by a vendor due to GSTN outages may negatively affect their score.
- **Data sparsity:** In the early period of AIT's operation, private signal data is limited. We communicate confidence levels clearly and do not present sparse-data scores as definitive.
- **The score is advisory, not determinative:** A low Vendor Trust Score indicates risk; it does not prove non-compliance. You should not deny ITC solely based on a Vendor Trust Score without verifying the underlying GSTN data.
- **Score updates:** Scores are recalculated when new filing data is available from GSTN or when new transactions are processed on AIT. Scores are not real-time.

**How to challenge a score:**
If you believe a Vendor Trust Score is incorrect — for example, due to a known GSTN filing failure that has since been corrected — you can:
1. Check the score detail view for the specific signals driving the score
2. Verify directly on the GSTN portal
3. Contact info@allindiataxes.com with subject `VENDOR TRUST SCORE QUERY` if you believe a data error is causing an inaccurate score

Vendors do not have direct access to their own Trust Score on AIT. Buyers control visibility. If a vendor believes they are being unfairly assessed, they should contact the buyer directly.

---

### 2.4 AI Training and Data Usage

| Consent Type | What Changes With Consent | What Happens Without Consent |
|---|---|---|
| AI Training consent granted | Your workspace's accepted invoices and correction patterns may be used to improve AIT's global OCR and extraction models | Your data is not used for model training; only used to serve your workspace |
| AI Training consent withdrawn | Processing stops; honoured within 24 hours for all data jobs | No change — your data was not being used |

**Anonymisation:** Where anonymised and aggregated data is used for model improvement (e.g., aggregate field correction rates across the platform), no individual workspace or user can be re-identified from the aggregated data.

---

## Changelog

| Date | Change |
|---|---|
| 7 March 2026 | Initial version published |

---

*All India Taxes · allindiataxes.com · info@allindiataxes.com*
*Version 1.0 · 7 March 2026*
*30 days' notice provided to workspace owners before any sub-processor changes.*
