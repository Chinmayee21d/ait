# AIT Legal & Compliance Documentation — Master Index
**All India Taxes · allindiataxes.com**
Version 1.0 · Effective 7 March 2026 · Confidential

---

## Quick Navigation

| # | File | What It Is | Status |
|---|------|-----------|--------|
| 00 | `00_master_index.md` | Start here — compliance matrix, implementation checklist, email requirements | This file |
| 01 | `01_privacy_policy.md` | Main user-facing privacy policy | ✅ Ready — fill in registered address |
| 02 | `02_terms_of_service.md` | Full commercial terms of service | ✅ Ready — fill in registered address |
| 03 | `03_data_processing_agreement.md` | GDPR Art. 28 / DPDP processor contract | ✅ Ready |
| 04 | `04_cookie_policy.md` | Per-category consent framework | ✅ Ready |
| 05 | `05_acceptable_use_policy.md` | Permitted and prohibited uses | ✅ Ready |
| 06 | `06_security_policy.md` | SOC 2 + ISO 27001 aligned security policy | ✅ Ready |
| 07 | `07_dpdp_compliance_statement.md` | India-specific DPDP Act 2023 deep dive | ✅ Ready |
| 08 | `08_eu_uk_privacy_notice.md` | GDPR + EU AI Act supplement | ✅ Ready |
| 09 | `09_sub_processors_ai_transparency.md` | Vendor list + AI bias/accuracy disclosures | ✅ Ready |

---

## Compliance Matrix

| Requirement | Framework | Covered In | Notes |
|---|---|---|---|
| Privacy notice to users | DPDP Act 2023 S.5 | 01, 07 | Must be shown at registration |
| Consent management | DPDP Act 2023 S.6 | 01, 04, 07 | No pre-ticked boxes |
| Grievance Officer | DPDP Act 2023 S.13 | 01, 07 | **Uses info@** — see email section below |
| Data Fiduciary obligations | DPDP Act 2023 S.8 | 01, 03, 07 | |
| Data Intermediary contract | DPDP Act 2023 S.8(2) | 03 | Required for CA-client relationships |
| Right to access | DPDP / GDPR Art.15 | 01, 07, 08 | Self-serve via Data Rights Portal |
| Right to erasure | DPDP / GDPR Art.17 | 01, 07, 08 | Legal hold caveat (7yr GST) |
| Data portability | GDPR Art.20 | 01, 08 | JSON export |
| Processor contract (Art.28) | GDPR / UK GDPR | 03 | Required for EU/UK data |
| Sub-processor disclosure | GDPR Art.28(3)(d) | 03, 09 | 30-day notice of changes |
| International transfer safeguards | GDPR Ch.V / DPDP | 01, 03, 08 | SCCs + IDTA listed |
| Cookie consent | ePrivacy Directive | 04 | Granular per-category |
| Security controls | SOC 2 CC6/CC7 | 06 | Audit logs, encryption, MFA |
| Information security policy | ISO 27001 A.5.1 | 06 | |
| Breach notification (72hr) | GDPR Art.33 / DPDP | 01, 06, 07 | |
| AI transparency | EU AI Act Art.13 | 08, 09 | Confidence scores, human-in-loop |
| AI bias disclosure | EU AI Act | 09 | Vendor Trust Score methodology |
| Acceptable use | SOC 2 / IT Act | 05 | Includes responsible disclosure |
| Retention schedule | GST Act S.36 / IT Act | 02, 06 | 7 years for tax records |
| SLA commitments | Commercial | 02 | Per-plan uptime targets |

---

## Email Address Requirements

> **Currently confirmed email addresses: `sales@allindiataxes.com` · `info@allindiataxes.com`**

The table below shows every email address referenced in this documentation and where it routes.

| Email Address | Purpose | Recommendation |
|---|---|---|
| `info@allindiataxes.com` | General privacy queries, data subject rights requests, DPDP Grievance Officer, abuse reports | **Already exists — use for all of these initially** |
| `sales@allindiataxes.com` | Commercial enquiries, plan upgrades, reseller agreements | **Already exists** |
| `legal@allindiataxes.com` | Legal notices, DPA requests, SCC/IDTA schedules | **⚠️ Create this** — legal notices need a distinct, auditable address |
| `security@allindiataxes.com` | Security vulnerability reports, responsible disclosure, breach reports | **⚠️ Create this** — regulators and researchers expect a dedicated security address; using info@ here weakens your SOC 2 posture |
| `dpo@allindiataxes.com` | EU/UK GDPR Data Protection Officer contact (required under GDPR Art.37 if applicable) | **⚠️ Create if you have EU/UK users** — GDPR requires a separate, identifiable DPO contact. Can forward to info@ internally but must be a distinct address publicly |

### Minimum viable email setup (3 addresses)
If you want to keep things simple, create just these two additional addresses and forward them:
1. `legal@allindiataxes.com` → forwards to founders / legal counsel
2. `security@allindiataxes.com` → forwards to your lead engineer

The `dpo@` address is only mandatory under GDPR if you process EU personal data at scale. If your user base is currently India-only, `info@` is sufficient as Grievance Officer contact — add `dpo@` when you launch in EU/UK.

---

## Implementation Checklist

### Before Launch (Mandatory)
- [ ] Fill in your registered company address in 01 and 02 (marked `All India Taxes, Senapati Bapat Marg, Mumbai, Maharashtra, India 400013`)
- [ ] Confirm which email addresses you are creating (see above)
- [ ] Have a qualified Indian legal counsel review 01, 02, 03, and 07 before publishing
- [ ] Build the Consent Management Centre UI (Settings → Privacy) — referenced in 01, 04, 07
- [ ] Build the Data Rights Portal (Settings → Privacy → Download My Data / Request Erasure) — referenced in 01, 07
- [ ] Display the Privacy Policy link and Cookie consent banner at first visit and registration
- [ ] Ensure consent screen at registration has no pre-ticked boxes (DPDP S.6 requirement)

### Within 90 Days of Launch
- [ ] Engage a GSTN-empanelled GSP and document the relationship in your sub-processor list (09)
- [ ] Commission a third-party penetration test and document findings per 06
- [ ] Implement audit logging as described in 06 (SOC 2 CC7.2)
- [ ] Begin SOC 2 Type II readiness process if enterprise clients are a target segment

### When You Have EU/UK Users
- [ ] Create `dpo@allindiataxes.com`
- [ ] Appoint an EU Article 27 Representative (can be a service provider — not an employee requirement)
- [ ] Appoint a UK Article 27 Representative
- [ ] Ensure EU/UK data stays in EEA or is transferred under SCCs (2021) — verify with each sub-processor
- [ ] Register with relevant DPA if required (e.g., CNIL for France, BfDI for Germany)

### Ongoing
- [ ] Review and update Sub-Processor list (09) whenever you add or change vendors — 30 days' notice required
- [ ] Annual review of all documents — update Effective Date and version
- [ ] Quarterly: workspace owners reminded to review access (SOC 2 CC6.3)
- [ ] Annual: employee security training (ISO 27001 A.6.3)
- [ ] Annual: penetration test
- [ ] Biannual: incident response plan test

---

*All India Taxes · allindiataxes.com · Version 1.0 · 7 March 2026*


