# Privacy Policy
**All India Taxes (AIT) · allindiataxes.com**
Version 1.0 · Effective 7 March 2026

---

## Summary (Plain Language)

| Question | Short Answer |
|---|---|
| Who controls your data? | All India Taxes, registered in India |
| What do we collect? | Account info, tax/invoice data, usage logs |
| Why do we collect it? | To run the platform and meet GST/TDS compliance obligations |
| Do we sell your data? | Never |
| Do we show ads? | Never |
| How long do we keep it? | 7 years for tax records (GST Act); shorter for everything else |
| How do you exercise your rights? | Settings → Privacy → Data Rights Portal, or email info@allindiataxes.com |

---

## 1. Who We Are

All India Taxes ("AIT", "we", "our", "us") operates the compliance intelligence platform at allindiataxes.com. We are the Data Fiduciary under the DPDP Act 2023 and the Data Controller under the GDPR for personal data collected through the platform.

**Contact:**
- General privacy and data rights: info@allindiataxes.com
- Registered address: All India Taxes, Senapati Bapat Marg, Mumbai, Maharashtra, India 400013

Where CA firms use AIT to process data on behalf of their clients, AIT acts as a Data Processor / Data Intermediary for that client data under the terms of our Data Processing Agreement (see Document 03).

---

## 2. Scope

This policy applies to:

- **Users** — workspace owners, filers, preparers, reviewers, and all other registered platform users
- **Vendors** — suppliers who submit invoices via Magic Links without creating an AIT account
- **CA Users** — chartered accountants and accounting firms managing client entities
- **API Users** — developers and ERP integrations accessing the AIT API
- **Website Visitors** — people who visit allindiataxes.com without registering

---

## 3. Frameworks We Comply With

- Digital Personal Data Protection Act, 2023 (DPDP Act) — India
- General Data Protection Regulation 2016/679 (GDPR) — European Union
- UK General Data Protection Regulation (UK GDPR)
- SOC 2 Type II Trust Services Criteria
- ISO/IEC 27001:2022 Information Security Management

---

## 4. What Data We Collect

### 4.1 Account and Identity Data
- Full name, email address, mobile number
- Company name, role within workspace
- Profile and notification preferences

### 4.2 Tax and Financial Data
- GSTIN(s), TAN(s), PAN, business registration details
- Invoice data: GSTIN of buyer/seller, HSN/SAC codes, taxable values, GST amounts, IRN, invoice dates
- GSTR-1, GSTR-3B, GSTR-2A/2B reconciliation records
- TDS deduction data: TAN, deductee PAN, section codes, challans
- ITC (Input Tax Credit) claims and reversal records

### 4.3 Integration and Credential Data
- API keys (prefix only stored; full key shown once and never retained in retrievable form)
- ERP webhook URLs and event subscriptions
- GSP credentials for BYOGSP users — encrypted at rest using AES-256-GCM; decrypted only in memory for a single API call; never returned in any API response
- TRACES credentials — same encryption and handling as GSP credentials

### 4.4 Vendor Data (Magic Link Submissions)
- Vendor GSTIN (validated against GSTN)
- Invoice details submitted through the vendor portal
- Submission timestamp and IP address

Vendors do not need an AIT account. Their data is processed solely to facilitate invoice submission and validation for the receiving entity.

### 4.5 Usage and Technical Data
- IP address, browser type, device identifiers, operating system
- Pages visited, features used, session duration
- Error logs and performance metrics
- Audit trail events (login, invoice created/modified, return filed, role changed)

### 4.6 Consent Preferences
- Essential (always active)
- Analytics (optional)
- AI Training (optional)
- Marketing (optional)

---

## 5. Legal Basis for Processing

| Processing Activity | GDPR/UK GDPR Basis | DPDP Basis |
|---|---|---|
| Account creation and platform access | Contract (Art. 6(1)(b)) | Consent / Contract |
| GST/TDS compliance processing | Contract + Legal obligation (Art. 6(1)(c)) | Legitimate Use |
| Invoice reconciliation and filing | Contract (Art. 6(1)(b)) | Contract |
| Fraud detection and security | Legitimate interest (Art. 6(1)(f)) | Legitimate Use |
| Analytics and product improvement | Consent (Art. 6(1)(a)) | Consent |
| AI model training | Consent (Art. 6(1)(a)) | Consent |
| Marketing communications | Consent (Art. 6(1)(a)) | Consent |
| Legal hold and audit records | Legal obligation (Art. 6(1)(c)) | Legal Obligation |

---

## 6. How We Use Your Data

### 6.1 Platform Operation
- Authenticate users and manage sessions
- Process invoice submissions, reconciliation, and GST/TDS return preparation
- Generate Vendor Trust Scores based on filing behaviour and invoice accuracy
- Auto-fill custom fields using historical patterns (85% agreement threshold)
- Route invoices through configurable workflow stages and trigger notifications

### 6.2 Security and Compliance
- Maintain audit logs for all material actions (SOC 2 CC7.2; ISO 27001 A.12.4)
- Detect and prevent unauthorised access and abuse
- Enforce account lockout after 5 failed login attempts (15-minute lockout)
- Enforce MFA where enabled by workspace owners

### 6.3 AI Features
- OCR extraction and confidence scoring for uploaded PDF invoices
- Auto-fill predictions trained on accepted invoices from the same supplier GSTIN and HSN code
- Vendor Trust Score computation using public GSTN data and platform behaviour

**AI Training Consent:** We only use identifiable data to improve AI models if you have granted AI Training consent. Withdrawing this consent is honoured within 24 hours for all data jobs. Fully anonymised and aggregated data may be used for model improvement without consent.

---

## 7. Data Sharing

### 7.1 Within Your Workspace
Data is shared between workspace members according to their assigned roles. CA firms access client entity data only within the scope of the CA-client relationship.

### 7.2 Sub-Processors
We share data with trusted sub-processors to operate the platform. The full list is in Document 09. Key sub-processors:

| Sub-Processor | Purpose | Location |
|---|---|---|
| Supabase | Database and authentication | EU / USA |
| Cloudflare | CDN, hosting, R2 storage | Global |
| Render | Application hosting | USA |
| Upstash | Redis cache | EU / USA |
| Twilio / SendGrid | Email and WhatsApp notifications | USA |

We do not sell personal data. We do not share data with advertisers.

### 7.3 Legal Disclosures
We may disclose data where required by law, court order, or government authority (GST authorities, Income Tax Department, TRACES). We will notify you before such disclosure where legally permitted.

---

## 8. International Data Transfers

Data may be transferred to countries outside India or the EEA to operate the platform. Safeguards in place:

- **EU Standard Contractual Clauses (2021)** for EEA-originating data transferred to non-EEA countries
- **UK IDTA (2022)** for UK-originating data
- **DPDP-compliant mechanisms** for India-originating data

Tax-sensitive records are primarily stored in India. They are not transferred outside India without your consent except where required by law.

---

## 9. Retention

| Data Category | Retention Period | Basis |
|---|---|---|
| GST return records, invoices, ITC data | 7 years from filing date | GST Act Section 36 |
| TDS records, challans, Form 16/16A | 7 years from assessment year | Income Tax Act Section 206 |
| Audit logs and security events | 5 years | SOC 2 / ISO 27001 |
| Account and profile data | Duration of account + 90 days | Contract |
| Vendor submission data (Magic Link) | 7 years | GST Act |
| Deleted workspace data | 90 days in backup, then purged | Recovery / Contract |
| Marketing consent records | 3 years after last interaction | Accountability |

Where data is subject to a legal hold (GST scrutiny, litigation), retention extends until the hold is lifted. This is communicated in the Data Rights Portal.

---

## 10. Your Rights

### 10.1 Under the DPDP Act 2023 (Indian Users)
- **Access** — obtain a summary of personal data processed and how it is processed
- **Correction and erasure** — correct inaccurate data; request deletion of data no longer necessary
- **Grievance redressal** — lodge complaints with our Grievance Officer (info@allindiataxes.com)
- **Nomination** — nominate an individual to exercise rights on your behalf

### 10.2 Under GDPR / UK GDPR (EU/UK Users)
- **Access (Art. 15)** — receive a copy of your personal data
- **Rectification (Art. 16)** — correct inaccurate or incomplete data
- **Erasure (Art. 17)** — request deletion where processing is no longer necessary
- **Restriction (Art. 18)** — restrict processing while accuracy is disputed
- **Portability (Art. 20)** — receive data in machine-readable JSON format
- **Object (Art. 21)** — object to processing based on legitimate interest
- **Withdraw consent** — at any time, without affecting prior lawful processing
- **Complaint** — lodge a complaint with your national supervisory authority (ICO, CNIL, BfDI, etc.)

### 10.3 How to Exercise Your Rights
- **Self-serve:** Settings → Privacy → Data Rights Portal (Download My Data, Request Erasure)
- **Email:** info@allindiataxes.com with subject line `DATA SUBJECT REQUEST`

We respond within 30 days. We may verify your identity before fulfilling requests.

---

## 11. Security

We maintain technical and organisational measures aligned with SOC 2 and ISO 27001. Key controls:

- TLS 1.2+ encryption in transit
- AES-256-GCM encryption at rest for sensitive credentials
- Per-entity data isolation with row-level security
- HMAC-SHA256 signed tokens for Magic Links
- Comprehensive audit logging
- Regular third-party penetration testing

Full detail is in Document 06 (Security Policy).

### Data Breach Notification
If a breach affects your workspace, we will:
- Notify workspace owners by email within 72 hours of becoming aware
- State what data was affected, what happened, our response, and contact details
- Notify the Data Protection Board of India (DPDP Act) and relevant DPAs (GDPR) as required

---

## 12. Consent Management

At registration, you are shown a consent screen covering four consent types. Pre-ticked boxes are not used. You can update consent at any time via Settings → Privacy → Consent Management Centre.

- Withdrawing **Analytics** consent takes effect within the current session — no page reload required
- Withdrawing **AI Training** consent is honoured in all data jobs within 24 hours
- Withdrawing **Marketing** consent removes you from marketing emails within 5 business days

---

## 13. Cookies

See Document 04 (Cookie Policy) for the full cookie register. In brief:

| Category | Opt-Out |
|---|---|
| Essential | Not possible — required for platform function |
| Analytics | Via Consent Centre in Settings |
| Marketing | Via Consent Centre in Settings |

---

## 14. Children

AIT is a B2B platform for businesses and professionals. We do not knowingly collect data from individuals under 18. Contact info@allindiataxes.com if you believe a minor has submitted data.

---

## 15. Changes to This Policy

Material changes will be notified by email at least 14 days before they take effect. We will update the Effective Date above. Continued use after the effective date constitutes acceptance.

---

## 16. Governing Law

This policy is governed by the laws of India. EU/UK users may also rely on GDPR and UK GDPR. Supervisory authorities:

| Region | Authority |
|---|---|
| India | Data Protection Board of India |
| European Union | Your national DPA |
| United Kingdom | Information Commissioner's Office (ICO) |

---

*All India Taxes · allindiataxes.com · info@allindiataxes.com*
*Version 1.0 · 7 March 2026*


