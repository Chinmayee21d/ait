# Acceptable Use Policy (AUP)
**All India Taxes (AIT) · allindiataxes.com**
Version 1.0 · Effective 7 March 2026

---

## Purpose

This Acceptable Use Policy defines the standards of behaviour required from all users of the AIT Platform. It supplements the Terms of Service (Document 02) and forms part of your agreement with AIT.

The AIT Platform handles sensitive tax and financial data for thousands of businesses. Misuse does not only affect AIT — it can harm other users, vendors, and the integrity of India's GST ecosystem.

---

## 1. Permitted Uses

You may use the Platform to:

- Manage GST and TDS compliance for entities registered in India within the scope of your Subscription
- Submit, validate, and reconcile invoices from your vendors
- Prepare and review GST returns (GSTR-1, GSTR-3B) and TDS returns before human-authorised submission
- Connect your ERP to AIT via the official API for invoice data exchange
- Invite vendors to submit invoices via Magic Links
- Generate Vendor Trust Score reports for your vendor management processes
- Configure approval workflows, custom fields, and notification rules for your workspace

---

## 2. Prohibited Uses

### 2.1 Tax Fraud and Financial Crime

The following are strictly prohibited and will result in immediate account termination and referral to relevant authorities:

- Submitting false, fabricated, or inflated invoices
- Claiming ITC for transactions that did not occur
- Creating or facilitating shell company workflows to inflate GST credits
- Using the Platform in connection with money laundering or financial fraud
- Deliberately misclassifying supplies to reduce tax liability

### 2.2 Security Violations

- Attempting to gain unauthorised access to any workspace, entity, or user account
- Testing Platform security with automated scanning tools without written authorisation from AIT
- Introducing malware, ransomware, viruses, or any harmful code to the Platform
- Intercepting, or attempting to intercept, data transmissions
- Disclosing or exploiting security vulnerabilities without following the Responsible Disclosure process below
- Forging HMAC tokens, Magic Link URLs, or authentication credentials

### 2.3 Platform Abuse

- Exceeding API rate limits (1,000 requests/hour; 10,000/day per key) or circumventing throttling
- Using bots or scrapers outside the official API to extract data at scale
- Creating multiple accounts or workspaces to circumvent plan limits
- Reselling Platform access without a written reseller agreement (contact sales@allindiataxes.com)
- Using Magic Links for any purpose other than legitimate vendor invoice submission to the intended entity
- Artificially inflating usage metrics or Vendor Trust Scores

### 2.4 Data and Privacy Violations

- Processing personal data of third parties through the Platform without a lawful basis
- Sharing login credentials, session tokens, or API keys with unauthorised individuals
- Uploading personal data of individuals who have not been informed of such processing
- Using the Platform in a way that violates the DPDP Act, GDPR, or any applicable privacy law
- Accessing another workspace's data through misconfigured permissions and failing to report it immediately

### 2.5 Content Violations

- Uploading content that is defamatory, harassing, or abusive
- Using the Platform to store content unrelated to GST/TDS compliance
- Attempting to use the AI features to generate outputs for purposes outside compliance (e.g. generating fraudulent documents)

---

## 3. Responsible Disclosure

AIT operates a responsible disclosure programme for security researchers.

If you discover a security vulnerability in the AIT Platform:

1. **Report it** — email info@allindiataxes.com with subject `RESPONSIBLE DISCLOSURE` and include a clear description of the vulnerability, steps to reproduce, and any evidence (screenshots, logs)
2. **Do not exploit it** — do not access, modify, or delete data beyond what is minimally necessary to demonstrate the vulnerability
3. **Give us time** — allow us 30 business days to investigate and remediate before any public disclosure
4. **Coordinate** — we will acknowledge your report within 2 business days and provide status updates

**What you can expect from us:**
- We will not pursue legal action against researchers acting in good faith under this programme
- We will acknowledge the finding and credit you (if you wish) after remediation
- We do not offer a bug bounty programme at this time, but we may do so in future

This programme does not authorise you to access accounts, data, or systems that are not your own, to perform denial-of-service testing, or to conduct social engineering attacks against AIT staff.

---

## 4. Enforcement

Violations of this AUP may result in any or all of the following, at AIT's sole discretion:

- **Warning** — for minor or first-time violations
- **Feature restriction** — access to specific features suspended pending investigation
- **Account suspension** — temporary suspension while we investigate
- **Account termination** — permanent termination with no refund for the current billing period
- **Legal action** — where violations constitute criminal offences under the IT Act, GST Act, or Indian Penal Code
- **Regulatory referral** — reporting to the GST Council, Income Tax Department, CERT-In, or other relevant authorities

AIT reserves the right to investigate suspected violations, including reviewing audit logs and usage data. We will cooperate with law enforcement agencies where required by law.

---

## 5. Reporting Violations

If you believe another user is violating this AUP — for example, submitting fraudulent invoices or attempting to access your workspace without authorisation — please report it to:

**info@allindiataxes.com** with subject `AUP VIOLATION REPORT`

Reports are treated confidentially. Include as much detail as possible: what you observed, when, and any evidence.

---

## 6. Updates

AIT may update this AUP at any time. Material changes will be communicated via in-Platform notification and email with at least 14 days' notice. Continued use after the effective date constitutes acceptance.

---

*All India Taxes · allindiataxes.com · info@allindiataxes.com · sales@allindiataxes.com*
*Version 1.0 · 7 March 2026*
