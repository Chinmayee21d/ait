# Terms of Service
**All India Taxes (AIT) · allindiataxes.com**
Version 1.0 · Effective 7 March 2026

---

## Summary (Plain Language)

| | |
|---|---|
| **You must be 18+** and have authority to bind your company | |
| **AIT is a compliance tool, not a tax advisor** — you remain responsible for all filings | |
| **AI assists, humans decide** — AIT never autonomously submits a return | |
| **Tax records are kept 7 years** by law — you cannot delete them earlier | |
| **Cancellation** is self-serve from Settings → Billing | |
| **Questions?** sales@allindiataxes.com · info@allindiataxes.com | |

---

## 1. Agreement and Acceptance

These Terms of Service ("Terms") are a binding legal agreement between you ("User", "Subscriber", "you") and All India Taxes ("AIT", "we", "our", "us"), governing your access to and use of the platform at allindiataxes.com ("Platform").

By registering an account, clicking "I Agree", or using the Platform in any way, you confirm that:

- You are at least 18 years of age and have legal capacity to enter a binding agreement
- You have authority to bind your company or firm to these Terms
- You have read and agree to these Terms and our Privacy Policy

**Registered address:** All India Taxes, Senapati Bapat Marg, Mumbai, Maharashtra, India 400013
**Commercial enquiries:** sales@allindiataxes.com
**General / support:** info@allindiataxes.com

---

## 2. Definitions

| Term | Meaning |
|---|---|
| **Platform** | The AIT software-as-a-service application, APIs, and associated services |
| **Workspace** | A top-level account on the Platform (one per business or CA firm) |
| **Entity** | A GSTIN/TAN holder managed within a Workspace |
| **User** | Any person with a role within a Workspace |
| **CA User** | A chartered accountant or accounting firm using the Platform to manage client entities |
| **Vendor** | A supplier submitting invoices via Magic Link without an AIT account |
| **Magic Link** | A secure, signed URL enabling vendor invoice submission without account creation |
| **Subscription** | A paid plan providing access to Platform features |
| **Service Credits** | Compensation issued for SLA breaches per Section 12 |
| **Your Data** | All data you submit to or generate within the Platform |
| **Confidential Information** | Non-public technical, business, or financial information shared between the parties |

---

## 3. Account Registration and Security

### 3.1 Registration
- You must provide accurate, current, and complete registration information and keep it updated
- Each Workspace must have a designated Owner with full administrative access
- You are responsible for all activity that occurs under your account

### 3.2 Authentication
- Login is via magic link OTP — no password required
- Accounts are locked for 15 minutes after 5 consecutive failed login attempts
- Workspace Owners may enforce MFA for all users in their Workspace
- You must not share login credentials or session tokens with unauthorised persons
- Report any suspected security breach immediately to info@allindiataxes.com

### 3.3 API Keys
- API keys are issued for ERP integration and developer access
- The full key is shown once at creation; AIT stores only the prefix — you are responsible for keeping your key secure
- Rate limits apply: 1,000 requests per hour and 10,000 per day per key
- AIT may revoke keys if abuse or a security risk is detected

---

## 4. Permitted Use and Restrictions

### 4.1 Permitted Use
You may use the Platform solely for lawful GST and TDS compliance management, invoice reconciliation, and related financial record-keeping for entities registered in India, within the scope of your Subscription plan.

### 4.2 Prohibited Activities
You must not:

- Use the Platform for any unlawful purpose, including tax evasion or fraudulent ITC claims
- Submit false, misleading, or fabricated invoice data
- Attempt to gain unauthorised access to other workspaces or entities
- Reverse-engineer, decompile, or extract source code from the Platform
- Use automated tools except via our official API
- Exceed API rate limits or attempt to circumvent them
- Resell or sub-licence Platform access without a written reseller agreement (contact sales@allindiataxes.com)
- Upload malware, viruses, or harmful code
- Conduct denial-of-service attacks or intentionally degrade Platform performance

See Document 05 (Acceptable Use Policy) for the full list.

---

## 5. CA-Client Relationship

### 5.1 Data Ownership Principle
Origin determines ownership. The Workspace that onboarded an Entity owns the data leverage for that Entity. This governs all CA-client relationships on the Platform.

### 5.2 CA Access Rights
- A CA User invited by a client Entity may access that Entity's data for compliance management
- CA Users may not transfer client Entity data to another platform without the client's consent
- CA Users act as data processors for their clients' data under applicable law

### 5.3 Transition Rights
- When a client removes a CA from their Workspace, the CA loses access immediately
- The client Entity retains full access to all historical data regardless of CA relationship status
- A CA who onboarded an Entity cannot retain access after explicit removal by the Entity owner
- These rules apply regardless of which party initiated the relationship

---

## 6. Subscription, Billing, and Payment

### 6.1 Plans
AIT offers Starter, Growth, Business, CA Growth, and CA Enterprise plans. Features and pricing are published at allindiataxes.com/pricing. Material changes to plan features are communicated with 30 days' notice to existing subscribers.

### 6.2 Billing
- Subscriptions are billed monthly or annually in advance in Indian Rupees (INR)
- Usage-based charges (additional entities, GSP API calls) are billed in arrears
- Prices are exclusive of applicable GST
- You authorise automatic renewal charges to your payment method on file

### 6.3 Payment Failure
- We retry failed payments twice over 7 days and notify you by email
- After 14 days of non-payment the account enters read-only mode
- After 30 days the subscription is cancelled and data deletion begins per our retention policy

### 6.4 Cancellation and Refunds
- Cancel at any time from Settings → Billing
- Cancellation takes effect at the end of the current billing period
- Annual subscriptions are non-refundable except as required by law
- Monthly subscriptions: no refund for the current month; future charges stop

For billing questions contact sales@allindiataxes.com.

---

## 7. Intellectual Property

### 7.1 AIT's IP
AIT owns all rights in the Platform including software, algorithms, AI models, Vendor Trust Score methodology, user interface designs, documentation, and trademarks. Nothing in these Terms transfers any IP rights to you.

### 7.2 Your Data
You own all data you submit to the Platform. You grant AIT a limited, non-exclusive licence to process Your Data solely to provide the Platform services. This licence terminates on account closure subject to statutory retention obligations.

### 7.3 Feedback
If you provide feedback or suggestions, you grant AIT a royalty-free, irrevocable, worldwide licence to use them without obligation to you.

---

## 8. Data Handling and Retention

Data handling is governed by our Privacy Policy (Document 01), incorporated by reference. Key commitments:

- GST and TDS records are retained for 7 years (GST Act Section 36; Income Tax Act)
- Deleted Workspace data is purged from backups within 90 days unless subject to a legal hold
- Sensitive credentials (GSP, TRACES) are encrypted at rest (AES-256-GCM) and never retrievable
- AIT maintains SOC 2 and ISO 27001 aligned security controls (Document 06)

---

## 9. AI Features — Disclaimer and Human-in-the-Loop

AIT's AI features assist human reviewers. They do not replace professional judgement and are not a substitute for qualified tax advice.

- **AI prepares, humans approve** — AIT will never autonomously submit a GST return or TDS filing without explicit human authorisation
- **Confidence scores are probabilistic** — OCR extraction and auto-fill predictions may be incorrect
- **Vendor Trust Scores are advisory** — they are not a guarantee of a vendor's compliance and should not be the sole basis for ITC decisions
- **You remain fully responsible** for the accuracy of all filings submitted through the Platform

AIT is not liable for penalties, interest, or disallowed ITC arising from AI-generated outputs that you reviewed, approved, and submitted.

---

## 10. Third-Party Integrations

### 10.1 ERP Integrations
ERP integrations (Tally, SAP, Zoho Books, QuickBooks, Oracle) operate via our open API. AIT does not warrant the accuracy of data received from third-party ERP systems. You are responsible for ensuring your ERP sends correct data.

### 10.2 BYOGSP and TRACES
BYOGSP users use their own GSP credentials. AIT facilitates the connection but is not responsible for GSP service availability, GSTN API changes, or TRACES portal outages. If your credentials fail, AIT may fall back to AIT's GSP and notify you; metered charges apply to fallback calls only.

### 10.3 Government Portals
GSTN, IRP, and TRACES portals are operated by the Government of India. AIT has no control over their availability or API changes. Government portal outages are not SLA events under AIT's commitments.

---

## 11. Confidentiality

Each party will keep the other's Confidential Information strictly confidential and not disclose it to third parties without prior written consent, except as required by law. AIT treats Your Data and business information as Confidential Information. This obligation survives termination for 5 years.

---

## 12. Service Level Agreement

| Plan | Monthly Uptime SLA | P1 Response Time |
|---|---|---|
| Starter | 99.5% | 4 hours |
| Growth | 99.7% | 2 hours |
| Enterprise / CA Enterprise | 99.9% | 30 minutes |

- Maintenance windows (max 4 hours/month, 48 hours' advance notice) are excluded from SLA measurement
- Government portal outages are excluded from AIT's SLA
- SLA breaches entitle you to Service Credits as published in the SLA Policy in your account dashboard
- Service Credits are your sole remedy for SLA breaches — they do not entitle you to cash refunds

**Filing-Day Protocol:** On GST due dates (typically the 11th and 20th of each month), AIT activates enhanced operations with engineering on-call from 08:00–22:00 IST and a deployment freeze from D-1 through D+1.

---

## 13. Support

| Plan | Support |
|---|---|
| Starter | In-app chat (business hours IST) + email to info@allindiataxes.com |
| Growth | Priority queue + extended hours in-app chat + email |
| Enterprise / CA Enterprise | Dedicated account manager + WhatsApp/phone + 24×7 P1 coverage |

---

## 14. Warranties and Disclaimers

### 14.1 AIT's Warranties
- The Platform will perform materially in accordance with its documentation
- We will maintain security controls as described in our Privacy Policy and Security Policy
- We will provide the support described in Section 13

### 14.2 Disclaimers
TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, AIT DISCLAIMS ALL IMPLIED WARRANTIES INCLUDING MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT. THE PLATFORM IS PROVIDED ON AN "AS IS" AND "AS AVAILABLE" BASIS.

AIT does not provide legal, tax, or accounting advice. The Platform is a technology tool. Consult a qualified professional for tax advice specific to your circumstances.

---

## 15. Limitation of Liability

TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW:

- AIT's total aggregate liability for any claims under these Terms shall not exceed the amount you paid to AIT in the 12 months preceding the event giving rise to the claim
- AIT is not liable for indirect, incidental, special, consequential, or punitive damages, including loss of profits, data, or business opportunity
- AIT is not liable for penalties, interest, or regulatory fines arising from filings submitted through the Platform
- AIT's liability for government portal outages is excluded

These limitations apply even if AIT has been advised of the possibility of such damages.

---

## 16. Indemnification

You agree to indemnify and hold harmless AIT and its directors, officers, and employees from any claims, losses, and expenses (including legal fees) arising from:

- Your violation of these Terms
- Data you submit that infringes any third-party rights
- Tax filing errors caused by data you provided or approved
- Unauthorised use of your account or API keys

---

## 17. Termination

### 17.1 By You
Cancel from Settings → Billing. Termination takes effect at the end of the billing period.

### 17.2 By AIT
AIT may suspend or terminate your account immediately if you:
- Materially breach these Terms and fail to cure within 7 days of notice
- Use the Platform for fraudulent or unlawful purposes
- Fail to pay subscription fees for more than 30 days
- Present a security risk to the Platform or other users

### 17.3 Effect of Termination
- Access ceases on the effective termination date
- You may request a data export up to 30 days after termination (info@allindiataxes.com)
- We retain data as required by law (7 years for GST records) then permanently delete

---

## 18. Governing Law and Dispute Resolution

- These Terms are governed by the laws of India
- Disputes shall first be referred to good-faith negotiation for 30 days
- Unresolved disputes shall be submitted to arbitration under the Arbitration and Conciliation Act, 1996
- Seat of arbitration: Mumbai, India · Language: English
- Nothing prevents either party from seeking urgent injunctive relief from a competent court

---

## 19. Changes to These Terms

For material changes, we will provide at least 30 days' notice by email and in-Platform notification. Continued use after the effective date constitutes acceptance. If you do not agree, you may terminate your subscription before the effective date without penalty.

---

## 20. General

- **Entire agreement:** These Terms, the Privacy Policy, and any Order Form constitute the entire agreement between the parties
- **Severability:** If any provision is unenforceable, the remainder continues in full force
- **Waiver:** Failure to enforce any provision is not a waiver of the right to enforce it later
- **Assignment:** You may not assign these Terms without our written consent; AIT may assign in connection with a merger or acquisition
- **Force majeure:** Neither party is liable for failures due to causes beyond reasonable control, including government portal outages
- **Legal notices:** Send legal notices to info@allindiataxes.com with subject `LEGAL NOTICE`

---

*All India Taxes · allindiataxes.com · sales@allindiataxes.com · info@allindiataxes.com*
*Version 1.0 · 7 March 2026*


