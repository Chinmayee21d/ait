# Cookie Policy
**All India Taxes (AIT) · allindiataxes.com**
Version 1.0 · Effective 7 March 2026

---

## What This Policy Covers

This policy explains every cookie and similar technology we use on allindiataxes.com and the AIT Platform, why we use it, how long it lasts, and how you can control it.

---

## 1. What Are Cookies?

Cookies are small text files stored on your device when you visit a website. They allow the site to recognise your device on subsequent visits. We also use similar technologies including browser local storage and tracking pixels where noted.

---

## 2. Our Cookie Categories

We use four categories of cookies. You control three of them.

### 2.1 Essential Cookies — Always Active

These cookies are strictly necessary for the Platform to function. They cannot be disabled without breaking the platform. We do not require consent for these under ePrivacy rules because they are technically essential.

| Cookie | Purpose | Duration |
|---|---|---|
| `ait_session` | Authenticated session token — identifies your logged-in session securely | Session |
| `ait_csrf` | Cross-Site Request Forgery (CSRF) protection — prevents malicious requests | Session |
| `ait_workspace` | Remembers your active workspace selection between pages | 30 days |
| `ait_auth_state` | Stores authentication state during magic link OTP flow | 10 minutes |
| `cf_clearance` | Cloudflare bot protection and DDoS mitigation | 1 year |
| `__stripe_mid` | Stripe payment processing — fraud prevention | 1 year |
| `__stripe_sid` | Stripe payment processing — session continuity | Session |

### 2.2 Analytics Cookies — Consent Required

These cookies help us understand how users interact with the Platform. We use this data to fix bugs, improve user flows, and prioritise features. We do not share this data with advertising networks.

| Cookie | Purpose | Duration |
|---|---|---|
| `ait_analytics_id` | Anonymous identifier for usage analytics — no PII | 12 months |
| `ait_session_seq` | Session-level event sequence for flow analysis | Session |
| `ph_*` (PostHog) | Product analytics — feature usage, funnel completion, error tracking | 12 months |

**How to opt out:** Settings → Privacy → Consent Management Centre → Analytics → Off. Takes effect immediately, within the current session — no page reload required.

### 2.3 Marketing Cookies — Consent Required

These cookies track whether you came to AIT from a marketing campaign. We use this to measure which channels bring us users and to avoid sending irrelevant follow-up communications.

| Cookie | Purpose | Duration |
|---|---|---|
| `ait_utm` | Stores UTM parameters (source, medium, campaign) from your first visit | 30 days |
| `ait_referral` | Tracks referral partner or affiliate attribution | 30 days |
| `ait_first_touch` | Records the first marketing channel that brought you to AIT | 12 months |

**How to opt out:** Settings → Privacy → Consent Management Centre → Marketing → Off.

### 2.4 Preference Cookies — Consent Required

These cookies remember your display preferences so you do not have to re-set them each visit.

| Cookie | Purpose | Duration |
|---|---|---|
| `ait_theme` | Stores your light/dark mode preference | 12 months |
| `ait_locale` | Stores your language/locale preference | 12 months |

**How to opt out:** Settings → Privacy → Consent Management Centre → Preferences → Off. Note: if you opt out, these preferences will be reset on each visit.

---

## 3. No Third-Party Advertising Cookies

AIT does not use advertising networks, retargeting pixels (Google Ads, Facebook Pixel, LinkedIn Insight Tag), or any cookies that track you across other websites for advertising purposes. We do not sell your browsing data. We do not serve ads.

---

## 4. Managing Cookies

### Via AIT Settings
Settings → Privacy → Consent Management Centre. You can change any non-essential cookie consent at any time. Changes take effect immediately or within the current session.

### Via Your Browser
You can configure or block cookies in your browser settings. Note that blocking essential cookies will prevent the Platform from working.

| Browser | Settings Location |
|---|---|
| Chrome | Settings → Privacy and Security → Cookies |
| Firefox | Preferences → Privacy and Security |
| Safari | Preferences → Privacy |
| Edge | Settings → Cookies and Site Permissions |

### Do Not Track (DNT)
We honour Do Not Track signals. When DNT is active in your browser, we automatically disable all non-essential cookies.

---

## 5. Consent at Registration

When you first visit allindiataxes.com, a cookie consent banner is displayed. Pre-ticked boxes are not used — you must actively choose to enable Analytics, Marketing, and Preference cookies. Essential cookies are active without consent as they are technically necessary.

Your consent choices are stored and respected on subsequent visits. You can change them at any time via Settings.

---

## 6. Updates to This Policy

We update this policy when we add, remove, or change cookies. Material changes are communicated by in-Platform notification. The Effective Date at the top of this document is always the date of the most recent update.

---

## 7. Questions

For questions about our cookie practices: info@allindiataxes.com

---

*All India Taxes · allindiataxes.com · info@allindiataxes.com*
*Version 1.0 · 7 March 2026*
