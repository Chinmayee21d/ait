# Security Policy
**All India Taxes (AIT) · allindiataxes.com**
Version 1.0 · Effective 7 March 2026

---

## Purpose and Scope

This Security Policy describes the technical and organisational controls AIT applies to protect the Platform and the data of its users. It is aligned with SOC 2 Type II Trust Services Criteria and ISO/IEC 27001:2022.

This policy is public-facing and provides transparency to users, enterprise customers, CA firms, and auditors. It does not include implementation details that would aid attackers.

---

## 1. Security Principles

AIT's security posture is built on five principles:

1. **Least privilege** — every user, process, and service has the minimum access required to do its job
2. **Defence in depth** — multiple independent layers of control, so no single failure is catastrophic
3. **Audit everything** — all material actions are logged immutably; logs cannot be modified by users
4. **Encrypt at rest and in transit** — sensitive data is encrypted everywhere it is stored or moved
5. **Humans in the loop** — no autonomous action takes place on tax filings; every submission requires explicit human authorisation

---

## 2. Infrastructure Security

### 2.1 Hosting and Architecture
- Platform hosted on Render (application), Cloudflare Pages (frontend), Supabase (database and authentication), Cloudflare R2 (object storage)
- All environments (production, staging, development) are isolated — no shared credentials or network access between them
- Infrastructure-as-code used for all environment provisioning to ensure consistency and auditability

### 2.2 Network Security
- All traffic encrypted in transit using TLS 1.2 minimum (TLS 1.3 preferred)
- Cloudflare WAF (Web Application Firewall) protects all public-facing endpoints
- DDoS mitigation via Cloudflare — volumetric and application-layer attacks
- API endpoints rate-limited at the application layer (1,000 requests/hour per API key) and at the infrastructure layer
- Internal services communicate over private networks; no unnecessary public exposure

### 2.3 Data Encryption
- **In transit:** TLS 1.2+ for all data between clients and servers; TLS for all service-to-service communication
- **At rest — database:** Supabase encrypted storage with AES-256
- **At rest — sensitive credentials:** GSP credentials and TRACES passwords encrypted with AES-256-GCM; decrypted only in memory for the duration of a single API call; never logged; never returned in any API response
- **At rest — object storage:** Cloudflare R2 server-side encryption for all stored documents and exports

---

## 3. Access Control

### 3.1 User Access
- Role-based access control (RBAC) enforced at both application and database layers
- Supabase Row-Level Security (RLS) ensures per-entity data isolation — a user in Workspace A cannot access Workspace B's data even if they exploit an application-layer bug
- Workspace owners control user roles; users see only what their role permits
- Magic Link vendor submissions are isolated to the specific entity the link was created for — vendors cannot access any other entity data

### 3.2 Authentication
- Magic link OTP authentication — no stored passwords, eliminating password breach risk
- Account lockout after 5 consecutive failed login attempts (15-minute lockout)
- MFA enforcement available at workspace level — owners can require MFA for all workspace users
- Session tokens are short-lived and rotated; sessions time out on configurable idle period (15 minutes to 8 hours)

### 3.3 API Key Security
- API keys scoped to workspace or optionally to a single entity
- Full key shown once at creation and never stored in retrievable form; only the key prefix is stored
- Keys can be revoked instantly by workspace owners
- All API key usage is logged with timestamp, endpoint, and response code

### 3.4 Internal Access
- AIT employees access production systems only via authenticated, audited pathways
- Production database access by engineers is logged and reviewed
- Access is on a need-to-know basis; access rights are reviewed quarterly
- Offboarding procedures revoke access on the day of departure

---

## 4. Application Security

### 4.1 Secure Development
- Security review is part of the development process for all features touching sensitive data
- OWASP Top 10 addressed in development guidelines
- Dependencies scanned for known vulnerabilities on every build
- Secrets management: no credentials in source code; all secrets stored in environment-specific secret managers

### 4.2 Input Validation and Output Encoding
- All user inputs validated and sanitised server-side
- Parameterised queries used throughout — no raw SQL string construction
- Output encoding applied to prevent XSS
- CSRF protection on all state-changing requests (CSRF token cookie)

### 4.3 Magic Link Security
- HMAC-SHA256 signed tokens — cannot be forged or tampered with
- GSTIN binding: links can be bound to a specific vendor GSTIN; submissions from any other GSTIN are rejected
- Expiry enforced server-side; expired links return 410 Gone
- Use-count enforced atomically via Redis INCR — links cannot be used more times than their configured limit even under concurrent requests
- Deactivation is instantaneous; deactivated links return 410 Gone immediately

---

## 5. Audit Logging

AIT maintains comprehensive, immutable audit logs for all material events. Logs cannot be modified or deleted by any user, including workspace owners.

### 5.1 Events Logged
- User authentication (login, logout, failed attempts, MFA events)
- Role changes (user added, role modified, user removed)
- Entity changes (entity created, GSTIN updated)
- Invoice lifecycle events (created, submitted, reviewed, accepted, rejected, amended)
- Return events (draft created, reviewed, filed, rejected)
- API key events (created, used, revoked)
- Webhook events (sent, failed, retried)
- Consent changes (consent granted or withdrawn)
- Data export and deletion requests
- Admin actions on workspace configuration

### 5.2 Log Retention
- Security and audit logs retained for 5 years (SOC 2 CC7.2 / ISO 27001 A.8.15)
- Logs stored in append-only storage; no modification after write
- Workspace owners can export their workspace's audit log as CSV (Settings → Audit Log)

### 5.3 Log Access
- Users can view their own audit log entries in-Platform
- Workspace owners see all events in their workspace
- AIT operations team can access logs for security investigation; all such access is itself logged

---

## 6. Vulnerability Management

### 6.1 Penetration Testing
- Third-party penetration tests conducted at least annually by an independent security firm
- Critical findings (CVSS 9.0+) remediated within 7 days of identification
- High findings (CVSS 7.0–8.9) remediated within 30 days
- Medium/low findings remediated within 90 days
- Enterprise customers may request a summary of the most recent penetration test findings under NDA

### 6.2 Dependency Scanning
- Automated dependency vulnerability scanning on every build
- Critical CVEs in dependencies trigger an immediate patch cycle

### 6.3 Disclosure
- AIT participates in a responsible disclosure programme (see Document 05)
- Security reports: info@allindiataxes.com with subject `RESPONSIBLE DISCLOSURE`

---

## 7. Incident Response

### 7.1 Detection
- Real-time monitoring of infrastructure metrics, error rates, and anomalous API behaviour
- Alerts for failed login spikes, unusual data export volumes, and abnormal API usage patterns
- Cloudflare security alerts integrated into on-call monitoring

### 7.2 Response Process
AIT follows a structured incident response process:

1. **Detection** — automated alert or user report
2. **Triage** — on-call engineer assesses severity within 30 minutes (P1) / 2 hours (P2)
3. **Containment** — isolate affected systems; revoke compromised credentials if applicable
4. **Investigation** — root cause analysis using audit logs
5. **Remediation** — fix deployed; systems restored
6. **Notification** — affected workspace owners notified within 72 hours for breaches involving personal data
7. **Post-incident review** — blameless post-mortem within 5 business days; findings documented

### 7.3 Severity Levels
| Severity | Definition | Response Target |
|---|---|---|
| P1 — Critical | Data breach; complete service outage; active exploit | 30 minutes |
| P2 — High | Significant performance degradation; security anomaly | 2 hours |
| P3 — Medium | Feature outage; elevated error rates | 4 hours |
| P4 — Low | Minor issues; no user impact | Next business day |

### 7.4 Filing-Day Protocol
On GST due dates (typically the 11th and 20th of each month):
- Engineering on-call from 08:00–22:00 IST
- Stricter monitoring thresholds activated
- GSTN health status banner displayed for all users
- Deployment freeze from D-1 through D+1 (no code changes in production)

---

## 8. Business Continuity and Disaster Recovery

- Database backups taken daily with 30-day retention; point-in-time recovery available
- Object storage (Cloudflare R2) with regional redundancy for all uploaded documents
- Recovery Time Objective (RTO): 4 hours for P1 outages
- Recovery Point Objective (RPO): 1 hour (maximum data loss in a disaster scenario)
- Disaster recovery playbooks documented and tested biannually

---

## 9. Supplier and Sub-Processor Security

- All sub-processors vetted for security certifications before onboarding
- Sub-processors required to maintain at minimum SOC 2 Type II or ISO 27001 certification
- Data Processing Agreements (DPAs) in place with all sub-processors
- Sub-processor security posture reviewed annually

Full sub-processor list with certifications is in Document 09.

---

## 10. Physical Security

AIT is a cloud-native company with no physical data centres. All physical infrastructure is operated by our cloud providers (Cloudflare, Supabase, Render) who maintain SOC 2 and ISO 27001 certified facilities. Remote-working employees are required to use encrypted devices and secure networks.

---

## 11. Employee Security

- Background checks for all employees with access to production systems
- Security awareness training for all employees at onboarding and annually thereafter
- Acceptable use policy for company devices and systems
- Mandatory reporting of suspected security incidents to info@allindiataxes.com

---

## 12. Compliance and Certification Roadmap

| Framework | Current Status | Target |
|---|---|---|
| SOC 2 Type I | In preparation | Q4 2026 |
| SOC 2 Type II | Planned | Q2 2027 |
| ISO/IEC 27001:2022 | Controls implemented; certification planned | Q1 2027 |
| DPDP Act 2023 | Compliant (see Document 07) | Ongoing |
| GDPR / UK GDPR | Compliant (see Document 08) | Ongoing |

Enterprise customers requiring evidence of security controls (SOC 2 reports, pen test summaries, ISO 27001 evidence) should contact sales@allindiataxes.com.

---

## 13. Contact

Security reports and responsible disclosure: info@allindiataxes.com — subject `RESPONSIBLE DISCLOSURE`
Enterprise security enquiries: sales@allindiataxes.com
General security questions: info@allindiataxes.com

---

*All India Taxes · allindiataxes.com*
*Version 1.0 · 7 March 2026*
*Aligned with: SOC 2 Trust Services Criteria · ISO/IEC 27001:2022 · DPDP Act 2023*
