const fs = require("fs");
const net = require("net");
const path = require("path");
const { spawn } = require("child_process");

const PORT = Number(process.env.PORT || 3010);
const lockPath = path.join(process.cwd(), ".next", "dev", "lock");

function isPortOpen(port) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    socket.setTimeout(1000);
    socket.once("connect", () => {
      socket.destroy();
      resolve(true);
    });
    socket.once("timeout", () => {
      socket.destroy();
      resolve(false);
    });
    socket.once("error", () => {
      resolve(false);
    });
    socket.connect(port, "127.0.0.1");
  });
}

async function main() {
  const inUse = await isPortOpen(PORT);
  if (inUse) {
    console.error(
      `Port ${PORT} is already in use. Stop the existing dev server before starting a new one.`
    );
    process.exit(1);
  }

  if (fs.existsSync(lockPath)) {
    fs.rmSync(lockPath, { force: true });
  }

  const nextBin = require.resolve("next/dist/bin/next");
  const child = spawn(
    process.execPath,
    [nextBin, "dev", "--webpack", "-H", "127.0.0.1", "-p", String(PORT)],
    {
      stdio: "inherit",
      env: {
        ...process.env,
        WATCHPACK_POLLING: "true",
      },
    }
  );

  child.on("exit", (code, signal) => {
    if (signal) process.kill(process.pid, signal);
    process.exit(code || 0);
  });
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
