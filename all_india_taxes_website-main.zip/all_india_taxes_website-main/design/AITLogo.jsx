export default function AITLogo({ className = "", size = "md" }) {
  const sizes = {
    sm: { width: 130, height: 80 },
    md: { width: 182, height: 112 },
    lg: { width: 260, height: 160 },
  };
  const { width, height } = sizes[size] || sizes.md;

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={width}
      height={height}
      viewBox="0 0 520 320"
      className={className}
      aria-label="AIT - All India Taxes"
      role="img"
    >
      <defs>
        <style>{`
          @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=Outfit:wght@500&display=swap');
          .ait-logo-main {
            font-family: 'DM Serif Display', Georgia, serif;
            font-size: 170px;
            font-weight: 400;
            letter-spacing: -2.5px;
            fill: #C6A85E;
          }
          .ait-logo-sub {
            font-family: 'Outfit', sans-serif;
            font-size: 22px;
            font-weight: 500;
            letter-spacing: 2.2px;
            fill: #8A9AB0;
          }
        `}</style>
        {/* Circuit line decorations */}
        <filter id="glow">
          <feGaussianBlur stdDeviation="2" result="coloredBlur" />
          <feMerge>
            <feMergeNode in="coloredBlur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* Gold circuit accent lines */}
      <line x1="36" y1="162" x2="136" y2="162" stroke="#C6A85E" strokeWidth="1.5" strokeOpacity="0.35" />
      <circle cx="36" cy="162" r="3" fill="#C6A85E" fillOpacity="0.5" />
      <line x1="136" y1="162" x2="136" y2="130" stroke="#C6A85E" strokeWidth="1.5" strokeOpacity="0.35" />
      <circle cx="136" cy="130" r="3" fill="#C6A85E" fillOpacity="0.5" />

      <line x1="484" y1="162" x2="384" y2="162" stroke="#C6A85E" strokeWidth="1.5" strokeOpacity="0.35" />
      <circle cx="484" cy="162" r="3" fill="#C6A85E" fillOpacity="0.5" />
      <line x1="384" y1="162" x2="384" y2="130" stroke="#C6A85E" strokeWidth="1.5" strokeOpacity="0.35" />
      <circle cx="384" cy="130" r="3" fill="#C6A85E" fillOpacity="0.5" />

      <text className="ait-logo-main" x="260" y="178" textAnchor="middle">
        AIT
      </text>
      <text className="ait-logo-sub" x="260" y="218" textAnchor="middle">
        ALL INDIA TAXES
      </text>
    </svg>
  );
}
