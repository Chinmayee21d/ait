"use client";
import { useState, useEffect } from "react";
import AITLogo from "./AITLogo";
import OTPInput from "./OTPInput";
import { globalStyles, validateEmail, injectStyles } from "./aitAuthUtils";

export default function AITViewDemo({
  deckUrl = "/files/AIT-PitchDeck-2025.pdf",
  onSuccess,
  mockOTP = null,
  className = "",
}) {
  useEffect(() => injectStyles("ait-auth-styles", globalStyles), []);

  const [step, setStep] = useState("gate");
  const [form, setForm] = useState({ name: "", email: "", company: "" });
  const [errors, setErrors] = useState({});
  const [otp, setOtp] = useState("");
  const [otpError, setOtpError] = useState("");
  const [loading, setLoading] = useState(false);
  const [resendTimer, setResendTimer] = useState(0);
  const [downloadStarted, setDownloadStarted] = useState(false);
  const [unlockedUrl, setUnlockedUrl] = useState(deckUrl);

  useEffect(() => {
    if (resendTimer <= 0) return;
    const t = setTimeout(() => setResendTimer((r) => r - 1), 1000);
    return () => clearTimeout(t);
  }, [resendTimer]);

  const setField = (key, value) => {
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((e) => ({ ...e, [key]: "" }));
  };

  const validateGate = () => {
    const errs = {};
    if (!form.name.trim()) errs.name = "Required";
    if (!validateEmail(form.email)) errs.email = "Enter a valid work email";
    if (!form.company.trim()) errs.company = "Required";
    return errs;
  };

  const handleGateSubmit = async (e) => {
    e?.preventDefault();
    const errs = validateGate();
    if (Object.keys(errs).length) {
      setErrors(errs);
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/otp/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: form.email.trim(), purpose: "demo" }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to send OTP. Please try again.");
      setStep("otp");
      setResendTimer(30);
    } catch (err) {
      setErrors({ email: err?.message || "Failed to send OTP. Please try again." });
    }
    setLoading(false);
  };

  const handleOTPSubmit = async (e) => {
    e?.preventDefault();
    if (otp.length < 6) {
      setOtpError("Enter the 6-digit code sent to your email.");
      return;
    }

    setOtpError("");
    setLoading(true);
    try {
      if (mockOTP && otp !== mockOTP) throw new Error("Invalid or expired code. Try again.");
      const res = await fetch("/api/otp/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: form.email.trim(),
          code: otp,
          purpose: "demo",
          payload: form,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Verification failed. Please try again.");
      setStep("unlocked");
      if (data.downloadUrl) setUnlockedUrl(data.downloadUrl);
      onSuccess?.({ ...form, ...(data.user || {}) });
    } catch (err) {
      setOtpError(err?.message || "Verification failed. Please try again.");
    }
    setLoading(false);
  };

  const handleResend = async () => {
    if (resendTimer > 0) return;
    setOtp("");
    setOtpError("");

    setLoading(true);
    try {
      const res = await fetch("/api/otp/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: form.email.trim(), purpose: "demo" }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to resend OTP.");
      setResendTimer(30);
    } catch {
      setOtpError("Could not resend code. Please try again.");
    }
    setLoading(false);
  };

  const triggerDownload = () => {
    setDownloadStarted(true);
    const a = document.createElement("a");
    a.href = unlockedUrl;
    a.download = "AIT-Demo-Brief.pdf";
    a.click();
  };

  const highlights = [
    { stat: "7 min", label: "guided product tour", sub: "finance workflow to filing" },
    { stat: "99.8%", label: "reconciliation accuracy", sub: "vs 60-70% manual" },
    { stat: "3 modules", label: "core demo walkthrough", sub: "reco, risk, response" },
    { stat: "10x", label: "faster turnaround", sub: "5 days -> under 2 hours" },
  ];

  const pages = [
    { num: "01", title: "Invoice to 2B Reconciliation", desc: "Find and resolve mismatches quickly" },
    { num: "02", title: "Vendor Risk Intelligence", desc: "Monitor compliance drift before it hurts ITC" },
    { num: "03", title: "Notice and Action Workflow", desc: "Route tasks with owner-level accountability" },
    { num: "04", title: "AI Tax Copilot", desc: "Ask questions, forecast impact, and prioritize action" },
  ];

  return (
    <div className={className} style={pageStyle}>
      <BackgroundDecor />
      <div style={{ width: "100%", maxWidth: 940, position: "relative", zIndex: 1, display: "flex", flexDirection: "column", alignItems: "center" }}>
        <div style={{ marginBottom: 16 }}>
          <AITLogo size="md" />
        </div>

        <div className="ait-view-grid" style={shellStyle}>
          <div style={leftPanelStyle}>
            <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 1, background: "linear-gradient(90deg, transparent, rgba(198,168,94,0.4), transparent)" }} />
            <p style={{ fontFamily: "'DM Serif Display', serif", fontSize: 28, color: "#f0ece4", margin: "0 0 8px", lineHeight: 1.3 }}>
              View the AIT product demo
              <br />
              <span style={{ color: "#C6A85E" }}>in one click</span>
            </p>
            <p style={{ fontFamily: "'Outfit', sans-serif", fontSize: 14, color: "#8A9AB0", marginBottom: 18, lineHeight: 1.6 }}>
              Get instant access to the on-demand demo and a short implementation brief.
            </p>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 22 }}>
              {highlights.map((h) => (
                <div key={h.stat} style={{ padding: 12, background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 10 }}>
                  <p style={{ fontFamily: "'DM Serif Display', serif", fontSize: 20, color: "#C6A85E", margin: "0 0 2px" }}>{h.stat}</p>
                  <p style={{ fontFamily: "'Outfit', sans-serif", fontSize: 11, fontWeight: 600, color: "#f0ece4", margin: "0 0 2px" }}>{h.label}</p>
                  <p style={{ fontFamily: "'Outfit', sans-serif", fontSize: 11, color: "rgba(138,154,176,0.8)", margin: 0 }}>{h.sub}</p>
                </div>
              ))}
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {pages.map((p) => (
                <div key={p.num} style={{ display: "flex", gap: 12, alignItems: "flex-start", padding: "10px 12px", background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.05)", borderRadius: 10 }}>
                  <span style={{ fontFamily: "'DM Serif Display', serif", fontSize: 14, color: "rgba(198,168,94,0.5)", flexShrink: 0, width: 22 }}>{p.num}</span>
                  <div>
                    <p style={{ fontFamily: "'Outfit', sans-serif", fontSize: 13, fontWeight: 600, color: "#d0ccc4", margin: "0 0 2px" }}>{p.title}</p>
                    <p style={{ fontFamily: "'Outfit', sans-serif", fontSize: 12, color: "rgba(138,154,176,0.7)", margin: 0 }}>{p.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div style={rightPanelStyle}>
            {step === "gate" && (
              <>
                <h2 style={{ fontFamily: "'Outfit', sans-serif", fontSize: 18, fontWeight: 600, color: "#f0ece4", margin: "0 0 18px" }}>Get instant demo access</h2>
                <form onSubmit={handleGateSubmit}>
                  <div style={{ marginBottom: 12 }}>
                    <label className="ait-label" htmlFor="view-name">Your Name*</label>
                    <input id="view-name" className={`ait-field ${errors.name ? "error" : ""}`} placeholder="Rohan Sharma" value={form.name} onChange={(e) => setField("name", e.target.value)} autoFocus />
                    {errors.name && <div className="ait-error-msg">{errors.name}</div>}
                  </div>
                  <div style={{ marginBottom: 12 }}>
                    <label className="ait-label" htmlFor="view-company">Company*</label>
                    <input id="view-company" className={`ait-field ${errors.company ? "error" : ""}`} placeholder="Acme Pvt. Ltd." value={form.company} onChange={(e) => setField("company", e.target.value)} />
                    {errors.company && <div className="ait-error-msg">{errors.company}</div>}
                  </div>
                  <div style={{ marginBottom: 24 }}>
                    <label className="ait-label" htmlFor="view-email">Work Email*</label>
                    <input id="view-email" className={`ait-field ${errors.email ? "error" : ""}`} type="email" placeholder="you@company.com" value={form.email} onChange={(e) => setField("email", e.target.value)} />
                    {errors.email && <div className="ait-error-msg"><ErrorIcon /> {errors.email}</div>}
                  </div>
                  <button className="ait-btn-primary" type="submit" disabled={loading}>
                    {loading ? <><span className="ait-spinner" />&nbsp;Sending code...</> : "Send OTP and continue ->"}
                  </button>
                </form>
              </>
            )}

            {step === "otp" && (
              <div className="ait-auth-card" style={{ maxWidth: 420, boxShadow: "none", border: "none", padding: 0, background: "transparent" }}>
                <button onClick={() => { setStep("gate"); setOtp(""); setOtpError(""); }} style={backBtnStyle}>{"<- Back"}</button>
                <h1 style={headingStyle}>Verify your email</h1>
                  <p style={subStyle}>We sent a 6-digit code to <strong style={{ color: "#C6A85E" }}>{form.email}</strong></p>
                <form onSubmit={handleOTPSubmit} style={{ marginTop: 24 }}>
                  <OTPInput value={otp} onChange={setOtp} error={!!otpError} disabled={loading} />
                  {otpError && <div className="ait-error-msg" style={{ justifyContent: "center", marginTop: 10 }}><ErrorIcon /> {otpError}</div>}
                  <button className="ait-btn-primary" type="submit" disabled={loading || otp.length < 6} style={{ marginTop: 24 }}>
                    {loading ? <><span className="ait-spinner" />&nbsp;Verifying...</> : "Unlock demo access"}
                  </button>
                </form>
                <div style={{ textAlign: "center", marginTop: 16, fontSize: 13, color: "#8A9AB0", fontFamily: "'Outfit', sans-serif" }}>
                  Didn't receive it?{" "}
                  {resendTimer > 0 ? <span>Resend in {resendTimer}s</span> : (
                    <button onClick={handleResend} style={{ background: "none", border: "none", color: "#C6A85E", cursor: "pointer", fontWeight: 600, fontFamily: "inherit", fontSize: "inherit" }}>Resend</button>
                  )}
                </div>
              </div>
            )}

            {step === "unlocked" && (
              <div className="ait-auth-card" style={{ maxWidth: 440, textAlign: "center", boxShadow: "none", border: "none", padding: 0, background: "transparent" }}>
                <div style={{ width: 64, height: 64, borderRadius: "50%", background: "rgba(198,168,94,0.12)", border: "1.5px solid rgba(198,168,94,0.3)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 24px" }}>
                  <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
                    <path d="M8 14l4 4 8-8" stroke="#C6A85E" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
                <h1 style={{ ...headingStyle, fontSize: 24 }}>Demo unlocked</h1>
                <p style={{ ...subStyle, marginTop: 12 }}>
                  Thanks, <strong style={{ color: "#f0ece4" }}>{form.name}</strong>. Your demo access is active now.
                </p>
                <button className="ait-btn-primary" onClick={triggerDownload} style={{ marginTop: 20 }}>
                  {downloadStarted ? "Downloading..." : "Download implementation brief"}
                </button>
                <a href={unlockedUrl} target="_blank" rel="noopener noreferrer" className="ait-btn-ghost" style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8, textDecoration: "none", width: "100%", boxSizing: "border-box", marginTop: 12 }}>
                  Open in browser
                </a>
              </div>
            )}
          </div>
        </div>
      </div>

      <style>{`
        @media (max-width: 920px) {
          .ait-view-grid { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </div>
  );
}

function ErrorIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" style={{ flexShrink: 0 }}>
      <circle cx="6" cy="6" r="5.5" stroke="currentColor" />
      <path d="M6 3.5v3M6 8h.01" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}

function BackgroundDecor() {
  return (
    <div style={{ position: "fixed", inset: 0, overflow: "hidden", zIndex: 0, pointerEvents: "none" }}>
      <div style={{ position: "absolute", top: "5%", right: "-5%", width: "55vw", height: "55vw", borderRadius: "50%", background: "radial-gradient(circle, rgba(21,59,111,0.35) 0%, transparent 70%)" }} />
      <div style={{ position: "absolute", bottom: "0%", left: "0%", width: "45vw", height: "45vw", borderRadius: "50%", background: "radial-gradient(circle, rgba(198,168,94,0.05) 0%, transparent 70%)" }} />
    </div>
  );
}

const pageStyle = { minHeight: "100vh", background: "#080e1c", display: "flex", alignItems: "center", justifyContent: "center", padding: "20px 16px", position: "relative" };
const shellStyle = { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 0, width: "100%", maxWidth: 900, background: "linear-gradient(145deg, #111d35 0%, #0d1829 100%)", border: "1px solid rgba(198,168,94,0.18)", borderRadius: 24, overflow: "hidden", boxShadow: "0 40px 80px rgba(0,0,0,0.6)" };
const leftPanelStyle = { padding: "34px 28px", borderRight: "1px solid rgba(198,168,94,0.1)", position: "relative" };
const rightPanelStyle = { padding: "34px 28px", display: "flex", flexDirection: "column", justifyContent: "center" };
const headingStyle = { fontFamily: "'DM Serif Display', Georgia, serif", fontSize: 26, fontWeight: 400, color: "#f0ece4", margin: 0, textAlign: "center" };
const subStyle = { fontFamily: "'Outfit', sans-serif", fontSize: 14, color: "#8A9AB0", textAlign: "center", margin: "8px 0 0", lineHeight: 1.6 };
const backBtnStyle = { background: "none", border: "none", color: "#8A9AB0", cursor: "pointer", fontFamily: "'Outfit', sans-serif", fontSize: 13, padding: 0, marginBottom: 20, display: "block" };
