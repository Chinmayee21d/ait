"use client";
import { useState, useEffect } from "react";
import AITLogo from "./AITLogo";
import OTPInput from "./OTPInput";
import { globalStyles, validateEmail, injectStyles } from "./aitAuthUtils";
import { pushAnalyticsEvent } from "@/lib/analytics";
import { CONSENT_VERSION } from "@/lib/consent";

/**
 * AITSignUp - Sign Up / Registration page for AIT
 *
 * Usage in Next.js:
 *   import AITSignUp from "@/components/auth/AITSignUp";
 *   <AITSignUp onSuccess={(user) => router.push("/onboarding")} onSignInClick={() => router.push("/signin")} />
 *
 * Props:
 *   onSuccess(userData) - called after account created & OTP verified
 *   onSignInClick() - navigate to sign in
 *   mockOTP - "123456" for dev testing
 */
export default function AITSignUp({
  onSuccess,
  onSignInClick,
  mockOTP = null,
  className = "",
}) {
  useEffect(() => injectStyles("ait-auth-styles", globalStyles), []);

  const [step, setStep] = useState("details"); // "details" | "otp"
  const [form, setForm] = useState({
    name: "",
    company: "",
    email: "",
    role: "",
    legalAccepted: false,
    analyticsConsent: false,
    marketingConsent: false,
    aiTrainingConsent: false,
  });
  const [errors, setErrors] = useState({});
  const [otp, setOtp] = useState("");
  const [otpError, setOtpError] = useState("");
  const [loading, setLoading] = useState(false);
  const [resendTimer, setResendTimer] = useState(0);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    if (resendTimer <= 0) return;
    const t = setTimeout(() => setResendTimer((r) => r - 1), 1000);
    return () => clearTimeout(t);
  }, [resendTimer]);

  const setField = (key, value) => {
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((e) => ({ ...e, [key]: "" }));
  };

  const validateDetails = () => {
    const errs = {};
    if (!form.name.trim()) errs.name = "Full name is required.";
    if (!form.company.trim()) errs.company = "Company name is required.";
    if (!validateEmail(form.email)) errs.email = "Enter a valid work email.";
    if (!form.role) errs.role = "Please select your role.";
    if (!form.legalAccepted) errs.legalAccepted = "You must accept the Terms and Privacy Policy.";
    return errs;
  };

  const handleDetailsSubmit = async (e) => {
    e?.preventDefault();
    const errs = validateDetails();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setLoading(true);
    try {
      const res = await fetch("/api/otp/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: form.email.trim(), purpose: "signup" }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to send OTP.");
      setStep("otp");
      setResendTimer(30);
      pushAnalyticsEvent("otp_send", { flow: "sign_up" });
    } catch {
      setErrors({ email: "Registration failed. Please try again." });
    }
    setLoading(false);
  };

  const handleOTPSubmit = async (e) => {
    e?.preventDefault();
    if (otp.length < 6) { setOtpError("Enter the 6-digit code sent to your email."); return; }
    setOtpError("");
    setLoading(true);
    try {
      if (mockOTP && otp !== mockOTP) throw new Error("Invalid or expired code. Please try again.");
      const res = await fetch("/api/otp/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: form.email.trim(),
          code: otp,
          purpose: "signup",
          payload: {
            ...form,
            consentReceipt: {
              version: CONSENT_VERSION,
              source: "website_sign_up",
              timestamp: new Date().toISOString(),
              categories: {
                essential: true,
                legal: form.legalAccepted,
                analytics: form.analyticsConsent,
                marketing: form.marketingConsent,
                ai_training: form.aiTrainingConsent,
              },
            },
          },
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Verification failed. Please try again.");
      setSuccess(true);
      pushAnalyticsEvent("otp_verify_success", {
        flow: "sign_up",
        role: form.role || "unknown",
      });
      await new Promise((r) => setTimeout(r, 600));
      onSuccess?.(data.user || { ...form });
    } catch (err) {
      setOtpError(err?.message || "Verification failed. Please try again.");
    }
    setLoading(false);
  };

  const handleResend = async () => {
    if (resendTimer > 0) return;
    setOtp(""); setOtpError("");
    setLoading(true);
    try {
      const res = await fetch("/api/otp/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: form.email.trim(), purpose: "signup" }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to resend OTP.");
      setResendTimer(30);
      pushAnalyticsEvent("otp_send", { flow: "sign_up", source: "resend" });
    } catch {
      setOtpError("Could not resend code. Please try again.");
    }
    setLoading(false);
  };

  const roles = [
    "CFO / Finance Head",
    "Tax Manager",
    "CA / Tax Consultant",
    "Business Owner",
    "Accounts Manager",
    "Other",
  ];

  const allConsentsSelected =
    form.legalAccepted &&
    form.analyticsConsent &&
    form.marketingConsent &&
    form.aiTrainingConsent;

  const setAllConsents = (checked) => {
    setForm((f) => ({
      ...f,
      legalAccepted: checked,
      analyticsConsent: checked,
      marketingConsent: checked,
      aiTrainingConsent: checked,
    }));
    if (checked) {
      setErrors((e) => ({ ...e, legalAccepted: "" }));
    }
  };

  return (
    <div className={className} style={pageStyle}>
      <BackgroundDecor />
      <div className="ait-auth-card" style={{ maxWidth: 450 }}>
        <div style={{ textAlign: "center", marginBottom: 14 }}>
          <AITLogo size="md" />
        </div>

        {step === "details" ? (
          <>
            <h1 style={headingStyle}>Create your account</h1>
            <p style={subStyle}>Join thousands of finance teams on AIT</p>

            <form onSubmit={handleDetailsSubmit} style={{ marginTop: 18 }}>
              {/* Name + Company row */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 14 }}>
                <div>
                  <label className="ait-label" htmlFor="signup-name">Full Name</label>
                  <input
                    id="signup-name"
                    className={`ait-field ${errors.name ? "error" : ""}`}
                    placeholder="Rohan Sharma"
                    value={form.name}
                    onChange={(e) => setField("name", e.target.value)}
                    autoFocus
                  />
                  {errors.name && <div className="ait-error-msg">{errors.name}</div>}
                </div>
                <div>
                  <label className="ait-label" htmlFor="signup-company">Company</label>
                  <input
                    id="signup-company"
                    className={`ait-field ${errors.company ? "error" : ""}`}
                    placeholder="Acme Pvt. Ltd."
                    value={form.company}
                    onChange={(e) => setField("company", e.target.value)}
                  />
                  {errors.company && <div className="ait-error-msg">{errors.company}</div>}
                </div>
              </div>

              <div style={{ marginBottom: 14 }}>
                <label className="ait-label" htmlFor="signup-email">Work Email</label>
                <input
                  id="signup-email"
                  className={`ait-field ${errors.email ? "error" : ""}`}
                  type="email"
                  placeholder="you@company.com"
                  value={form.email}
                  onChange={(e) => setField("email", e.target.value)}
                  autoComplete="email"
                />
                {errors.email && (
                  <div className="ait-error-msg">
                    <ErrorIcon /> {errors.email}
                  </div>
                )}
              </div>

              <div style={{ marginBottom: 18 }}>
                <label className="ait-label" htmlFor="signup-role">Your Role</label>
                <select
                  id="signup-role"
                  className={`ait-field ${errors.role ? "error" : ""}`}
                  value={form.role}
                  onChange={(e) => setField("role", e.target.value)}
                  style={{ cursor: "pointer", appearance: "none", backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8' fill='none'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%238A9AB0' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")`, backgroundRepeat: "no-repeat", backgroundPosition: "calc(100% - 14px) center" }}
                >
                  <option value="">Select your role…</option>
                  {roles.map((r) => <option key={r} value={r}>{r}</option>)}
                </select>
                {errors.role && <div className="ait-error-msg">{errors.role}</div>}
              </div>

              <div style={{ marginBottom: 14, border: "1px solid rgba(198,168,94,0.2)", borderRadius: 12, padding: "10px 10px 4px", background: "rgba(255,255,255,0.02)" }}>
                <p style={{ fontFamily: "'Outfit', sans-serif", fontSize: 10.5, color: "#C6A85E", margin: "0 0 6px", letterSpacing: "0.6px", fontWeight: 600 }}>
                  CONSENT PREFERENCES
                </p>

                <label style={consentRowStyle}>
                  <input
                    type="checkbox"
                    checked={allConsentsSelected}
                    onChange={(e) => setAllConsents(e.target.checked)}
                    style={consentCheckboxStyle}
                  />
                  <span style={{ ...consentTextStyle, color: "#C6A85E", fontWeight: 600 }}>
                    Sign all consent options
                  </span>
                </label>
                <div
                  style={{
                    height: 1,
                    background: "linear-gradient(90deg, transparent, rgba(198,168,94,0.22), transparent)",
                    margin: "4px 0 7px",
                  }}
                />
                <label style={consentRowStyle}>
                  <input
                    type="checkbox"
                    checked={form.legalAccepted}
                    onChange={(e) => setField("legalAccepted", e.target.checked)}
                    style={consentCheckboxStyle}
                  />
                  <span style={{ ...consentTextStyle, color: errors.legalAccepted ? "#ef4444" : consentTextStyle.color }}>
                    I agree to the <a href="/terms" style={consentLinkStyle}>Terms of Service</a> and <a href="/privacy" style={consentLinkStyle}>Privacy Policy</a>{" "}and{" "}<a href="/cookie-policy" style={{ color: "rgba(198,168,94,0.5)", textDecoration: "none" }}>Cookie Policy</a>.*
                  </span>
                </label>
                {errors.legalAccepted && <div className="ait-error-msg">{errors.legalAccepted}</div>}

                <label style={consentRowStyle}>
                  <input
                    type="checkbox"
                    checked={form.analyticsConsent}
                    onChange={(e) => setField("analyticsConsent", e.target.checked)}
                    style={consentCheckboxStyle}
                  />
                  <span style={consentTextStyle}>I consent to analytics cookies and product usage measurement.</span>
                </label>

                <label style={consentRowStyle}>
                  <input
                    type="checkbox"
                    checked={form.marketingConsent}
                    onChange={(e) => setField("marketingConsent", e.target.checked)}
                    style={consentCheckboxStyle}
                  />
                  <span style={consentTextStyle}>I consent to receive marketing and product updates by email.</span>
                </label>

                <label style={consentRowStyle}>
                  <input
                    type="checkbox"
                    checked={form.aiTrainingConsent}
                    onChange={(e) => setField("aiTrainingConsent", e.target.checked)}
                    style={consentCheckboxStyle}
                  />
                  <span style={consentTextStyle}>I consent to optional use of my data for AI workflow improvements.</span>
                </label>
              </div>

              <button className="ait-btn-primary" type="submit" disabled={loading}>
                {loading ? <><span className="ait-spinner" />&nbsp;Creating account…</> : "Create Account & Get OTP →"}
              </button>
            </form>

            {onSignInClick && (
              <p style={{ textAlign: "center", marginTop: 14, fontSize: 14, color: "#8A9AB0", fontFamily: "'Outfit', sans-serif" }}>
                Already have an account?{" "}
                <button onClick={onSignInClick} style={{ background: "none", border: "none", color: "#C6A85E", cursor: "pointer", fontWeight: 600, fontFamily: "inherit", fontSize: "inherit" }}>
                  Sign in
                </button>
              </p>
            )}
          </>
        ) : (
          <>
            <button onClick={() => { setStep("details"); setOtp(""); setOtpError(""); }} style={backBtnStyle}>
              ← Back
            </button>
            <h1 style={headingStyle}>Verify your email</h1>
            <p style={subStyle}>
              A 6-digit code was sent to<br />
              <strong style={{ color: "#C6A85E", fontWeight: 600 }}>{form.email}</strong>
            </p>

            <form onSubmit={handleOTPSubmit} style={{ marginTop: 28 }}>
              <OTPInput value={otp} onChange={setOtp} error={!!otpError} disabled={loading || success} />
              {otpError && (
                <div className="ait-error-msg" style={{ justifyContent: "center", marginTop: 10 }}>
                  <ErrorIcon /> {otpError}
                </div>
              )}
              <button className="ait-btn-primary" type="submit" disabled={loading || success || otp.length < 6} style={{ marginTop: 24 }}>
                {success ? <><CheckIcon /> Account Created!</> : loading ? <><span className="ait-spinner" />&nbsp;Verifying…</> : "Verify & Create Account"}
              </button>
            </form>

            <div style={{ textAlign: "center", marginTop: 16, fontSize: 13, color: "#8A9AB0", fontFamily: "'Outfit', sans-serif" }}>
              Didn't receive it?{" "}
              {resendTimer > 0 ? <span>Resend in {resendTimer}s</span> : (
                <button onClick={handleResend} style={{ background: "none", border: "none", color: "#C6A85E", cursor: "pointer", fontWeight: 600, fontFamily: "inherit", fontSize: "inherit" }}>Resend code</button>
              )}
            </div>
          </>
        )}

        <p style={{ textAlign: "center", marginTop: 14, fontSize: 10.5, color: "rgba(138,154,176,0.4)", fontFamily: "'Outfit', sans-serif", lineHeight: 1.4 }}>
          By creating an account, you agree to AIT's{" "}
          <a href="/terms" style={{ color: "rgba(198,168,94,0.5)", textDecoration: "none" }}>Terms of Service</a>{" "}and{" "}
          <a href="/privacy" style={{ color: "rgba(198,168,94,0.5)", textDecoration: "none" }}>Privacy Policy</a>{" "}and{" "}<a href="/cookie-policy" style={{ color: "rgba(198,168,94,0.5)", textDecoration: "none" }}>Cookie Policy</a>
        </p>
      </div>
    </div>
  );
}

function ErrorIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" style={{ flexShrink: 0 }}>
      <circle cx="6" cy="6" r="5.5" stroke="currentColor" />
      <path d="M6 3.5v3M6 8h.01" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}
function CheckIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" style={{ flexShrink: 0 }}>
      <circle cx="9" cy="9" r="8.5" stroke="rgba(15,30,61,0.4)" />
      <path d="M5.5 9l2.5 2.5 4.5-5" stroke="#0f1e3d" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
function BackgroundDecor() {
  return (
    <div style={{ position: "fixed", inset: 0, overflow: "hidden", zIndex: 0, pointerEvents: "none" }}>
      <div style={{ position: "absolute", top: "-20%", left: "-10%", width: "60vw", height: "60vw", borderRadius: "50%", background: "radial-gradient(circle, rgba(21,59,111,0.4) 0%, transparent 70%)" }} />
      <div style={{ position: "absolute", bottom: "-20%", right: "-10%", width: "50vw", height: "50vw", borderRadius: "50%", background: "radial-gradient(circle, rgba(198,168,94,0.06) 0%, transparent 70%)" }} />
    </div>
  );
}

const pageStyle = { minHeight: "100vh", background: "#080e1c", display: "flex", alignItems: "center", justifyContent: "center", padding: "14px 14px", position: "relative" };
const headingStyle = { fontFamily: "'DM Serif Display', Georgia, serif", fontSize: 26, fontWeight: 400, color: "#f0ece4", margin: 0, textAlign: "center" };
const subStyle = { fontFamily: "'Outfit', sans-serif", fontSize: 14, color: "#8A9AB0", textAlign: "center", margin: "6px 0 0", lineHeight: 1.45 };
const backBtnStyle = { background: "none", border: "none", color: "#8A9AB0", cursor: "pointer", fontFamily: "'Outfit', sans-serif", fontSize: 13, padding: 0, marginBottom: 20, display: "block" };
const consentRowStyle = { display: "flex", alignItems: "center", gap: 6, marginBottom: 6 };
const consentCheckboxStyle = { marginTop: 0, width: 13, height: 13, flexShrink: 0 };
const consentTextStyle = { fontFamily: "'Outfit', sans-serif", fontSize: 9.5, color: "#8A9AB0", lineHeight: 1.2, whiteSpace: "nowrap" };
const consentLinkStyle = { color: "#C6A85E", textDecoration: "none" };
