// Shared styles for AIT auth components
// Import this in your global CSS or use with CSS modules

export const aitColors = {
  navy: "#0f1e3d",
  navyMid: "#153B6F",
  gold: "#C6A85E",
  goldLight: "#d9bc7e",
  cream: "#f9f7f3",
  slate: "#8A9AB0",
  error: "#ef4444",
  success: "#22c55e",
};

export const globalStyles = `
  @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=Outfit:wght@300;400;500;600&display=swap');

  .ait-auth-overlay {
    position: fixed;
    inset: 0;
    background: rgba(8, 14, 28, 0.85);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    z-index: 1000;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 16px;
    animation: ait-fade-in 0.25s ease;
  }

  .ait-auth-card {
    background: linear-gradient(145deg, #111d35 0%, #0d1829 100%);
    border: 1px solid rgba(198,168,94,0.18);
    border-radius: 20px;
    width: 100%;
    max-width: 460px;
    padding: 30px 28px 24px;
    position: relative;
    box-shadow: 0 40px 80px rgba(0,0,0,0.6), 0 0 0 1px rgba(255,255,255,0.04) inset;
    animation: ait-slide-up 0.35s cubic-bezier(0.22, 1, 0.36, 1);
    color-scheme: dark;
  }
  .ait-auth-page {
    color-scheme: dark;
  }

  .ait-auth-card::before {
    content: '';
    position: absolute;
    top: 0; left: 50%; transform: translateX(-50%);
    width: 60%;
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(198,168,94,0.5), transparent);
  }

  .ait-field {
    width: 100%;
    background: rgba(255,255,255,0.04);
    border: 1.5px solid rgba(255,255,255,0.1);
    border-radius: 10px;
    padding: 14px 16px;
    font-size: 15px;
    font-family: 'Outfit', sans-serif;
    color: #f0ece4;
    outline: none;
    transition: all 0.2s ease;
    box-sizing: border-box;
    caret-color: #C6A85E;
  }
  .ait-field::placeholder { color: rgba(138,154,176,0.6); }
  .ait-field:focus {
    border-color: #C6A85E;
    background: rgba(198,168,94,0.06);
    box-shadow: 0 0 0 3px rgba(198,168,94,0.12);
  }
  .ait-field.error {
    border-color: #ef4444;
    box-shadow: 0 0 0 3px rgba(239,68,68,0.12);
  }
  select.ait-field {
    color: #f0ece4;
    background-color: rgba(255,255,255,0.04);
  }
  select.ait-field option {
    color: #f0ece4;
    background: #0f1e3d;
  }
  select.ait-field optgroup {
    color: #f0ece4;
    background: #0f1e3d;
  }

  .ait-btn-primary {
    width: 100%;
    background: linear-gradient(135deg, #C6A85E, #d9bc7e);
    color: #0f1e3d;
    border: none;
    border-radius: 10px;
    padding: 15px;
    font-size: 15px;
    font-weight: 600;
    font-family: 'Outfit', sans-serif;
    letter-spacing: 0.3px;
    cursor: pointer;
    transition: all 0.2s ease;
    display: flex; align-items: center; justify-content: center; gap: 8px;
  }
  .ait-btn-primary:hover:not(:disabled) {
    background: linear-gradient(135deg, #d9bc7e, #C6A85E);
    transform: translateY(-1px);
    box-shadow: 0 8px 24px rgba(198,168,94,0.35);
  }
  .ait-btn-primary:active:not(:disabled) { transform: translateY(0); }
  .ait-btn-primary:disabled { opacity: 0.55; cursor: not-allowed; }

  .ait-btn-ghost {
    background: transparent;
    border: 1.5px solid rgba(198,168,94,0.3);
    color: #C6A85E;
    border-radius: 10px;
    padding: 13px;
    font-size: 14px;
    font-weight: 500;
    font-family: 'Outfit', sans-serif;
    cursor: pointer;
    transition: all 0.2s ease;
  }
  .ait-btn-ghost:hover:not(:disabled) {
    background: rgba(198,168,94,0.08);
    border-color: rgba(198,168,94,0.6);
  }

  .ait-label {
    display: block;
    font-size: 12px;
    font-weight: 500;
    font-family: 'Outfit', sans-serif;
    color: #8A9AB0;
    letter-spacing: 0.8px;
    text-transform: uppercase;
    margin-bottom: 6px;
  }

  .ait-error-msg {
    font-size: 12px;
    color: #ef4444;
    font-family: 'Outfit', sans-serif;
    margin-top: 5px;
    display: flex; align-items: center; gap: 4px;
  }

  .ait-divider {
    display: flex; align-items: center; gap: 12px;
    margin: 20px 0;
  }
  .ait-divider::before, .ait-divider::after {
    content: '';
    flex: 1;
    height: 1px;
    background: rgba(255,255,255,0.08);
  }
  .ait-divider span {
    font-size: 12px;
    color: rgba(138,154,176,0.5);
    font-family: 'Outfit', sans-serif;
    white-space: nowrap;
  }

  @keyframes ait-fade-in {
    from { opacity: 0; }
    to { opacity: 1; }
  }
  @keyframes ait-slide-up {
    from { opacity: 0; transform: translateY(24px) scale(0.98); }
    to { opacity: 1; transform: translateY(0) scale(1); }
  }
  @keyframes ait-spin {
    to { transform: rotate(360deg); }
  }
  .ait-spinner {
    width: 18px; height: 18px;
    border: 2px solid rgba(15,30,61,0.3);
    border-top-color: #0f1e3d;
    border-radius: 50%;
    animation: ait-spin 0.7s linear infinite;
    flex-shrink: 0;
  }
  .ait-spinner-gold {
    border-color: rgba(198,168,94,0.2);
    border-top-color: #C6A85E;
  }

  .ait-close-btn {
    position: absolute;
    top: 16px; right: 16px;
    width: 32px; height: 32px;
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 8px;
    color: #8A9AB0;
    cursor: pointer;
    display: flex; align-items: center; justify-content: center;
    font-size: 18px;
    line-height: 1;
    transition: all 0.2s ease;
  }
  .ait-close-btn:hover { background: rgba(255,255,255,0.1); color: #f0ece4; }
`;

export function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

export function validatePhone(phone) {
  return /^[6-9]\d{9}$/.test(phone.replace(/\s/g, ""));
}

export function formatPhone(phone) {
  return phone.replace(/\D/g, "").slice(0, 10);
}

export function injectStyles(id, css) {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const style = document.createElement("style");
  style.id = id;
  style.textContent = css;
  document.head.appendChild(style);
}
