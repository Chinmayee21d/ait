"use client";
import { useState, useEffect } from "react";
import AITLogo from "./AITLogo";
import OTPInput from "./OTPInput";
import { globalStyles, validateEmail, injectStyles } from "./aitAuthUtils";
import { pushAnalyticsEvent } from "@/lib/analytics";

/**
 * AITPitchDeckDownload - Gated pitch deck download page for AIT
 *
 * Usage in Next.js:
 *   import AITPitchDeckDownload from "@/components/auth/AITPitchDeckDownload";
 *   <AITPitchDeckDownload deckUrl="/files/AIT-PitchDeck-2026.pdf" />
 *
 * Props:
 *   deckUrl - URL of the PDF to trigger download (or show a link to)
 *   onSuccess(userData) - called after download is unlocked
 *   mockOTP - "123456" for dev testing
 */
export default function AITPitchDeckDownload({
  deckUrl = "/files/AIT-PitchDeck-2026.pdf",
  onSuccess,
  mockOTP = null,
  className = "",
}) {
  useEffect(() => injectStyles("ait-auth-styles", globalStyles), []);

  const [step, setStep] = useState("gate"); // "gate" | "otp" | "unlocked"
  const [form, setForm] = useState({ name: "", email: "", company: "" });
  const [errors, setErrors] = useState({});
  const [otp, setOtp] = useState("");
  const [otpError, setOtpError] = useState("");
  const [loading, setLoading] = useState(false);
  const [resendTimer, setResendTimer] = useState(0);
  const [downloadStarted, setDownloadStarted] = useState(false);
  const [unlockedUrl, setUnlockedUrl] = useState(deckUrl);

  useEffect(() => {
    if (resendTimer <= 0) return;
    const t = setTimeout(() => setResendTimer((r) => r - 1), 1000);
    return () => clearTimeout(t);
  }, [resendTimer]);

  const setField = (key, value) => {
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((e) => ({ ...e, [key]: "" }));
  };

  const validateGate = () => {
    const errs = {};
    if (!form.name.trim()) errs.name = "Required";
    if (!validateEmail(form.email)) errs.email = "Enter a valid work email";
    if (!form.company.trim()) errs.company = "Required";
    return errs;
  };

  const handleGateSubmit = async (e) => {
    e?.preventDefault();
    const errs = validateGate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setLoading(true);
    try {
      const res = await fetch("/api/otp/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: form.email.trim(), purpose: "pitch" }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to send OTP. Please try again.");
      setStep("otp");
      setResendTimer(30);
      pushAnalyticsEvent("otp_send", { flow: "pitch_deck" });
    } catch (err) {
      setErrors({ email: err?.message || "Failed to send OTP. Please try again." });
    }
    setLoading(false);
  };

  const handleOTPSubmit = async (e) => {
    e?.preventDefault();
    if (otp.length < 6) { setOtpError("Enter the 6-digit code sent to your email."); return; }
    setOtpError("");
    setLoading(true);
    try {
      if (mockOTP && otp !== mockOTP) throw new Error("Invalid or expired code. Try again.");
      const res = await fetch("/api/otp/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: form.email.trim(),
          code: otp,
          purpose: "pitch",
          payload: form,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Verification failed. Please try again.");
      setStep("unlocked");
      if (data.downloadUrl) setUnlockedUrl(data.downloadUrl);
      pushAnalyticsEvent("otp_verify_success", { flow: "pitch_deck" });
      onSuccess?.({ ...form, ...(data.user || {}) });
    } catch (err) {
      setOtpError(err?.message || "Verification failed. Please try again.");
    }
    setLoading(false);
  };

  const handleResend = async () => {
    if (resendTimer > 0) return;
    setOtp(""); setOtpError("");
    setLoading(true);
    try {
      const res = await fetch("/api/otp/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: form.email.trim(), purpose: "pitch" }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to resend OTP.");
      setResendTimer(30);
      pushAnalyticsEvent("otp_send", { flow: "pitch_deck", source: "resend" });
    } catch {
      setOtpError("Could not resend code. Please try again.");
    }
    setLoading(false);
  };

  const triggerDownload = () => {
    setDownloadStarted(true);
    pushAnalyticsEvent("pitch_deck_download", {
      flow: "pitch_deck",
      download_url: unlockedUrl,
    });
    const a = document.createElement("a");
    a.href = unlockedUrl;
    a.download = "AIT-PitchDeck-2026.pdf";
    a.click();
  };

  const highlights = [
    { stat: "₹1.5 Cr", label: "avg ITC recovery", sub: "per ₹500 Cr revenue" },
    { stat: "99.8%", label: "reconciliation accuracy", sub: "vs 60–70% manual" },
    { stat: "30 days", label: "to full deployment", sub: "API-first architecture" },
    { stat: "10x", label: "operational velocity", sub: "5 days → <2 hours" },
  ];

  return (
    <div
      className={className}
      style={pageStyle}
    >
      <BackgroundDecor />

      <div
        style={{
          width: "100%",
          maxWidth: 880,
          position: "relative",
          zIndex: 1,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        {/* Logo */}
        <div style={{ marginBottom: 16 }}>
          <AITLogo size="md" />
        </div>

        {/* STEP: Gate */}
        {step === "gate" && (
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: 0,
              width: "100%",
              maxWidth: 840,
              background: "linear-gradient(145deg, #111d35 0%, #0d1829 100%)",
              border: "1px solid rgba(198,168,94,0.18)",
              borderRadius: 24,
              overflow: "hidden",
              boxShadow: "0 40px 80px rgba(0,0,0,0.6)",
            }}
          >
            {/* Left - Deck info */}
            <div style={{ padding: "36px 30px", borderRight: "1px solid rgba(198,168,94,0.1)", position: "relative" }}>
              <div
                style={{
                  position: "absolute",
                  top: 0, left: 0, right: 0,
                  height: "1px",
                  background: "linear-gradient(90deg, transparent, rgba(198,168,94,0.4), transparent)",
                }}
              />

              <div style={{ marginBottom: 12 }}>
                <span style={{ fontFamily: "'Outfit', sans-serif", fontSize: 11, fontWeight: 600, color: "#C6A85E", letterSpacing: "1.5px", textTransform: "uppercase", background: "rgba(198,168,94,0.1)", padding: "5px 10px", borderRadius: 20, border: "1px solid rgba(198,168,94,0.2)" }}>
                  Investor Pitch Deck · 2026
                </span>
              </div>

              <p style={{ fontFamily: "'DM Serif Display', serif", fontSize: 28, color: "#f0ece4", margin: "12px 0 8px", lineHeight: 1.3 }}>
                The Infrastructure<br />
                <span style={{ color: "#C6A85E" }}>India's Finance</span><br />
                Teams Were Missing
              </p>
              <p style={{ fontFamily: "'Outfit', sans-serif", fontSize: 14, color: "#8A9AB0", marginBottom: 24, lineHeight: 1.6 }}>
                17 slides covering AIT's vision, platform, unit economics, and the ₹87,000 Cr opportunity in Indian tax compliance.
              </p>

              {/* Stats grid */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 24 }}>
                {highlights.map((h) => (
                  <div key={h.stat} style={{ padding: "14px", background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 12 }}>
                    <p style={{ fontFamily: "'DM Serif Display', serif", fontSize: 22, color: "#C6A85E", margin: "0 0 2px" }}>{h.stat}</p>
                    <p style={{ fontFamily: "'Outfit', sans-serif", fontSize: 12, fontWeight: 600, color: "#f0ece4", margin: "0 0 2px" }}>{h.label}</p>
                    <p style={{ fontFamily: "'Outfit', sans-serif", fontSize: 11, color: "rgba(138,154,176,0.7)", margin: 0 }}>{h.sub}</p>
                  </div>
                ))}
              </div>

              <div style={{ padding: "14px", background: "rgba(198,168,94,0.06)", borderRadius: 12, border: "1px solid rgba(198,168,94,0.12)" }}>
                <p style={{ fontFamily: "'Outfit', sans-serif", fontSize: 12, color: "#C6A85E", fontWeight: 600, margin: "0 0 4px" }}>CONFIDENTIAL</p>
                <p style={{ fontFamily: "'Outfit', sans-serif", fontSize: 12, color: "#8A9AB0", margin: 0, lineHeight: 1.6 }}>
                  Verify your email to unlock and download the full deck.
                </p>
              </div>
            </div>

            {/* Right - Form */}
            <div style={{ padding: "36px 30px" }}>
              <h2 style={{ fontFamily: "'Outfit', sans-serif", fontSize: 18, fontWeight: 600, color: "#f0ece4", margin: "0 0 6px" }}>
                Download the deck
              </h2>
              <p style={{ fontFamily: "'Outfit', sans-serif", fontSize: 14, color: "#8A9AB0", marginBottom: 20, lineHeight: 1.6 }}>
                We'll send you a one-time code to verify your email.
              </p>

              <form onSubmit={handleGateSubmit} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                <div>
                  <label className="ait-label" htmlFor="deck-name">Your Name*</label>
                  <input id="deck-name" className={`ait-field ${errors.name ? "error" : ""}`} placeholder="Rohan Sharma" value={form.name} onChange={(e) => setField("name", e.target.value)} autoFocus />
                  {errors.name && <div className="ait-error-msg">{errors.name}</div>}
                </div>
                <div>
                  <label className="ait-label" htmlFor="deck-company">Company / Fund*</label>
                  <input id="deck-company" className={`ait-field ${errors.company ? "error" : ""}`} placeholder="Sequoia India" value={form.company} onChange={(e) => setField("company", e.target.value)} />
                  {errors.company && <div className="ait-error-msg">{errors.company}</div>}
                </div>
                <div>
                  <label className="ait-label" htmlFor="deck-email">Work Email*</label>
                  <input id="deck-email" className={`ait-field ${errors.email ? "error" : ""}`} type="email" placeholder="you@company.com" value={form.email} onChange={(e) => setField("email", e.target.value)} />
                  {errors.email && <div className="ait-error-msg"><ErrorIcon /> {errors.email}</div>}
                </div>

                <button className="ait-btn-primary" type="submit" disabled={loading} style={{ marginTop: 8 }}>
                  {loading ? <><span className="ait-spinner" />&nbsp;Sending code…</> : "Get Download Link"}
                </button>
              </form>

              <p style={{ fontFamily: "'Outfit', sans-serif", fontSize: 12, color: "rgba(138,154,176,0.5)", textAlign: "center", marginTop: 16, lineHeight: 1.6 }}>
                NDA not required. Deck is shared under mutual confidentiality.
              </p>
            </div>
          </div>
        )}

        {/* STEP: OTP */}
        {step === "otp" && (
          <div className="ait-auth-card" style={{ maxWidth: 420 }}>
            <button onClick={() => { setStep("gate"); setOtp(""); setOtpError(""); }} style={backBtnStyle}>← Back</button>

            <div style={{ width: 56, height: 56, borderRadius: "50%", background: "rgba(198,168,94,0.1)", border: "1px solid rgba(198,168,94,0.25)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px" }}>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2z" stroke="#C6A85E" strokeWidth="1.5" />
                <path d="M22 6l-10 7L2 6" stroke="#C6A85E" strokeWidth="1.5" strokeLinecap="round" />
              </svg>
            </div>

            <h1 style={headingStyle}>Check your inbox</h1>
            <p style={{ ...subStyle, marginBottom: 28 }}>
              Code sent to <strong style={{ color: "#C6A85E" }}>{form.email}</strong>
            </p>

            <form onSubmit={handleOTPSubmit}>
              <OTPInput value={otp} onChange={setOtp} error={!!otpError} disabled={loading} />
              {otpError && <div className="ait-error-msg" style={{ justifyContent: "center", marginTop: 10 }}><ErrorIcon /> {otpError}</div>}
              <button className="ait-btn-primary" type="submit" disabled={loading || otp.length < 6} style={{ marginTop: 24 }}>
                {loading ? <><span className="ait-spinner" />&nbsp;Verifying…</> : "Verify & Unlock Deck"}
              </button>
            </form>

            <div style={{ textAlign: "center", marginTop: 16, fontSize: 13, color: "#8A9AB0", fontFamily: "'Outfit', sans-serif" }}>
              Didn't receive it?{" "}
              {resendTimer > 0 ? <span>Resend in {resendTimer}s</span> : (
                <button onClick={handleResend} style={{ background: "none", border: "none", color: "#C6A85E", cursor: "pointer", fontWeight: 600, fontFamily: "inherit", fontSize: "inherit" }}>Resend code</button>
              )}
            </div>
          </div>
        )}

        {/* STEP: Unlocked */}
        {step === "unlocked" && (
          <div className="ait-auth-card" style={{ maxWidth: 440, textAlign: "center" }}>
            <div style={{ width: 64, height: 64, borderRadius: "50%", background: "rgba(198,168,94,0.12)", border: "1.5px solid rgba(198,168,94,0.3)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 24px", animation: "ait-slide-up 0.4s ease" }}>
              <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
                <path d="M14 4v12M8 10l6 6 6-6" stroke="#C6A85E" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M4 22h20" stroke="#C6A85E" strokeWidth="2.5" strokeLinecap="round" />
              </svg>
            </div>

            <h1 style={{ ...headingStyle, fontSize: 24 }}>Deck unlocked!</h1>
            <p style={{ ...subStyle, marginTop: 8, marginBottom: 28 }}>
              Hi <strong style={{ color: "#f0ece4" }}>{form.name.split(" ")[0]}</strong>, your download is ready.<br />
              The deck covers all 17 slides of AIT's investor presentation.
            </p>

            <button
              className="ait-btn-primary"
              onClick={triggerDownload}
              style={{ marginBottom: 12 }}
            >
              {downloadStarted ? (
                <><CheckIcon /> Downloading…</>
              ) : (
                <>
                  <svg width="18" height="18" viewBox="0 0 18 18" fill="none" style={{ flexShrink: 0 }}>
                    <path d="M9 2v10M4 8l5 5 5-5" stroke="#0f1e3d" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    <path d="M3 14h12" stroke="#0f1e3d" strokeWidth="2" strokeLinecap="round" />
                  </svg>
                  Download PDF (17 slides)
                </>
              )}
            </button>

            <a href={unlockedUrl} target="_blank" rel="noopener noreferrer" className="ait-btn-ghost" style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8, textDecoration: "none", width: "100%", boxSizing: "border-box" }}>
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                <path d="M1 7h12M8 2l5 5-5 5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              View in browser
            </a>

            <div style={{ marginTop: 24, padding: "16px", background: "rgba(198,168,94,0.06)", borderRadius: 12, border: "1px solid rgba(198,168,94,0.12)" }}>
              <p style={{ fontFamily: "'Outfit', sans-serif", fontSize: 12, color: "#C6A85E", fontWeight: 600, margin: "0 0 8px", letterSpacing: "0.8px" }}>WHAT'S NEXT</p>
              <p style={{ fontFamily: "'Outfit', sans-serif", fontSize: 13, color: "#8A9AB0", margin: "0 0 10px", lineHeight: 1.5 }}>
                Interested in a live demo or partnership discussion?
              </p>
              <a href="/request-demo" style={{ fontFamily: "'Outfit', sans-serif", fontSize: 13, fontWeight: 600, color: "#C6A85E", textDecoration: "none" }}>
                Book a 30-min demo →
              </a>
            </div>
          </div>
        )}
      </div>

      {/* Responsive CSS */}
      <style>{`
        @media (max-width: 640px) {
          .ait-deck-card-grid { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </div>
  );
}

function ErrorIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" style={{ flexShrink: 0 }}>
      <circle cx="6" cy="6" r="5.5" stroke="currentColor" />
      <path d="M6 3.5v3M6 8h.01" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}
function CheckIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" style={{ flexShrink: 0 }}>
      <path d="M4 9l4 4 6-7" stroke="#0f1e3d" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
function BackgroundDecor() {
  return (
    <div style={{ position: "fixed", inset: 0, overflow: "hidden", zIndex: 0, pointerEvents: "none" }}>
      <div style={{ position: "absolute", top: "5%", right: "-5%", width: "55vw", height: "55vw", borderRadius: "50%", background: "radial-gradient(circle, rgba(21,59,111,0.35) 0%, transparent 70%)" }} />
      <div style={{ position: "absolute", bottom: "0%", left: "0%", width: "45vw", height: "45vw", borderRadius: "50%", background: "radial-gradient(circle, rgba(198,168,94,0.05) 0%, transparent 70%)" }} />
    </div>
  );
}

const pageStyle = { minHeight: "100vh", background: "#080e1c", display: "flex", alignItems: "center", justifyContent: "center", padding: "20px 16px", position: "relative" };
const headingStyle = { fontFamily: "'DM Serif Display', Georgia, serif", fontSize: 26, fontWeight: 400, color: "#f0ece4", margin: 0, textAlign: "center" };
const subStyle = { fontFamily: "'Outfit', sans-serif", fontSize: 14, color: "#8A9AB0", textAlign: "center", margin: "8px 0 0", lineHeight: 1.6 };
const backBtnStyle = { background: "none", border: "none", color: "#8A9AB0", cursor: "pointer", fontFamily: "'Outfit', sans-serif", fontSize: 13, padding: 0, marginBottom: 20, display: "block" };
