"use client";
import { useRef, useState, useEffect } from "react";

export default function OTPInput({ length = 6, value = "", onChange, disabled = false, error = false }) {
  const [digits, setDigits] = useState(() => {
    const arr = value.split("").slice(0, length);
    while (arr.length < length) arr.push("");
    return arr;
  });
  const inputs = useRef([]);

  useEffect(() => {
    const arr = value.split("").slice(0, length);
    while (arr.length < length) arr.push("");
    setDigits(arr);
  }, [value, length]);

  const handleChange = (idx, e) => {
    const val = e.target.value.replace(/\D/g, "").slice(-1);
    const next = [...digits];
    next[idx] = val;
    setDigits(next);
    onChange(next.join(""));
    if (val && idx < length - 1) {
      inputs.current[idx + 1]?.focus();
    }
  };

  const handleKeyDown = (idx, e) => {
    if (e.key === "Backspace") {
      if (!digits[idx] && idx > 0) {
        inputs.current[idx - 1]?.focus();
        const next = [...digits];
        next[idx - 1] = "";
        setDigits(next);
        onChange(next.join(""));
      } else {
        const next = [...digits];
        next[idx] = "";
        setDigits(next);
        onChange(next.join(""));
      }
    }
    if (e.key === "ArrowLeft" && idx > 0) inputs.current[idx - 1]?.focus();
    if (e.key === "ArrowRight" && idx < length - 1) inputs.current[idx + 1]?.focus();
  };

  const handlePaste = (e) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, length);
    const next = pasted.split("");
    while (next.length < length) next.push("");
    setDigits(next);
    onChange(next.join(""));
    const focusIdx = Math.min(pasted.length, length - 1);
    inputs.current[focusIdx]?.focus();
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "12px" }}>
      <div style={{ display: "flex", gap: "10px", justifyContent: "center" }}>
      {digits.map((d, i) => (
        <input
          key={i}
          ref={(el) => (inputs.current[i] = el)}
          type="text"
          inputMode="numeric"
          maxLength={1}
          value={d}
          onChange={(e) => handleChange(i, e)}
          onKeyDown={(e) => handleKeyDown(i, e)}
          onPaste={handlePaste}
          disabled={disabled}
          style={{
            width: "48px",
            height: "56px",
            textAlign: "center",
            fontSize: "22px",
            fontWeight: "600",
            fontFamily: "'Outfit', sans-serif",
            background: d ? "rgba(198,168,94,0.08)" : "rgba(255,255,255,0.03)",
            border: `1.5px solid ${error ? "#ef4444" : d ? "#C6A85E" : "rgba(255,255,255,0.12)"}`,
            borderRadius: "10px",
            color: error ? "#ef4444" : "#C6A85E",
            outline: "none",
            transition: "all 0.2s ease",
            caretColor: "#C6A85E",
            letterSpacing: "0",
          }}
          onFocus={(e) => {
            e.target.style.borderColor = error ? "#ef4444" : "#C6A85E";
            e.target.style.boxShadow = `0 0 0 3px ${error ? "rgba(239,68,68,0.15)" : "rgba(198,168,94,0.15)"}`;
          }}
          onBlur={(e) => {
            e.target.style.borderColor = error ? "#ef4444" : d ? "#C6A85E" : "rgba(255,255,255,0.12)";
            e.target.style.boxShadow = "none";
          }}
        />
      ))}
      </div>
      <p style={{
        fontFamily: "'Outfit', sans-serif",
        fontSize: 12,
        color: "rgba(138,154,176,0.55)",
        margin: 0,
        textAlign: "center",
        lineHeight: 1.5,
      }}>
        Can't find it? Check your <strong style={{ color: "rgba(198,168,94,0.7)", fontWeight: 600 }}>junk or spam folder</strong>.
      </p>
    </div>
  );
}
