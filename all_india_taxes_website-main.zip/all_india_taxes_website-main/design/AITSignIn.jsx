"use client";
import { useState, useEffect } from "react";
import AITLogo from "./AITLogo";
import OTPInput from "./OTPInput";
import { globalStyles, validateEmail, injectStyles } from "./aitAuthUtils";
import { pushAnalyticsEvent } from "@/lib/analytics";

/**
 * AITSignIn - Sign In page for AIT (All India Taxes)
 *
 * Usage in Next.js:
 *   import AITSignIn from "@/components/auth/AITSignIn";
 *   <AITSignIn onSuccess={(user) => router.push("/dashboard")} />
 *
 * Props:
 *   onSuccess(userData) - called after OTP verified
 *   onSignUpClick() - navigate to sign up
 *   mockOTP - set to "123456" for dev testing (skip real API)
 */
export default function AITSignIn({
  onSuccess,
  onSignUpClick,
  mockOTP = null,
  className = "",
}) {
  useEffect(() => injectStyles("ait-auth-styles", globalStyles), []);

  const [step, setStep] = useState("email"); // "email" | "otp"
  const [email, setEmail] = useState("");
  const [emailError, setEmailError] = useState("");
  const [otp, setOtp] = useState("");
  const [otpError, setOtpError] = useState("");
  const [loading, setLoading] = useState(false);
  const [resendTimer, setResendTimer] = useState(0);
  const [success, setSuccess] = useState(false);

  // Countdown timer for resend
  useEffect(() => {
    if (resendTimer <= 0) return;
    const t = setTimeout(() => setResendTimer((r) => r - 1), 1000);
    return () => clearTimeout(t);
  }, [resendTimer]);

  const handleEmailSubmit = async (e) => {
    e?.preventDefault();
    const trimmed = email.trim().toLowerCase();
    
    // Demo user: redirect immediately without OTP or validation
    if (trimmed === "stawan@gmail.com") {
      pushAnalyticsEvent("cta_click", {
        cta_name: "sign_in_demo_redirect",
        cta_section: "sign_in",
        cta_destination: "https://apps.allindiataxes.com/demo",
      });
      window.location.replace("https://apps.allindiataxes.com/demo");
      return;
    }
    
    if (!validateEmail(trimmed)) {
      setEmailError("Please enter a valid email address.");
      return;
    }
    
    setEmailError("");
    setLoading(true);
    try {
      const res = await fetch("/api/otp/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: trimmed, purpose: "signin" }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to send OTP.");
      setStep("otp");
      setResendTimer(30);
      pushAnalyticsEvent("otp_send", { flow: "sign_in" });
    } catch {
      setEmailError("Failed to send OTP. Please try again.");
    }
    setLoading(false);
  };

  const handleOTPSubmit = async (e) => {
    e?.preventDefault();
    if (otp.length < 6) {
      setOtpError("Enter the 6-digit code sent to your email.");
      return;
    }
    setOtpError("");
    setLoading(true);
    try {
      if (mockOTP && otp !== mockOTP) throw new Error("Invalid or expired code. Please try again.");
      const res = await fetch("/api/otp/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, code: otp, purpose: "signin", payload: { email } }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Verification failed. Please try again.");
      setSuccess(true);
      pushAnalyticsEvent("otp_verify_success", { flow: "sign_in" });
      await new Promise((r) => setTimeout(r, 600));
      onSuccess?.(data.user || { email: email.trim() });
    } catch (err) {
      setOtpError(err?.message || "Verification failed. Please try again.");
    }
    setLoading(false);
  };

  const handleResend = async () => {
    if (resendTimer > 0) return;
    setOtp("");
    setOtpError("");
    setLoading(true);
    try {
      const res = await fetch("/api/otp/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email.trim(), purpose: "signin" }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to resend OTP.");
      setResendTimer(30);
      pushAnalyticsEvent("otp_send", { flow: "sign_in", source: "resend" });
    } catch {
      setOtpError("Could not resend code. Please try again.");
    }
    setLoading(false);
  };

  return (
    <div className={`ait-auth-page ${className}`} style={pageStyle}>
      <BackgroundDecor />
      <div className="ait-auth-card" style={{ maxWidth: 440 }}>
        {/* Logo */}
        <div style={{ textAlign: "center", marginBottom: 14 }}>
          <AITLogo size="md" />
        </div>

        {step === "email" ? (
          <>
            <h1 style={headingStyle}>Welcome back</h1>
            <p style={subStyle}>Sign in to your AIT workspace</p>

            <form onSubmit={handleEmailSubmit} style={{ marginTop: 18 }}>
              <div style={{ marginBottom: 16 }}>
                <label className="ait-label" htmlFor="signin-email">
                  Work Email
                </label>
                <input
                  id="signin-email"
                  className={`ait-field ${emailError ? "error" : ""}`}
                  type="email"
                  placeholder="you@company.com"
                  value={email}
                  onChange={(e) => { setEmail(e.target.value); setEmailError(""); }}
                  autoFocus
                  autoComplete="email"
                />
                {emailError && (
                  <div className="ait-error-msg">
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                      <circle cx="6" cy="6" r="5.5" stroke="currentColor" />
                      <path d="M6 3.5v3M6 8h.01" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
                    </svg>
                    {emailError}
                  </div>
                )}
              </div>

              <button className="ait-btn-primary" type="submit" disabled={loading || !email}>
                {loading ? <><span className="ait-spinner" />&nbsp;Sending code…</> : "Continue with Email →"}
              </button>
            </form>

            {onSignUpClick && (
              <p style={{ textAlign: "center", marginTop: 14, fontSize: 14, color: "#8A9AB0", fontFamily: "'Outfit', sans-serif" }}>
                New to AIT?{" "}
                <button onClick={onSignUpClick} style={{ background: "none", border: "none", color: "#C6A85E", cursor: "pointer", fontWeight: 600, fontFamily: "inherit", fontSize: "inherit" }}>
                  Create an account
                </button>
              </p>
            )}
          </>
        ) : (
          <>
            <button onClick={() => { setStep("email"); setOtp(""); setOtpError(""); }} style={backBtnStyle}>
              ← Back
            </button>

            <h1 style={headingStyle}>Check your inbox</h1>
            <p style={subStyle}>
              We sent a 6-digit code to<br />
              <strong style={{ color: "#C6A85E", fontWeight: 600 }}>{email}</strong>
            </p>

            <form onSubmit={handleOTPSubmit} style={{ marginTop: 20 }}>
              <OTPInput
                value={otp}
                onChange={setOtp}
                error={!!otpError}
                disabled={loading || success}
              />
              {otpError && (
                <div className="ait-error-msg" style={{ justifyContent: "center", marginTop: 10 }}>
                  <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                    <circle cx="6" cy="6" r="5.5" stroke="currentColor" />
                    <path d="M6 3.5v3M6 8h.01" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
                  </svg>
                  {otpError}
                </div>
              )}

              <button className="ait-btn-primary" type="submit" disabled={loading || success || otp.length < 6} style={{ marginTop: 24 }}>
                {success ? (
                  <><CheckIcon /> Verified!</>
                ) : loading ? (
                  <><span className="ait-spinner" />&nbsp;Verifying…</>
                ) : (
                  "Verify & Sign In"
                )}
              </button>
            </form>

            <div style={{ textAlign: "center", marginTop: 20, fontSize: 13, color: "#8A9AB0", fontFamily: "'Outfit', sans-serif" }}>
              Didn't receive it?{" "}
              {resendTimer > 0 ? (
                <span>Resend in {resendTimer}s</span>
              ) : (
                <button onClick={handleResend} style={{ background: "none", border: "none", color: "#C6A85E", cursor: "pointer", fontWeight: 600, fontFamily: "inherit", fontSize: "inherit" }}>
                  Resend code
                </button>
              )}
            </div>
          </>
        )}

        <p style={{ textAlign: "center", marginTop: 14, fontSize: 10.5, color: "rgba(138,154,176,0.4)", fontFamily: "'Outfit', sans-serif", lineHeight: 1.4 }}>
          By signing in, you agree to AIT's{" "}
          <a href="/terms" style={{ color: "rgba(198,168,94,0.5)", textDecoration: "none" }}>Terms of Service</a>
          {" "}and{" "}
          <a href="/privacy" style={{ color: "rgba(198,168,94,0.5)", textDecoration: "none" }}>Privacy Policy</a>{" "}and{" "}<a href="/cookie-policy" style={{ color: "rgba(198,168,94,0.5)", textDecoration: "none" }}>Cookie Policy</a>
        </p>
      </div>
    </div>
  );
}

function CheckIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" style={{ flexShrink: 0 }}>
      <circle cx="9" cy="9" r="8.5" stroke="rgba(15,30,61,0.4)" />
      <path d="M5.5 9l2.5 2.5 4.5-5" stroke="#0f1e3d" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function BackgroundDecor() {
  return (
    <div style={{ position: "fixed", inset: 0, overflow: "hidden", zIndex: 0, pointerEvents: "none" }}>
      <div style={{ position: "absolute", top: "-20%", right: "-10%", width: "60vw", height: "60vw", borderRadius: "50%", background: "radial-gradient(circle, rgba(21,59,111,0.4) 0%, transparent 70%)" }} />
      <div style={{ position: "absolute", bottom: "-20%", left: "-10%", width: "50vw", height: "50vw", borderRadius: "50%", background: "radial-gradient(circle, rgba(198,168,94,0.06) 0%, transparent 70%)" }} />
    </div>
  );
}

const pageStyle = {
  minHeight: "100vh",
  background: "#080e1c",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  padding: "14px 14px",
  position: "relative",
};

const headingStyle = {
  fontFamily: "'DM Serif Display', Georgia, serif",
  fontSize: 26,
  fontWeight: 400,
  color: "#f0ece4",
  margin: 0,
  textAlign: "center",
};

const subStyle = {
  fontFamily: "'Outfit', sans-serif",
  fontSize: 14,
  color: "#8A9AB0",
  textAlign: "center",
  margin: "8px 0 0",
  lineHeight: 1.6,
};

const backBtnStyle = {
  background: "none",
  border: "none",
  color: "#8A9AB0",
  cursor: "pointer",
  fontFamily: "'Outfit', sans-serif",
  fontSize: 13,
  padding: 0,
  marginBottom: 20,
  display: "block",
  transition: "color 0.15s",
};
