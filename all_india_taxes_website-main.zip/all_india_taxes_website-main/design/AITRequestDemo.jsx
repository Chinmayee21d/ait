"use client";

import { useEffect, useMemo, useState } from "react";
import AITLogo from "./AITLogo";
import OTPInput from "./OTPInput";
import { globalStyles, validateEmail, injectStyles } from "./aitAuthUtils";
import { pushAnalyticsEvent } from "@/lib/analytics";

const ROLE_LABELS = {
  business: "Business Owner",
  enterprise: "Enterprise User",
  ca: "CA Firm",
};

const VIEW_DEMO_COPY = {
  title: "Register to view your product demo",
  subtitle:
    "Complete quick registration and email verification to unlock the guided AIT demo instantly.",
  features: [
    {
      title: "Live compliance workspace",
      desc: "See real GST and TDS operational flows in an interactive product environment.",
    },
    {
      title: "Role-relevant walkthrough",
      desc: "Demo screens are aligned to your operating context and decision needs.",
    },
    {
      title: "Verified access only",
      desc: "OTP verification protects the demo and keeps lead context accurate.",
    },
    {
      title: "Optional deep-dive session",
      desc: "Reply to the confirmation email if you want a detailed customized walkthrough.",
    },
  ],
  outcomeLabel: "ACCESS FLOW",
  outcomeTitle: "Register -> Verify -> Launch Demo",
  outcomeSub: "Takes about 60 seconds",
  submitText: "Verify Email and Continue",
  confirmTitle: "Registration complete",
  nextSteps: [
    "Your email is verified and your access is confirmed.",
    "Opening your guided demo in a new flow now.",
    "Reply to Stawan's email if you want a tailored deep-dive session.",
  ],
};

const REQUEST_DEMO_COPY = {
  title: "Book your demo",
  subtitle: "Live walkthrough tailored to your compliance challenges.",
  features: [
    {
      title: "Real-time ITC reconciliation",
      desc: "See mismatches resolved in seconds, not days.",
    },
    {
      title: "Vendor trust score in action",
      desc: "Understand vendor compliance risk before ITC is impacted.",
    },
    {
      title: "AI tax copilot",
      desc: "Review anomaly detection and workflow recommendations.",
    },
    {
      title: "Practical onboarding view",
      desc: "We map the demo to your current GST and TDS process.",
    },
  ],
  outcomeLabel: "AVERAGE OUTCOME",
  outcomeTitle: "Rs1.5 Cr ITC recovered",
  outcomeSub: "per Rs500 Cr revenue, within 90 days",
  submitText: "Book Demo and Verify Email",
  confirmTitle: "Demo confirmed",
  nextSteps: [
    "You will receive a calendar invite within 2 hours.",
    "30-minute live walkthrough tailored to your use case.",
    "Optional GSTIN mock audit to show real impact.",
  ],
};

export default function AITRequestDemo(props) {
  const {
    onSuccess,
    onSignInClick,
    onBack,
    mockOTP = null,
    className = "",
    mode = "request",
    selectedRole = "",
    autoRedirectUrl = "",
  } = props || {};
  useEffect(() => injectStyles("ait-auth-styles", globalStyles), []);

  const [step, setStep] = useState("form");
  const [form, setForm] = useState({
    name: "",
    company: "",
    email: "",
    phone: "",
    teamSize: "",
    currentSoftware: "",
    challenge: "",
    role: selectedRole || "",
  });
  const [errors, setErrors] = useState({});
  const [otp, setOtp] = useState("");
  const [otpError, setOtpError] = useState("");
  const [loading, setLoading] = useState(false);
  const [resendTimer, setResendTimer] = useState(0);

  useEffect(() => {
    setForm((prev) => ({ ...prev, role: selectedRole || "" }));
  }, [selectedRole]);

  useEffect(() => {
    if (resendTimer <= 0) return;
    const t = setTimeout(() => setResendTimer((r) => r - 1), 1000);
    return () => clearTimeout(t);
  }, [resendTimer]);

  const copy = useMemo(
    () => (mode === "view" ? VIEW_DEMO_COPY : REQUEST_DEMO_COPY),
    [mode]
  );
  const otpPurpose = mode === "view" ? "view_demo" : "request_demo";

  const roleLabel = ROLE_LABELS[form.role] || "";
  const leftHeading =
    mode === "view" && roleLabel
      ? `View demo for ${roleLabel}`
      : mode === "view"
      ? "View your AIT demo"
      : "See AIT in 30 minutes";

  const setField = (key, value) => {
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((e) => ({ ...e, [key]: "" }));
  };

  const validateForm = () => {
    const errs = {};
    if (!form.name.trim()) errs.name = "Required";
    if (!form.company.trim()) errs.company = "Required";
    if (!validateEmail(form.email)) errs.email = "Enter a valid work email";
    if (!form.teamSize) errs.teamSize = "Required";
    return errs;
  };

  const handleFormSubmit = async (e) => {
    e?.preventDefault();
    const errs = validateForm();
    if (Object.keys(errs).length) {
      setErrors(errs);
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/otp/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: form.email.trim(), purpose: otpPurpose }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Submission failed. Please try again.");
      setStep("otp");
      setResendTimer(30);
      pushAnalyticsEvent("otp_send", {
        flow: mode === "view" ? "view_demo" : "request_demo",
      });
    } catch (err) {
      setErrors({ email: err?.message || "Submission failed. Please try again." });
    }
    setLoading(false);
  };

  const handleOTPSubmit = async (e) => {
    e?.preventDefault();
    if (otp.length < 6) {
      setOtpError("Enter the 6-digit code sent to your email.");
      return;
    }
    setOtpError("");
    setLoading(true);
    try {
      if (mockOTP && otp !== mockOTP) throw new Error("Invalid or expired code. Try again.");
      const res = await fetch("/api/otp/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: form.email.trim(),
          code: otp,
          purpose: otpPurpose,
          payload: form,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Verification failed. Please try again.");
      setStep("confirmed");
      pushAnalyticsEvent("otp_verify_success", {
        flow: mode === "view" ? "view_demo" : "request_demo",
        role: form.role || "unknown",
      });
      onSuccess?.({ ...form, ...(data.user || {}) });
      if (autoRedirectUrl) {
        setTimeout(() => {
          window.location.href = autoRedirectUrl;
        }, 1200);
      }
    } catch (err) {
      setOtpError(err?.message || "Verification failed. Please try again.");
    }
    setLoading(false);
  };

  const handleResend = async () => {
    if (resendTimer > 0) return;
    setOtp("");
    setOtpError("");
    setLoading(true);
    try {
      const res = await fetch("/api/otp/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: form.email.trim(), purpose: otpPurpose }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to resend OTP.");
      setResendTimer(30);
      pushAnalyticsEvent("otp_send", {
        flow: mode === "view" ? "view_demo" : "request_demo",
        source: "resend",
      });
    } catch {
      setOtpError("Could not resend code. Please try again.");
    }
    setLoading(false);
  };

  const teamSizes = ["1-10", "11-50", "51-200", "201-500", "500+"];
  const softwares = ["Tally", "SAP", "Zoho Books", "QuickBooks", "Excel / Manual", "Other"];
  const challenges = [
    "ITC Reconciliation",
    "Vendor Compliance",
    "Multi-GSTIN Management",
    "Audit Readiness",
    "Cash Flow Forecasting",
    "Other",
  ];

  return (
    <div className={className} style={pageStyle}>
      <BackgroundDecor />

      <div
        style={{
          width: "100%",
          maxWidth: 880,
          position: "relative",
          zIndex: 1,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <div style={{ marginBottom: 16 }}>
          <AITLogo size="md" />
        </div>

        {step === "form" && (
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: 0,
              width: "100%",
              maxWidth: 840,
              background: "linear-gradient(145deg, #111d35 0%, #0d1829 100%)",
              border: "1px solid rgba(198,168,94,0.18)",
              borderRadius: 24,
              overflow: "hidden",
              boxShadow: "0 40px 80px rgba(0,0,0,0.6)",
            }}
          >
            <div style={{ padding: "36px 30px", borderRight: "1px solid rgba(198,168,94,0.1)", position: "relative" }}>
              <div
                style={{
                  position: "absolute",
                  top: 0,
                  left: 0,
                  right: 0,
                  height: "1px",
                  background: "linear-gradient(90deg, transparent, rgba(198,168,94,0.4), transparent)",
                }}
              />
              <p style={{ fontFamily: "'DM Serif Display', serif", fontSize: 28, color: "#f0ece4", margin: "0 0 8px", lineHeight: 1.3 }}>
                {leftHeading}
              </p>
              <p style={{ fontFamily: "'Outfit', sans-serif", fontSize: 14, color: "#8A9AB0", marginBottom: 24, lineHeight: 1.6 }}>
                {copy.subtitle}
              </p>

              <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
                {copy.features.map((item) => (
                  <div key={item.title} style={{ display: "flex", gap: 14, alignItems: "flex-start" }}>
                    <div
                      style={{
                        width: 38,
                        height: 38,
                        borderRadius: 10,
                        background: "rgba(198,168,94,0.1)",
                        border: "1px solid rgba(198,168,94,0.2)",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontSize: 18,
                        flexShrink: 0,
                        color: "#C6A85E",
                        fontWeight: 700,
                      }}
                    >
                      +
                    </div>
                    <div>
                      <p style={{ fontFamily: "'Outfit', sans-serif", fontSize: 13, fontWeight: 600, color: "#f0ece4", margin: "0 0 2px" }}>
                        {item.title}
                      </p>
                      <p style={{ fontFamily: "'Outfit', sans-serif", fontSize: 12, color: "#8A9AB0", margin: 0, lineHeight: 1.5 }}>
                        {item.desc}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              <div style={{ marginTop: 24, padding: "14px", background: "rgba(198,168,94,0.06)", borderRadius: 12, border: "1px solid rgba(198,168,94,0.12)" }}>
                <p style={{ fontFamily: "'Outfit', sans-serif", fontSize: 12, color: "#C6A85E", fontWeight: 600, margin: "0 0 4px" }}>{copy.outcomeLabel}</p>
                <p style={{ fontFamily: "'DM Serif Display', serif", fontSize: 22, color: "#f0ece4", margin: "0 0 4px" }}>{copy.outcomeTitle}</p>
                <p style={{ fontFamily: "'Outfit', sans-serif", fontSize: 12, color: "#8A9AB0", margin: 0 }}>{copy.outcomeSub}</p>
              </div>
            </div>

            <div style={{ padding: "36px 30px" }}>
              <h2 style={{ fontFamily: "'Outfit', sans-serif", fontSize: 18, fontWeight: 600, color: "#f0ece4", margin: "0 0 18px" }}>
                {copy.title}
              </h2>

              <form onSubmit={handleFormSubmit}>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }}>
                  <div>
                    <label className="ait-label" htmlFor="demo-name">Full Name*</label>
                    <input id="demo-name" className={`ait-field ${errors.name ? "error" : ""}`} placeholder="Rohan Sharma" value={form.name} onChange={(e) => setField("name", e.target.value)} autoFocus />
                    {errors.name && <div className="ait-error-msg">{errors.name}</div>}
                  </div>
                  <div>
                    <label className="ait-label" htmlFor="demo-company">Company*</label>
                    <input id="demo-company" className={`ait-field ${errors.company ? "error" : ""}`} placeholder="Acme Pvt. Ltd." value={form.company} onChange={(e) => setField("company", e.target.value)} />
                    {errors.company && <div className="ait-error-msg">{errors.company}</div>}
                  </div>
                </div>

                <div style={{ marginBottom: 12 }}>
                  <label className="ait-label" htmlFor="demo-email">Work Email*</label>
                  <input id="demo-email" className={`ait-field ${errors.email ? "error" : ""}`} type="email" placeholder="you@company.com" value={form.email} onChange={(e) => setField("email", e.target.value)} />
                  {errors.email && <div className="ait-error-msg"><ErrorIcon /> {errors.email}</div>}
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }}>
                  <div>
                    <label className="ait-label" htmlFor="demo-size">Team Size*</label>
                    <select id="demo-size" className={`ait-field ${errors.teamSize ? "error" : ""}`} value={form.teamSize} onChange={(e) => setField("teamSize", e.target.value)} style={selectStyle}>
                      <option value="">Select...</option>
                      {teamSizes.map((s) => <option key={s}>{s}</option>)}
                    </select>
                    {errors.teamSize && <div className="ait-error-msg">{errors.teamSize}</div>}
                  </div>
                  <div>
                    <label className="ait-label" htmlFor="demo-software">Current Software</label>
                    <select id="demo-software" className="ait-field" value={form.currentSoftware} onChange={(e) => setField("currentSoftware", e.target.value)} style={selectStyle}>
                      <option value="">Select...</option>
                      {softwares.map((s) => <option key={s}>{s}</option>)}
                    </select>
                  </div>
                </div>

                <div style={{ marginBottom: 24 }}>
                  <label className="ait-label" htmlFor="demo-challenge">Primary Challenge</label>
                  <select id="demo-challenge" className="ait-field" value={form.challenge} onChange={(e) => setField("challenge", e.target.value)} style={selectStyle}>
                    <option value="">Select...</option>
                    {challenges.map((c) => <option key={c}>{c}</option>)}
                  </select>
                </div>

                <button className="ait-btn-primary" type="submit" disabled={loading}>
                  {loading ? <><span className="ait-spinner" /> Submitting...</> : copy.submitText}
                </button>
              </form>

              <p style={{ fontFamily: "'Outfit', sans-serif", fontSize: 12, color: "rgba(138,154,176,0.5)", textAlign: "center", margin: "16px 0 0" }}>
                Secure OTP verification is required before access.
              </p>
            </div>
          </div>
        )}

        {step === "otp" && (
          <div className="ait-auth-card" style={{ maxWidth: 420 }}>
            <button onClick={() => { setStep("form"); setOtp(""); setOtpError(""); }} style={backBtnStyle}>Back</button>
            <h1 style={headingStyle}>Verify your email</h1>
            <p style={subStyle}>
              We sent a 6-digit code to<br />
              <strong style={{ color: "#C6A85E" }}>{form.email}</strong>
            </p>
            <form onSubmit={handleOTPSubmit} style={{ marginTop: 20 }}>
              <OTPInput value={otp} onChange={setOtp} error={!!otpError} disabled={loading} />
              {otpError && <div className="ait-error-msg" style={{ justifyContent: "center", marginTop: 10 }}><ErrorIcon /> {otpError}</div>}
              <button className="ait-btn-primary" type="submit" disabled={loading || otp.length < 6} style={{ marginTop: 24 }}>
                {loading ? <><span className="ait-spinner" /> Verifying...</> : "Confirm and Continue"}
              </button>
            </form>
            <div style={{ textAlign: "center", marginTop: 16, fontSize: 13, color: "#8A9AB0", fontFamily: "'Outfit', sans-serif" }}>
              Did not receive it?{' '}
              {resendTimer > 0 ? <span>Resend in {resendTimer}s</span> : (
                <button onClick={handleResend} style={{ background: "none", border: "none", color: "#C6A85E", cursor: "pointer", fontWeight: 600, fontFamily: "inherit", fontSize: "inherit" }}>Resend</button>
              )}
            </div>
          </div>
        )}

        {step === "confirmed" && (
          <div className="ait-auth-card" style={{ maxWidth: 440, textAlign: "center" }}>
            <div style={{ width: 64, height: 64, borderRadius: "50%", background: "rgba(198,168,94,0.12)", border: "1.5px solid rgba(198,168,94,0.3)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 24px" }}>
              <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
                <path d="M7 14l5 5 9-9" stroke="#C6A85E" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
            <h1 style={{ ...headingStyle, fontSize: 24 }}>{copy.confirmTitle}</h1>
            <p style={{ ...subStyle, marginTop: 12 }}>
              Thank you, <strong style={{ color: "#f0ece4" }}>{form.name}</strong>.<br />
              {mode === "view" ? "Preparing your demo access..." : "Our team will reach out shortly to schedule your session."}
            </p>

            <div style={{ marginTop: 28, padding: "20px", background: "rgba(198,168,94,0.06)", borderRadius: 12, border: "1px solid rgba(198,168,94,0.12)" }}>
              <p style={{ fontFamily: "'Outfit', sans-serif", fontSize: 12, color: "#C6A85E", fontWeight: 600, margin: "0 0 8px", letterSpacing: "0.8px" }}>WHAT HAPPENS NEXT</p>
              {copy.nextSteps.map((s, i) => (
                <p key={i} style={{ fontFamily: "'Outfit', sans-serif", fontSize: 13, color: "#8A9AB0", margin: "4px 0", lineHeight: 1.5 }}>
                  <span style={{ color: "#C6A85E" }}>0{i + 1}.</span> {s}
                </p>
              ))}
            </div>

            {autoRedirectUrl && (
              <a href={autoRedirectUrl} className="ait-btn-primary" style={{ marginTop: 20, textDecoration: "none" }}>
                Open Demo Now
              </a>
            )}

            {onBack && (
              <button onClick={onBack} className="ait-btn-ghost" style={{ marginTop: 14, width: "100%" }}>
                Choose Another Role
              </button>
            )}

            {onSignInClick && (
              <button onClick={onSignInClick} className="ait-btn-ghost" style={{ marginTop: 12, width: "100%" }}>
                Sign in to AIT
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function ErrorIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" style={{ flexShrink: 0 }}>
      <circle cx="6" cy="6" r="5.5" stroke="currentColor" />
      <path d="M6 3.5v3M6 8h.01" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}

function BackgroundDecor() {
  return (
    <div style={{ position: "fixed", inset: 0, overflow: "hidden", zIndex: 0, pointerEvents: "none" }}>
      <div style={{ position: "absolute", top: "5%", right: "-5%", width: "55vw", height: "55vw", borderRadius: "50%", background: "radial-gradient(circle, rgba(21,59,111,0.35) 0%, transparent 70%)" }} />
      <div style={{ position: "absolute", bottom: "0%", left: "0%", width: "45vw", height: "45vw", borderRadius: "50%", background: "radial-gradient(circle, rgba(198,168,94,0.05) 0%, transparent 70%)" }} />
    </div>
  );
}

const pageStyle = { minHeight: "100vh", background: "#080e1c", display: "flex", alignItems: "center", justifyContent: "center", padding: "20px 16px", position: "relative" };
const headingStyle = { fontFamily: "'DM Serif Display', Georgia, serif", fontSize: 26, fontWeight: 400, color: "#f0ece4", margin: 0, textAlign: "center" };
const subStyle = { fontFamily: "'Outfit', sans-serif", fontSize: 14, color: "#8A9AB0", textAlign: "center", margin: "8px 0 0", lineHeight: 1.6 };
const backBtnStyle = { background: "none", border: "none", color: "#8A9AB0", cursor: "pointer", fontFamily: "'Outfit', sans-serif", fontSize: 13, padding: 0, marginBottom: 20, display: "block" };
const selectStyle = { cursor: "pointer", appearance: "none", backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8' fill='none'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%238A9AB0' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")`, backgroundRepeat: "no-repeat", backgroundPosition: "calc(100% - 14px) center" };
