﻿import { useState, useEffect, useRef } from "react";

const C = {
  navy: "#0f2240", navyMid: "#1a3a6b", navyLt: "#e8eef8",
  gold: "#b8912a", goldLt: "#fdf6e3",
  green: "#1a6644", greenLt: "#e8f5ee",
  border: "#e2e8f0", bg: "#f4f6fb",
  white: "#ffffff", text: "#1e293b", textSub: "#64748b",
};

const PHASES = [
  { id: "vendor_open", dur: 2800, dot: null },
  { id: "dot_v_ait", dur: 900, dot: { from: "vendor", to: "ait", color: C.navyMid } },
  { id: "ait_validate", dur: 3200, dot: null },
  { id: "dot_ait_cust", dur: 900, dot: { from: "ait", to: "customer", color: C.gold } },
  { id: "cust_open", dur: 2400, dot: null },
  { id: "dot_cust_ait", dur: 900, dot: { from: "customer", to: "ait", color: C.navyMid } },
  { id: "ait_batch", dur: 2400, dot: null },
  { id: "dot_ait_ca", dur: 900, dot: { from: "ait", to: "ca", color: C.green } },
  { id: "ca_open", dur: 2600, dot: null },
  { id: "dot_ca_ait", dur: 900, dot: { from: "ca", to: "ait", color: C.navyMid } },
  { id: "ait_file", dur: 3000, dot: null },
  { id: "dot_ait_gst", dur: 900, dot: { from: "ait", to: "gst", color: C.green } },
  { id: "gst_open", dur: 800, dot: null },
  { id: "dot_gst_ait", dur: 900, dot: { from: "gst", to: "ait", color: "#22c55e" } },
  { id: "ait_filed", dur: 1600, dot: null },
  { id: "done", dur: 3200, dot: null },
];
const LOOP = PHASES.reduce((s, p) => s + p.dur, 0);

function buildTL() {
  let t = 0;
  return PHASES.map(p => { const s = t; t += p.dur; return { ...p, start: s, end: t }; });
}
const TL = buildTL();

function usePhase(started) {
  const [ms, setMs] = useState(0);
  const rafRef = useRef(null);
  useEffect(() => {
    if (!started) return;
    const s = performance.now();
    function tick(n) { setMs((n - s) % LOOP); rafRef.current = requestAnimationFrame(tick); }
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [started]);
  const cur = TL.find(p => ms >= p.start && ms < p.end) || TL[0];
  return { cur, phaseMs: ms - cur.start };
}

function useLayout(ref) {
  const [layout, setLayout] = useState({ isMobile: false, CW: 240, CH: 176, CARD_W: 110 });
  useEffect(() => {
    function update() {
      const el = ref.current;
      if (!el) return;
      const rootW = el.getBoundingClientRect().width;
      const isMobile = rootW < 560;
      if (isMobile) {
        const avail = rootW - 16;
        const CARD_W = Math.max(90, Math.min(130, Math.floor((avail - 12) / 3)));
        setLayout({ isMobile, CW: CARD_W, CH: Math.round(CARD_W * (178 / 240)), CARD_W });
      } else {
        const CW = Math.max(140, Math.min(260, Math.floor(rootW / 3)));
        setLayout({ isMobile, CW, CH: Math.round(CW * (178 / 240)), CARD_W: CW });
      }
    }
    update();
    const ro = new ResizeObserver(update);
    if (ref.current) ro.observe(ref.current);
    return () => ro.disconnect();
  }, [ref]);
  return layout;
}

function DotCanvas({ nodeRefs, wrapRef, dot, phaseMs, phaseDur }) {
  const canvasRef = useRef(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const cssW = wrap.clientWidth, cssH = wrap.clientHeight;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.max(1, Math.round(cssW * dpr));
    canvas.height = Math.max(1, Math.round(cssH * dpr));
    canvas.style.width = cssW + "px"; canvas.style.height = cssH + "px";
    const ctx = canvas.getContext("2d");
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, cssW, cssH);
    if (!dot) return;
    const fromEl = nodeRefs[dot.from]?.current, toEl = nodeRefs[dot.to]?.current;
    if (!fromEl || !toEl) return;
    const wr = wrap.getBoundingClientRect();
    const fR = fromEl.getBoundingClientRect(), tR = toEl.getBoundingClientRect();
    const sx = wr.width / (cssW || 1), sy = wr.height / (cssH || 1);
    const fx = (fR.left + fR.width / 2 - wr.left) / sx, fy = (fR.top + fR.height / 2 - wr.top) / sy;
    const tx = (tR.left + tR.width / 2 - wr.left) / sx, ty = (tR.top + tR.height / 2 - wr.top) / sy;
    const raw = Math.min(1, phaseMs / phaseDur);
    const e = raw < 0.5 ? 2 * raw * raw : 1 - Math.pow(-2 * raw + 2, 2) / 2;
    const cx = fx + (tx - fx) * e, cy = fy + (ty - fy) * e;
    const op = raw < 0.1 ? raw / 0.1 : raw > 0.9 ? (1 - raw) / 0.1 : 1;
    const h = dot.color.replace("#", "");
    const r = parseInt(h.slice(0, 2), 16), g = parseInt(h.slice(2, 4), 16), b = parseInt(h.slice(4, 6), 16);
    for (let i = 3; i >= 1; i--) {
      const tr = Math.max(0, raw - i * 0.06), te = tr < 0.5 ? 2 * tr * tr : 1 - Math.pow(-2 * tr + 2, 2) / 2;
      ctx.beginPath(); ctx.arc(fx + (tx - fx) * te, fy + (ty - fy) * te, 3 - i * 0.5, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(${r},${g},${b},${op * (0.25 - i * 0.06)})`; ctx.fill();
    }
    const gw = ctx.createRadialGradient(cx, cy, 0, cx, cy, 18);
    gw.addColorStop(0, `rgba(${r},${g},${b},${op * 0.22})`); gw.addColorStop(1, `rgba(${r},${g},${b},0)`);
    ctx.beginPath(); ctx.arc(cx, cy, 18, 0, Math.PI * 2); ctx.fillStyle = gw; ctx.fill();
    const iw = ctx.createRadialGradient(cx, cy, 0, cx, cy, 8);
    iw.addColorStop(0, `rgba(${r},${g},${b},${op * 0.5})`); iw.addColorStop(1, `rgba(${r},${g},${b},0)`);
    ctx.beginPath(); ctx.arc(cx, cy, 8, 0, Math.PI * 2); ctx.fillStyle = iw; ctx.fill();
    ctx.beginPath(); ctx.arc(cx, cy, 4, 0, Math.PI * 2); ctx.fillStyle = `rgba(${r},${g},${b},${op})`; ctx.fill();
    ctx.beginPath(); ctx.arc(cx, cy, 1.8, 0, Math.PI * 2); ctx.fillStyle = `rgba(255,255,255,${op * 0.9})`; ctx.fill();
  }, [dot, phaseMs, phaseDur, nodeRefs, wrapRef]);
  return <canvas ref={canvasRef} style={{ position: "absolute", inset: 0, pointerEvents: "none", zIndex: 30 }} />;
}

function MobileLines({ nodeRefs, wrapRef }) {
  const svgRef = useRef(null);
  useEffect(() => {
    const svg = svgRef.current, wrap = wrapRef.current;
    if (!svg || !wrap) return;
    function draw() {
      const wr = wrap.getBoundingClientRect();
      const h = wrap.offsetHeight;
      svg.style.width = wr.width + "px"; svg.style.height = h + "px";
      svg.setAttribute("viewBox", `0 0 ${wr.width} ${h}`);
      svg.setAttribute("width", wr.width); svg.setAttribute("height", h);
      function mid(key) {
        const el = nodeRefs[key]?.current; if (!el) return null;
        const r = el.getBoundingClientRect();
        return { x: r.left + r.width / 2 - wr.left, y: r.top + r.height / 2 - wr.top };
      }
      const hub = mid("ait"), vend = mid("vendor"), cust = mid("customer"), ca = mid("ca"), gst = mid("gst");
      if (!hub || !vend || !cust || !ca || !gst) return;
      function line(a, b, color) {
        return `<line x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" stroke="${color}" stroke-width="1.5" stroke-dasharray="4 4" opacity="0.35" stroke-linecap="round"/>`;
      }
      svg.innerHTML = line(hub, vend, C.navyMid) + line(hub, cust, C.gold) + line(hub, ca, C.green) + line(hub, gst, C.green);
    }
    draw();
    const ro = new ResizeObserver(draw); ro.observe(wrap);
    return () => ro.disconnect();
  }, [nodeRefs, wrapRef]);
  return <svg ref={svgRef} style={{ position: "absolute", top: 0, left: 0, pointerEvents: "none", zIndex: 1, overflow: "visible" }} xmlns="http://www.w3.org/2000/svg" />;
}

function Bar({ pct, color, h = 3 }) {
  return (
    <div style={{ height: h, background: "#e8eef5", borderRadius: h, overflow: "hidden" }}>
      <div style={{ height: "100%", borderRadius: h, background: color, width: `${pct}%`, transition: "width 0.4s linear", boxShadow: `0 0 6px ${color}55` }} />
    </div>
  );
}

function SmallCard({ title, sub, icon, done, dimmed, isMobile }) {
  const pad = isMobile ? "7px 9px" : "10px 14px";
  const icSz = isMobile ? 22 : 28;
  const nameSz = isMobile ? 9 : 11.5;
  const subSz = isMobile ? 7.5 : 9.5;
  return (
    <div style={{ background: C.white, borderRadius: 14, border: `1.5px solid ${done ? C.green + "28" : C.border}`, boxShadow: "0 1px 4px rgba(0,0,0,0.04)", padding: pad, display: "flex", alignItems: "center", gap: 9, opacity: dimmed ? 0.38 : 1, transition: "opacity 0.4s" }}>
      <div style={{ width: icSz, height: icSz, borderRadius: 8, flexShrink: 0, background: done ? `${C.green}12` : "#f1f5f9", display: "flex", alignItems: "center", justifyContent: "center" }}>{icon}</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: nameSz, fontWeight: 700, color: done ? C.green : C.text, fontFamily: "'DM Sans',sans-serif", lineHeight: 1.2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{title}</div>
        <div style={{ fontSize: subSz, color: C.textSub, fontFamily: "'DM Sans',sans-serif", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{sub}</div>
      </div>
      {done && <div style={{ width: 18, height: 18, borderRadius: "50%", background: C.green, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><svg width="9" height="8" viewBox="0 0 10 9" fill="none"><path d="M1.5 4.5l2.5 3 4.5-6" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg></div>}
    </div>
  );
}

const I = {
  doc: (c) => <svg width="15" height="15" viewBox="0 0 16 16" fill="none"><rect x="2.5" y="1.5" width="11" height="13" rx="1.5" stroke={c} strokeWidth="1.4" /><path d="M5 6h6M5 8.5h6M5 11h4" stroke={c} strokeWidth="1.1" strokeLinecap="round" /></svg>,
  biz: (c) => <svg width="15" height="15" viewBox="0 0 16 16" fill="none"><rect x="2" y="5" width="12" height="9" rx="1.5" stroke={c} strokeWidth="1.4" /><path d="M5 5V4a3 3 0 016 0v1" stroke={c} strokeWidth="1.3" strokeLinecap="round" /></svg>,
  ca: (c) => <svg width="15" height="15" viewBox="0 0 16 16" fill="none"><path d="M3 2a1 1 0 011-1h8a1 1 0 011 1v12a1 1 0 01-1 1H4a1 1 0 01-1-1V2z" stroke={c} strokeWidth="1.4" /><path d="M5.5 6h5M5.5 8.5h5M5.5 11h3" stroke={c} strokeWidth="1.1" strokeLinecap="round" /></svg>,
  gst: (c) => <svg width="15" height="15" viewBox="0 0 16 16" fill="none"><path d="M8 1.5a6.5 6.5 0 100 13A6.5 6.5 0 008 1.5z" stroke={c} strokeWidth="1.4" /><path d="M5.5 8.5l2 2 3.5-4.5" stroke={c} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" /></svg>,
  star: () => <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M8 1.5l1.2 2.3 2.5.37-1.82 1.77.43 2.5L8 7.3 5.67 8.44l.43-2.5L4.28 4.17l2.5-.37L8 1.5z" stroke="#b8912a" fill="rgba(184,145,42,0.18)" strokeWidth="1.3" strokeLinejoin="round" /></svg>,
};

function phaseIndex(id) { return TL.findIndex(p => p.id === id); }

function AITCard({ phaseId, phaseMs, isMobile, cardW }) {
  const isOpen = ["ait_validate", "ait_batch", "ait_file", "ait_filed"].includes(phaseId);
  const curI = phaseIndex(phaseId);
  const label = phaseId === "ait_validate" ? "VALIDATING" : phaseId === "ait_batch" ? "BATCHING" : phaseId === "ait_file" ? "FILING" : phaseId === "ait_filed" ? "COMPLETE" : "READY";
  const valChecks = phaseId === "ait_validate" ? Math.min(6, Math.floor(phaseMs / 490) + 1) : 0;
  const batchCount = phaseId === "ait_batch" ? (phaseMs > 600 ? 42 : 41) : 41;
  const fileStep = phaseId === "ait_file" ? Math.min(3, Math.floor(phaseMs / 700) + 1) : 0;
  const isFiled = phaseId === "ait_filed";
  const dimmed = !isOpen && curI < phaseIndex("ait_validate");
  const pad = isMobile ? (isOpen ? "12px 12px 10px" : "9px 12px") : (isOpen ? "20px 22px 18px" : "14px 20px");
  const w = isMobile ? cardW : (isOpen ? 244 : 204);
  const fSz = isMobile ? 12 : 15;
  const mSz = isMobile ? 7 : 9;
  const iSz = isMobile ? 9 : 10.5;
  return (
    <div style={{ background: C.navy, borderRadius: 20, border: "1.5px solid rgba(184,145,42,0.35)", boxShadow: isOpen ? "0 0 0 5px rgba(184,145,42,0.1),0 0 0 10px rgba(184,145,42,0.05),0 20px 60px rgba(15,34,64,0.4)" : "0 8px 32px rgba(15,34,64,0.25)", padding: pad, transition: "all 0.55s cubic-bezier(0.16,1,0.3,1)", position: "relative", overflow: "hidden", width: w, opacity: dimmed ? 0.6 : 1 }}>
      <div style={{ position: "absolute", top: 0, left: 20, right: 20, height: 2, background: "linear-gradient(90deg,transparent,#b8912a,transparent)", borderRadius: 2 }} />
      {isOpen && <div style={{ position: "absolute", inset: -10, borderRadius: 30, border: "1.5px solid rgba(184,145,42,0.15)", animation: "rp 2.5s ease-in-out infinite", pointerEvents: "none" }} />}
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: isOpen ? (isMobile ? 10 : 16) : 0 }}>
        <div style={{ width: isMobile ? 28 : 36, height: isMobile ? 28 : 36, borderRadius: 10, background: "rgba(184,145,42,0.12)", border: "1px solid rgba(184,145,42,0.28)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>{I.star()}</div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: fSz, fontWeight: 800, color: "#fff", fontFamily: "'DM Sans',sans-serif", lineHeight: 1.1 }}>AIT</div>
          <div style={{ fontSize: mSz, color: "rgba(255,255,255,0.38)", fontFamily: "'JetBrains Mono',monospace", letterSpacing: "1px" }}>{label}</div>
        </div>
        {isFiled && <div style={{ width: 22, height: 22, borderRadius: "50%", background: C.green, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, animation: "scaleIn 0.4s ease" }}><svg width="11" height="10" viewBox="0 0 11 10" fill="none"><path d="M1.5 5l3 3.5 5-7" stroke="white" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" /></svg></div>}
      </div>
      {phaseId === "ait_validate" && (
        <div style={{ animation: "fu 0.3s ease" }}>
          <div style={{ fontSize: mSz, color: "rgba(255,255,255,0.3)", fontFamily: "'JetBrains Mono',monospace", marginBottom: isMobile ? 5 : 8, letterSpacing: "0.5px" }}>AI CHECKS · {valChecks}/6</div>
          <div style={{ marginBottom: isMobile ? 6 : 10 }}><Bar pct={valChecks / 6 * 100} color={C.gold} h={3} /></div>
          <div style={{ display: "flex", flexDirection: "column", gap: isMobile ? 3 : 5 }}>
            {["Invoice format", "GSTIN match", "Duplicate scan", "Tax calculation", "ITC eligibility", "Compliance risk"].map((c, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 7, opacity: i < valChecks ? 1 : 0.22, transition: "opacity 0.3s" }}>
                <div style={{ width: isMobile ? 10 : 13, height: isMobile ? 10 : 13, borderRadius: "50%", flexShrink: 0, background: i < valChecks ? C.gold : "transparent", border: `1.5px solid ${i < valChecks ? C.gold : "rgba(255,255,255,0.18)"}`, display: "flex", alignItems: "center", justifyContent: "center", transition: "all 0.3s" }}>
                  {i < valChecks && <svg width="6" height="6" viewBox="0 0 8 7" fill="none"><path d="M1 3.5l2 2 4-4" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg>}
                </div>
                <span style={{ fontSize: iSz, color: "rgba(255,255,255,0.7)", fontFamily: "'DM Sans',sans-serif" }}>{c}</span>
                {i < valChecks && <span style={{ marginLeft: "auto", fontSize: mSz, color: C.gold, fontFamily: "'JetBrains Mono',monospace", fontWeight: 600 }}>Pass</span>}
              </div>
            ))}
          </div>
        </div>
      )}
      {phaseId === "ait_batch" && (
        <div style={{ animation: "fu 0.3s ease" }}>
          <div style={{ fontSize: mSz, color: "rgba(255,255,255,0.3)", fontFamily: "'JetBrains Mono',monospace", marginBottom: isMobile ? 5 : 8, letterSpacing: "0.5px" }}>CA BATCH · FEB 2026</div>
          <div style={{ display: "flex", alignItems: "baseline", gap: 8, marginBottom: 6 }}>
            <span style={{ fontSize: isMobile ? 22 : 32, fontWeight: 800, color: "#fff", fontFamily: "'DM Sans',sans-serif" }}>{batchCount}</span>
            <span style={{ fontSize: isMobile ? 8 : 11, color: "rgba(255,255,255,0.35)", fontFamily: "'DM Sans',sans-serif" }}>invoices</span>
          </div>
          {batchCount === 42 && <div style={{ fontSize: iSz, color: C.gold, fontFamily: "'DM Sans',sans-serif", marginBottom: isMobile ? 6 : 10, animation: "fu 0.3s ease" }}>↑ Just added</div>}
          <div style={{ display: "flex", gap: 7 }}>
            {[{ l: "Taxable", v: "₹49.4 L" }, { l: "GST", v: "₹8.89 L" }].map((s, i) => (
              <div key={i} style={{ flex: 1, background: "rgba(255,255,255,0.05)", borderRadius: 7, padding: "6px 8px" }}>
                <div style={{ fontSize: isMobile ? 7 : 9, color: "rgba(255,255,255,0.28)", fontFamily: "'DM Sans',sans-serif" }}>{s.l}</div>
                <div style={{ fontSize: isMobile ? 10 : 12, fontWeight: 700, color: C.gold, fontFamily: "'DM Sans',sans-serif" }}>{s.v}</div>
              </div>
            ))}
          </div>
        </div>
      )}
      {phaseId === "ait_file" && (
        <div style={{ animation: "fu 0.3s ease" }}>
          <div style={{ fontSize: mSz, color: "rgba(255,255,255,0.3)", fontFamily: "'JetBrains Mono',monospace", marginBottom: isMobile ? 5 : 8, letterSpacing: "0.5px" }}>FILING 42 INVOICES</div>
          <div style={{ display: "flex", gap: 5, marginBottom: isMobile ? 7 : 10 }}>
            {["GSTR-1", "GSTR-3B", "Recon"].map((d, i) => (
              <div key={i} style={{ flex: 1, textAlign: "center", borderRadius: 7, padding: isMobile ? "5px 2px" : "7px 3px", background: i < fileStep ? "rgba(26,102,68,0.22)" : "rgba(255,255,255,0.05)", border: `1px solid ${i < fileStep ? "rgba(26,102,68,0.4)" : "rgba(255,255,255,0.07)"}`, opacity: i < fileStep ? 1 : 0.25, transition: "all 0.45s" }}>
                <div style={{ fontSize: isMobile ? 7.5 : 9.5, fontWeight: 700, color: i < fileStep ? "#4ade80" : "rgba(255,255,255,0.35)", fontFamily: "'JetBrains Mono',monospace" }}>{d}</div>
              </div>
            ))}
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 7, padding: isMobile ? "5px 8px" : "7px 10px", borderRadius: 7, background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)" }}>
            <div style={{ width: 8, height: 8, borderRadius: "50%", border: "2px solid rgba(184,145,42,0.7)", borderTopColor: "transparent", animation: "spin 0.9s linear infinite", flexShrink: 0 }} />
            <span style={{ fontSize: isMobile ? 8.5 : 10.5, color: "rgba(255,255,255,0.45)", fontFamily: "'DM Sans',sans-serif" }}>Syncing with GST portal…</span>
          </div>
        </div>
      )}
      {isFiled && (
        <div style={{ animation: "fu 0.35s ease", padding: isMobile ? "7px 9px" : "10px 12px", borderRadius: 9, background: "rgba(26,102,68,0.2)", border: "1px solid rgba(26,102,68,0.38)" }}>
          <div style={{ fontSize: isMobile ? 9 : 11, fontWeight: 700, color: "#4ade80", fontFamily: "'DM Sans',sans-serif", marginBottom: 3 }}>Filed successfully</div>
          <div style={{ fontSize: isMobile ? 7 : 9.5, color: "rgba(255,255,255,0.38)", fontFamily: "'JetBrains Mono',monospace" }}>ARN: GST2026/FEB/1847263</div>
        </div>
      )}
    </div>
  );
}

function VendorCard({ phaseId, phaseMs, isMobile, cardW }) {
  const isOpen = phaseId === "vendor_open";
  const curI = phaseIndex(phaseId);
  const isDone = curI > phaseIndex("vendor_open");
  const dimmed = !isOpen && !isDone;
  const uploadPct = isOpen ? Math.min(100, (phaseMs / 1800) * 100) : isDone ? 100 : 0;
  const fields = isOpen ? [phaseMs > 400, phaseMs > 800, phaseMs > 1200] : isDone ? [true, true, true] : [false, false, false];
  if (!isOpen) return <SmallCard title="Vendor" sub="Factwise Portal" icon={I.doc(isDone ? C.green : C.navyMid)} done={isDone} dimmed={dimmed} isMobile={isMobile} />;
  const w = isMobile ? cardW : 230;
  const p = isMobile ? "12px 12px 10px" : "18px 18px 16px";
  const iSz = isMobile ? 9 : 10.5;
  const mSz = isMobile ? 7 : 9.5;
  return (
    <div style={{ background: C.white, borderRadius: 16, border: `1.5px solid ${C.navyMid}44`, boxShadow: `0 0 0 4px ${C.navyMid}0e,0 12px 40px ${C.navyMid}14`, padding: p, position: "relative", overflow: "hidden", width: w, animation: "expandCard 0.4s cubic-bezier(0.16,1,0.3,1)" }}>
      <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 2.5, background: `linear-gradient(90deg,${C.navyMid},${C.navyMid}77)`, borderRadius: "16px 16px 0 0" }} />
      <div style={{ display: "flex", alignItems: "center", gap: 9, marginBottom: isMobile ? 10 : 14 }}>
        <div style={{ width: isMobile ? 22 : 30, height: isMobile ? 22 : 30, borderRadius: 8, background: C.navyLt, display: "flex", alignItems: "center", justifyContent: "center" }}>{I.doc(C.navyMid)}</div>
        <div><div style={{ fontSize: isMobile ? 9 : 12, fontWeight: 700, color: C.navyMid, fontFamily: "'DM Sans',sans-serif" }}>Vendor</div><div style={{ fontSize: isMobile ? 7.5 : 9.5, color: C.textSub }}>Factwise Portal</div></div>
      </div>
      <div style={{ fontSize: mSz, color: C.textSub, fontFamily: "'JetBrains Mono',monospace", marginBottom: isMobile ? 7 : 10, letterSpacing: "0.5px" }}>UPLOADING</div>
      <div style={{ background: "#f8fafc", border: "1px solid #e8eef5", borderRadius: 8, padding: isMobile ? "7px 9px" : "9px 11px", display: "flex", gap: 9, alignItems: "center", marginBottom: isMobile ? 7 : 10 }}>
        <div style={{ width: isMobile ? 22 : 26, height: isMobile ? 28 : 32, background: C.navyLt, borderRadius: 5, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
          <svg width="11" height="13" viewBox="0 0 12 14" fill="none"><path d="M1.5 2a1 1 0 011-1h5l3 3v8a1 1 0 01-1 1H2.5a1 1 0 01-1-1V2z" stroke={C.navyMid} strokeWidth="1.2" /><path d="M7.5 1v3h3" stroke={C.navyMid} strokeWidth="1.1" strokeLinecap="round" /></svg>
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: iSz, fontWeight: 600, color: C.text, fontFamily: "'DM Sans',sans-serif", marginBottom: 4, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>INV-2026-0842.pdf</div>
          <Bar pct={uploadPct} color={C.navyMid} h={3} />
          <div style={{ fontSize: isMobile ? 7.5 : 9, color: C.textSub, marginTop: 2 }}>{uploadPct >= 100 ? "Done" : "Uploading…"}</div>
        </div>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: isMobile ? 4 : 6 }}>
        {[["Invoice", "INV-2026-0842"], ["GSTIN", "29AABCU9603R"], ["Amt", "₹1,18,000"]].map(([l, v], i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div style={{ width: isMobile ? 10 : 13, height: isMobile ? 10 : 13, borderRadius: "50%", flexShrink: 0, background: fields[i] ? C.green : "transparent", border: `1.5px solid ${fields[i] ? C.green : "#cbd5e1"}`, display: "flex", alignItems: "center", justifyContent: "center", transition: "all 0.3s" }}>
              {fields[i] && <svg width="6" height="5" viewBox="0 0 8 7" fill="none"><path d="M1 3.5l2 2 4-4" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg>}
            </div>
            <span style={{ fontSize: isMobile ? 7.5 : 10.5, color: C.textSub, flex: 1 }}>{l}</span>
            <span style={{ fontSize: isMobile ? 7.5 : 10.5, fontWeight: 600, color: fields[i] ? C.text : "#cbd5e1", fontFamily: "'JetBrains Mono',monospace", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{v}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function CustomerCard({ phaseId, phaseMs, isMobile, cardW }) {
  const isOpen = phaseId === "cust_open";
  const curI = phaseIndex(phaseId);
  const isDone = curI > phaseIndex("cust_open");
  const dimmed = curI < phaseIndex("cust_open") && !isOpen;
  const approved = isOpen && phaseMs > 1700;
  if (!isOpen) return <SmallCard title="Customer" sub="Finance Team" icon={I.biz(isDone ? C.green : C.navyMid)} done={isDone} dimmed={dimmed} isMobile={isMobile} />;
  const w = isMobile ? cardW : 230;
  const p = isMobile ? "12px 12px 10px" : "18px 18px 16px";
  return (
    <div style={{ background: C.white, borderRadius: 16, border: `1.5px solid ${C.navyMid}44`, boxShadow: `0 0 0 4px ${C.navyMid}0e,0 12px 40px ${C.navyMid}14`, padding: p, position: "relative", overflow: "hidden", width: w, animation: "expandCard 0.4s cubic-bezier(0.16,1,0.3,1)" }}>
      <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 2.5, background: `linear-gradient(90deg,${C.navyMid},${C.navyMid}77)`, borderRadius: "16px 16px 0 0" }} />
      <div style={{ display: "flex", alignItems: "center", gap: 9, marginBottom: isMobile ? 10 : 14 }}>
        <div style={{ width: isMobile ? 22 : 30, height: isMobile ? 22 : 30, borderRadius: 8, background: C.navyLt, display: "flex", alignItems: "center", justifyContent: "center" }}>{I.biz(C.navyMid)}</div>
        <div><div style={{ fontSize: isMobile ? 9 : 12, fontWeight: 700, color: C.navyMid }}>Customer</div><div style={{ fontSize: isMobile ? 7.5 : 9.5, color: C.textSub }}>Finance Team</div></div>
      </div>
      <div style={{ fontSize: isMobile ? 7 : 9.5, color: C.textSub, fontFamily: "'JetBrains Mono',monospace", marginBottom: isMobile ? 7 : 10, letterSpacing: "0.5px" }}>REVIEW & APPROVE</div>
      <div style={{ background: "#f8fafc", border: "1px solid #e8eef5", borderRadius: 9, padding: isMobile ? "8px 9px" : "10px 12px", marginBottom: isMobile ? 7 : 10 }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: isMobile ? 5 : 7 }}>
          <div><div style={{ fontSize: isMobile ? 7 : 9.5, color: C.textSub }}>Vendor</div><div style={{ fontSize: isMobile ? 9 : 12, fontWeight: 600, color: C.text }}>Apex Supplies</div></div>
          <div style={{ textAlign: "right" }}><div style={{ fontSize: isMobile ? 7 : 9.5, color: C.textSub }}>Amount</div><div style={{ fontSize: isMobile ? 11 : 14, fontWeight: 700, color: C.navy }}>₹1,18,000</div></div>
        </div>
        <div style={{ display: "flex", gap: 7 }}>
          {[{ l: "ITC", v: "₹18,000", c: C.green }, { l: "Trust", v: "94/100", c: C.gold }].map((b, i) => (
            <div key={i} style={{ flex: 1, background: `${b.c}0d`, border: `1px solid ${b.c}22`, borderRadius: 7, padding: isMobile ? "4px 5px" : "5px 7px" }}>
              <div style={{ fontSize: isMobile ? 7 : 8.5, color: b.c }}>{b.l}</div>
              <div style={{ fontSize: isMobile ? 9 : 11, fontWeight: 700, color: b.c }}>{b.v}</div>
            </div>
          ))}
        </div>
      </div>
      <div style={{ height: isMobile ? 28 : 33, borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", gap: 7, background: approved ? `${C.green}14` : C.navyMid, border: `1px solid ${approved ? `${C.green}30` : "transparent"}`, transition: "all 0.55s" }}>
        {approved
          ? <><div style={{ width: 14, height: 14, borderRadius: "50%", background: C.green, display: "flex", alignItems: "center", justifyContent: "center" }}><svg width="7" height="6" viewBox="0 0 8 7" fill="none"><path d="M1 3.5l2 2 4-4" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg></div><span style={{ fontSize: isMobile ? 8 : 11, fontWeight: 600, color: C.green }}>Approved</span></>
          : <span style={{ fontSize: isMobile ? 8 : 11, fontWeight: 600, color: "white" }}>Approve Invoice</span>
        }
      </div>
    </div>
  );
}

function CACard({ phaseId, phaseMs, isMobile, cardW }) {
  const isOpen = phaseId === "ca_open";
  const curI = phaseIndex(phaseId);
  const isDone = curI > phaseIndex("ca_open");
  const dimmed = curI < phaseIndex("ca_open") && !isOpen;
  const caChecks = isOpen ? Math.min(3, Math.floor(phaseMs / 600) + 1) : isDone ? 3 : 0;
  if (!isOpen) return <SmallCard title="CA Firm" sub="Compliance Review" icon={I.ca(isDone ? C.green : C.navyMid)} done={isDone} dimmed={dimmed} isMobile={isMobile} />;
  const w = isMobile ? cardW : 230;
  const p = isMobile ? "12px 12px 10px" : "18px 18px 16px";
  return (
    <div style={{ background: C.white, borderRadius: 16, border: `1.5px solid ${C.green}44`, boxShadow: `0 0 0 4px ${C.green}0e,0 12px 40px ${C.green}12`, padding: p, position: "relative", overflow: "hidden", width: w, animation: "expandCard 0.4s cubic-bezier(0.16,1,0.3,1)" }}>
      <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 2.5, background: `linear-gradient(90deg,${C.green},${C.green}77)`, borderRadius: "16px 16px 0 0" }} />
      <div style={{ display: "flex", alignItems: "center", gap: 9, marginBottom: isMobile ? 10 : 14 }}>
        <div style={{ width: isMobile ? 22 : 30, height: isMobile ? 22 : 30, borderRadius: 8, background: C.greenLt, display: "flex", alignItems: "center", justifyContent: "center" }}>{I.ca(C.green)}</div>
        <div><div style={{ fontSize: isMobile ? 9 : 12, fontWeight: 700, color: C.green }}>CA Firm</div><div style={{ fontSize: isMobile ? 7.5 : 9.5, color: C.textSub }}>Compliance Review</div></div>
      </div>
      <div style={{ fontSize: isMobile ? 7 : 9.5, color: C.textSub, fontFamily: "'JetBrains Mono',monospace", marginBottom: isMobile ? 7 : 10, letterSpacing: "0.5px" }}>COMPLIANCE REVIEW</div>
      <div style={{ display: "flex", flexDirection: "column", gap: isMobile ? 5 : 7 }}>
        {["GSTR-2B recon", "ITC cross-verify", "Risk review"].map((c, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 8, opacity: i < caChecks ? 1 : 0.25, transition: "opacity 0.35s" }}>
            <div style={{ width: isMobile ? 10 : 14, height: isMobile ? 10 : 14, borderRadius: "50%", flexShrink: 0, background: i < caChecks ? C.green : "transparent", border: `1.5px solid ${i < caChecks ? C.green : "#cbd5e1"}`, display: "flex", alignItems: "center", justifyContent: "center", transition: "all 0.3s" }}>
              {i < caChecks && <svg width="6" height="6" viewBox="0 0 8 7" fill="none"><path d="M1 3.5l2 2 4-4" stroke="white" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" /></svg>}
            </div>
            <span style={{ fontSize: isMobile ? 8 : 11, color: C.text }}>{c}</span>
          </div>
        ))}
      </div>
      {caChecks === 3 && (
        <div style={{ marginTop: isMobile ? 7 : 10, padding: isMobile ? "5px 8px" : "7px 11px", borderRadius: 8, background: `${C.green}0f`, border: `1px solid ${C.green}25`, fontSize: isMobile ? 8.5 : 10.5, fontWeight: 600, color: C.green, animation: "fu 0.35s ease", display: "flex", alignItems: "center", gap: 6 }}>
          <div style={{ width: isMobile ? 10 : 14, height: isMobile ? 10 : 14, borderRadius: "50%", background: C.green, display: "flex", alignItems: "center", justifyContent: "center" }}><svg width="7" height="6" viewBox="0 0 8 7" fill="none"><path d="M1 3.5l2 2 4-4" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg></div>
          Compliant · Ready
        </div>
      )}
    </div>
  );
}

function GSTCard({ phaseId, phaseMs, isMobile, cardW }) {
  const isOpen = phaseId === "gst_open";
  const curI = phaseIndex(phaseId);
  const isDone = curI > phaseIndex("gst_open");
  const dimmed = curI < phaseIndex("gst_open") && !isOpen;
  if (!isOpen) return <SmallCard title="GST Portal" sub="Gov. System" icon={I.gst(isDone ? C.green : C.navyMid)} done={isDone} dimmed={dimmed} isMobile={isMobile} />;
  const w = isMobile ? cardW : 200;
  const p = isMobile ? "12px 12px 10px" : "18px 18px 16px";
  return (
    <div style={{ background: "linear-gradient(135deg,#1a4428,#0f2d1a)", borderRadius: 16, border: "1.5px solid rgba(74,222,128,0.38)", boxShadow: "0 0 0 5px rgba(74,222,128,0.07),0 12px 32px rgba(26,102,68,0.25)", padding: p, position: "relative", overflow: "hidden", width: w, animation: "expandCard 0.4s cubic-bezier(0.16,1,0.3,1)" }}>
      <div style={{ position: "absolute", inset: -8, borderRadius: 24, border: "1.5px solid rgba(74,222,128,0.15)", animation: "rp 1.4s ease-in-out infinite", pointerEvents: "none" }} />
      <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
        <div style={{ width: isMobile ? 22 : 30, height: isMobile ? 22 : 30, borderRadius: 8, background: "rgba(74,222,128,0.12)", display: "flex", alignItems: "center", justifyContent: "center" }}>{I.gst("#4ade80")}</div>
        <div><div style={{ fontSize: isMobile ? 9 : 12, fontWeight: 700, color: "#fff" }}>GST Portal</div><div style={{ fontSize: isMobile ? 7 : 9.5, color: "rgba(255,255,255,0.4)", fontFamily: "'JetBrains Mono',monospace" }}>ACCEPTING</div></div>
      </div>
    </div>
  );
}

const STAGE_MAP = {
  vendor_open: 0, dot_v_ait: 0, ait_validate: 1, dot_ait_cust: 1,
  cust_open: 2, dot_cust_ait: 2, ait_batch: 3, dot_ait_ca: 3,
  ca_open: 4, dot_ca_ait: 4, ait_file: 5, dot_ait_gst: 5, gst_open: 5, dot_gst_ait: 5, ait_filed: 5, done: 6,
};
const STAGE_LABELS = ["Vendor", "AI Validate", "Approve", "Batch", "CA Review", "Filing", "Done"];

export default function AIT_Hub({ hideHeader = false }) {
  const [started, setStarted] = useState(false);
  const outerRef = useRef(null);
  const wrapRef = useRef(null);
  const { cur, phaseMs } = usePhase(started);
  const { isMobile, CW, CH, CARD_W } = useLayout(outerRef);

  const nodeRefs = {
    vendor: useRef(null),
    ait: useRef(null),
    customer: useRef(null),
    ca: useRef(null),
    gst: useRef(null),
  };

  useEffect(() => {
    const el = outerRef.current; if (!el) return;
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setStarted(true); obs.disconnect(); } }, { threshold: 0.1 });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  const phaseId = cur.id;
  const isDone = phaseId === "done";
  const curStage = STAGE_MAP[phaseId] ?? 0;
  const gridW = isMobile ? CARD_W * 3 + 6 * 2 : CW * 3;

  return (
    <div ref={outerRef} style={{ padding: "0", fontFamily: "'Outfit',sans-serif", overflow: "hidden" }}>
      <style>{`
        @keyframes fu { from{opacity:0;transform:translateY(7px)} to{opacity:1;transform:none} }
        @keyframes spin { to{transform:rotate(360deg)} }
        @keyframes rp { 0%,100%{opacity:0.6;transform:scale(1)} 50%{opacity:0.18;transform:scale(1.06)} }
        @keyframes pd { 0%,100%{transform:scale(1);opacity:1} 50%{transform:scale(1.4);opacity:0.7} }
        @keyframes scaleIn { from{transform:scale(0.4);opacity:0} to{transform:scale(1);opacity:1} }
        @keyframes dash { from{stroke-dashoffset:90} to{stroke-dashoffset:0} }
        @keyframes expandCard { from{opacity:0;transform:scale(0.94)} to{opacity:1;transform:scale(1)} }
        @keyframes summaryIn { from{opacity:0;transform:translateY(12px)} to{opacity:1;transform:none} }
      `}</style>

      {!hideHeader && (
        <div style={{ textAlign: "left", maxWidth: 760, margin: "0 0 48px" }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 7, background: `${C.gold}12`, border: `1px solid ${C.gold}28`, borderRadius: 100, padding: "5px 14px", marginBottom: 16 }}>
            <div style={{ width: 6, height: 6, borderRadius: "50%", background: C.gold, animation: "pd 2s ease-in-out infinite" }} />
            <span style={{ fontSize: 10, fontWeight: 700, letterSpacing: "2px", color: C.gold, textTransform: "uppercase", fontFamily: "'JetBrains Mono',monospace" }}>AIT Compliance Engine</span>
          </div>
          <h2 style={{ fontFamily: "'DM Serif Display',serif", fontSize: "clamp(38px,3.2vw,62px)", lineHeight: 1.08, color: "var(--navy)", letterSpacing: "-1px", margin: "0 0 14px" }}>
            One invoice. Zero friction.<br />
            <em style={{ color: "var(--navy-2)", fontStyle: "italic" }}>AIT orchestrates the entire chain.</em>
          </h2>
          <p style={{ fontSize: 20, color: "var(--text-2)", lineHeight: 1.65, margin: 0, maxWidth: 760 }}>From vendor upload to GST filing - watch the compliance flow happen automatically.</p>
        </div>
      )}

      {/* Hub wrapper */}
      <div ref={wrapRef} style={{ maxWidth: gridW, margin: "0 auto", position: "relative", height: isMobile ? undefined : CH * 3, minHeight: isMobile ? 200 : undefined }}>

        {started && <DotCanvas nodeRefs={nodeRefs} wrapRef={wrapRef} dot={cur.dot} phaseMs={phaseMs} phaseDur={cur.dur} />}
        {isMobile && started && <MobileLines nodeRefs={nodeRefs} wrapRef={wrapRef} />}

        {isDone && (
          <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", zIndex: 60, animation: "summaryIn 0.5s ease", minHeight: isMobile ? 240 : undefined }}>
            <div style={{ width: isMobile ? 80 : 130, height: isMobile ? 80 : 130, borderRadius: "50%", background: "linear-gradient(135deg,#1a6644,#2d9966)", boxShadow: "0 0 0 18px rgba(26,102,68,0.1),0 0 0 36px rgba(26,102,68,0.05),0 16px 56px rgba(26,102,68,0.4)", display: "flex", alignItems: "center", justifyContent: "center", animation: "scaleIn 0.7s cubic-bezier(0.16,1,0.3,1)" }}>
              <svg width={isMobile ? 36 : 56} height={isMobile ? 30 : 46} viewBox="0 0 56 46" fill="none">
                <path d="M4 24L20 40L52 4" stroke="white" strokeWidth="5.5" strokeLinecap="round" strokeLinejoin="round" style={{ strokeDasharray: 90, strokeDashoffset: 0, animation: "dash 0.6s cubic-bezier(0.16,1,0.3,1) 0.35s both" }} />
              </svg>
            </div>
            <div style={{ marginTop: isMobile ? 14 : 20, textAlign: "center", animation: "fu 0.5s 0.4s both ease" }}>
              <div style={{ fontSize: isMobile ? 13 : 15, fontWeight: 700, color: C.green, fontFamily: "'DM Sans',sans-serif" }}>Filed & Complete</div>
              <div style={{ fontSize: isMobile ? 8 : 10.5, color: C.textSub, fontFamily: "'JetBrains Mono',monospace", marginTop: 4 }}>ARN: GST2026/FEB/1847263</div>
            </div>
          </div>
        )}

        {/* 3×3 grid */}
        <div style={{
          display: "grid",
          gridTemplateColumns: isMobile ? `${CARD_W}px ${CARD_W}px ${CARD_W}px` : `${CW}px ${CW}px ${CW}px`,
          gridTemplateRows: isMobile ? "auto auto auto" : `${CH}px ${CH}px ${CH}px`,
          gap: isMobile ? "6px" : "0px 24px",
          alignItems: "center",
          justifyItems: "center",
          position: isMobile ? "relative" : "absolute",
          inset: isMobile ? undefined : 0,
          zIndex: 2,
          opacity: isDone ? 0 : 1,
          transform: isDone ? "scale(0.88)" : "scale(1)",
          transition: "opacity 0.65s cubic-bezier(0.16,1,0.3,1),transform 0.65s cubic-bezier(0.16,1,0.3,1)",
          width: isMobile ? gridW : undefined,
          margin: isMobile ? "0 auto" : undefined,
        }}>
          <div /><div ref={nodeRefs.customer}><CustomerCard phaseId={phaseId} phaseMs={phaseMs} isMobile={isMobile} cardW={CARD_W} /></div><div />
          <div ref={nodeRefs.vendor}><VendorCard phaseId={phaseId} phaseMs={phaseMs} isMobile={isMobile} cardW={CARD_W} /></div>
          <div ref={nodeRefs.ait}><AITCard phaseId={phaseId} phaseMs={phaseMs} isMobile={isMobile} cardW={CARD_W} /></div>
          <div ref={nodeRefs.ca}><CACard phaseId={phaseId} phaseMs={phaseMs} isMobile={isMobile} cardW={CARD_W} /></div>
          <div /><div ref={nodeRefs.gst}><GSTCard phaseId={phaseId} phaseMs={phaseMs} isMobile={isMobile} cardW={CARD_W} /></div><div />
        </div>
      </div>

      {/* Progress dots */}
      <div style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: isMobile ? 8 : 10, margin: `${isMobile ? 14 : 10}px auto 0`, maxWidth: gridW, flexWrap: "wrap" }}>
        {STAGE_LABELS.map((label, idx) => (
          <div key={idx} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
            <div style={{ width: idx === curStage ? (isMobile ? 7 : 9) : (isMobile ? 5 : 6), height: idx === curStage ? (isMobile ? 7 : 9) : (isMobile ? 5 : 6), borderRadius: "50%", background: idx === curStage ? C.navy : idx < curStage ? C.green : "#cbd5e1", boxShadow: idx === curStage ? `0 0 0 3px ${C.navyLt}` : "none", transition: "all 0.4s" }} />
            <div style={{ fontSize: isMobile ? 7 : 8.5, color: idx === curStage ? C.navy : idx < curStage ? C.green : "#94a3b8", fontFamily: "'DM Sans',sans-serif", fontWeight: idx === curStage ? 700 : 400, whiteSpace: "nowrap" }}>{label}</div>
          </div>
        ))}
      </div>

      {/* Metrics */}
      <div style={{ maxWidth: gridW, margin: "10px auto 0", display: "grid", gridTemplateColumns: isMobile ? "repeat(2,1fr)" : "repeat(4,1fr)", gap: isMobile ? 8 : 12 }}>
        {[{ l: "End-to-end", was: "3–5 days", now: "< 2 hours" }, { l: "Manual steps", was: "22 steps", now: "2 approvals" }, { l: "ITC recovery", was: "91%", now: "99.8%" }, { l: "Error rate", was: "4–6%", now: "< 0.1%" }].map((m, i) => (
          <div key={i} style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: 10, padding: isMobile ? "10px 12px" : "14px 16px" }}>
            <div style={{ fontSize: isMobile ? 7.5 : 9.5, fontFamily: "'JetBrains Mono',monospace", color: C.textSub, letterSpacing: "0.5px", textTransform: "uppercase", marginBottom: isMobile ? 5 : 8 }}>{m.l}</div>
            <div style={{ display: "flex", alignItems: "center", gap: isMobile ? 5 : 7, flexWrap: "wrap" }}>
              <span style={{ fontSize: isMobile ? 9 : 11, color: "#dc2626", background: "#fef2f2", padding: "1px 7px", borderRadius: 5, fontWeight: 600, opacity: 0.8 }}>{m.was}</span>
              <svg width="12" height="10" viewBox="0 0 12 10" fill="none"><path d="M2 5h8M7 2l3 3-3 3" stroke={C.green} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" /></svg>
              <span style={{ fontSize: isMobile ? 10 : 12.5, color: C.green, background: C.greenLt, padding: "1px 8px", borderRadius: 5, fontWeight: 700 }}>{m.now}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}