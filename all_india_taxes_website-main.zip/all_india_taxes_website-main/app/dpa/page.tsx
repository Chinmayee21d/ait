import { redirect } from 'next/navigation'

export default function DpaRedirectPage() {
  redirect('/legal/dpa')
}
