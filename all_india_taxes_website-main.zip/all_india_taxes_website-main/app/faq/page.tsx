import type { Metadata } from 'next'
import Nav from '@/components/Nav'
import Footer from '@/components/Footer'

type FAQItem = {
  question: string
  answer: string
}

type FAQSection = {
  title: string
  items: FAQItem[]
}

const primaryDomain = 'https://www.allindiataxes.com'
const lastUpdated = 'March 6, 2026'

const faqSections: FAQSection[] = [
  {
    title: 'Platform Overview',
    items: [
      {
        question: 'What is All India Taxes (AIT)?',
        answer:
          'All India Taxes (AIT) is a GST and TDS compliance platform built for Indian businesses and CA firms. It combines filing operations, reconciliation workflows, and compliance collaboration in one system.',
      },
      {
        question: 'Who should use AIT?',
        answer:
          'AIT is designed for finance teams, tax teams, founders, and chartered accountant firms managing GST, TDS, and vendor compliance at single or multi-entity scale.',
      },
      {
        question: 'What are the main modules in AIT?',
        answer:
          'AIT covers GST operations, TDS operations, reconciliation queues, compliance tracking, and shared workflows for internal teams and external CA partners.',
      },
      {
        question: 'Is AIT for small businesses or large enterprises?',
        answer:
          'Both. Teams can start with one entity and basic filing workflows, then scale to multi-entity operations with standardized controls and audit-friendly processes.',
      },
      {
        question: 'Can AIT replace spreadsheet-driven tax operations?',
        answer:
          'AIT is intended to reduce dependence on ad hoc spreadsheet processes by centralizing tax tasks, exceptions, and status tracking in one operational layer.',
      },
      {
        question: 'How is AIT different from filing-only tools?',
        answer:
          'Filing is only one part of compliance. AIT focuses on full-cycle operations, including preparation, reconciliation, exception management, and cross-team coordination.',
      },
    ],
  },
  {
    title: 'GST Operations',
    items: [
      {
        question: 'Does AIT support GST return workflows?',
        answer:
          'Yes. AIT supports operational workflows around GST return readiness, issue tracking, and filing coordination for periodic compliance cycles.',
      },
      {
        question: 'How does AIT help with GST reconciliation?',
        answer:
          'AIT helps identify mismatches across source datasets, groups exceptions by priority, and guides resolution before filing deadlines.',
      },
      {
        question: 'Can AIT help with ITC-focused checks?',
        answer:
          'Yes. Teams can use AIT workflows to flag and follow up on mismatches that affect ITC eligibility and downstream GST compliance accuracy.',
      },
      {
        question: 'Can multiple entities be handled in one workspace?',
        answer:
          'Yes. AIT is built for multi-entity operations so teams can monitor compliance status and open actions across entities from one place.',
      },
      {
        question: 'Does AIT support GST notice-response preparation?',
        answer:
          'AIT can be used to organize documentation, evidence trails, and response workflows so teams can handle notices with better traceability and turnaround.',
      },
      {
        question: 'Where can I see the end-to-end GST flow?',
        answer:
          'You can review the operational sequence on the home page flow sections, especially How It Works and AI Intelligence. Start here: /#how and /#ai.',
      },
    ],
  },
  {
    title: 'TDS Operations',
    items: [
      {
        question: 'Does AIT support TDS compliance workflows?',
        answer:
          'Yes. AIT supports TDS operational workflows including return preparation support, reconciliation checkpoints, and periodic compliance tracking.',
      },
      {
        question: 'Can AIT help with quarterly TDS return readiness?',
        answer:
          'Yes. Teams can use AIT to manage tasks and exceptions that must be resolved before quarterly return timelines.',
      },
      {
        question: 'How does AIT help reduce TDS filing errors?',
        answer:
          'AIT helps by surfacing mismatches and incomplete records earlier in the process, so corrective actions happen before final submission windows.',
      },
      {
        question: 'Can finance and CA teams collaborate on TDS in AIT?',
        answer:
          'Yes. AIT is structured for shared workflows so in-house finance teams and external tax professionals can track ownership and progress in one place.',
      },
      {
        question: 'Can AIT support evidence trails for compliance reviews?',
        answer:
          'Yes. AIT workflows are designed to keep context, issue state, and operational history easier to reference during reviews and follow-ups.',
      },
      {
        question: 'Is AIT useful for both ongoing and year-end TDS work?',
        answer:
          'Yes. AIT is intended for recurring compliance operations and heavy periods where coordinated execution and visibility matter most.',
      },
    ],
  },
  {
    title: 'CA Firms, Security, and Onboarding',
    items: [
      {
        question: 'Can CA firms use AIT across multiple clients?',
        answer:
          'Yes. AIT is designed for multi-client CA workflows with centralized visibility and process consistency across registrations and entities.',
      },
      {
        question: 'How does AIT support vendor compliance monitoring?',
        answer:
          'AIT includes operational support for vendor document collection, validation checkpoints, and risk signaling used by finance and tax teams.',
      },
      {
        question: 'Does AIT support role-based team workflows?',
        answer:
          'Yes. AIT workflows are structured so teams can separate ownership, handoffs, and approvals across members and functional roles.',
      },
      {
        question: 'How do I evaluate AIT for my organization?',
        answer:
          'Start with a demo conversation to map your existing process, data sources, and compliance pain points. You can request one at /request-demo.',
      },
      {
        question: 'Where can I access product and company materials?',
        answer:
          'You can access the pitch deck resource page at /pitch-deck for a quick overview of positioning and platform direction.',
      },
      {
        question: 'How quickly can teams get started with AIT?',
        answer:
          'Teams typically begin with one workflow and a small operating scope, then expand after initial process baselining and stakeholder alignment.',
      },
    ],
  },
]

const allFaqItems = faqSections.flatMap((section) => section.items)

export const metadata: Metadata = {
  title: 'AEO FAQ for GST and TDS Compliance',
  description:
    'Detailed FAQ for All India Taxes (AIT) covering GST and TDS workflows, reconciliation, CA collaboration, onboarding, and operational best practices.',
  alternates: {
    canonical: '/faq',
    languages: {
      'en-IN': '/faq',
      'x-default': '/faq',
    },
  },
}

export default function FAQPage() {
  const faqJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: allFaqItems.map((item) => ({
      '@type': 'Question',
      name: item.question,
      acceptedAnswer: {
        '@type': 'Answer',
        text: item.answer,
      },
    })),
  }

  const webPageJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'WebPage',
    name: 'AIT FAQ',
    url: `${primaryDomain}/faq`,
    description: metadata.description,
    inLanguage: 'en-IN',
    isPartOf: {
      '@type': 'WebSite',
      name: 'All India Taxes (AIT)',
      url: primaryDomain,
    },
    dateModified: '2026-03-06',
  }

  const breadcrumbJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      {
        '@type': 'ListItem',
        position: 1,
        name: 'Home',
        item: primaryDomain,
      },
      {
        '@type': 'ListItem',
        position: 2,
        name: 'FAQ',
        item: `${primaryDomain}/faq`,
      },
    ],
  }

  return (
    <>
      <Nav />
      <main className="faq-page">
        <section className="section-wrap faq-wrap">
          <p className="section-tag">AEO and Search Answers</p>
          <h1 className="faq-title">Frequently Asked Questions</h1>
          <p className="section-sub faq-sub">
            Detailed answers about All India Taxes (AIT), GST and TDS workflows, and how finance
            teams and CA firms execute compliance operations with better visibility.
          </p>
          <p className="faq-updated">Last updated: {lastUpdated}</p>

          <div className="faq-links">
            <a href="/#how" className="btn-nav btn-nav-ghost faq-link-btn">
              How It Works
            </a>
            <a href="/#ai" className="btn-nav btn-nav-ghost faq-link-btn">
              AI Intelligence
            </a>
            <a href="/request-demo" className="btn-nav btn-nav-ghost faq-link-btn">
              Request Demo
            </a>
            <a href="/pitch-deck" className="btn-nav btn-nav-ghost faq-link-btn">
              Pitch Deck
            </a>
          </div>

          <div className="faq-section-list">
            {faqSections.map((section) => (
              <section key={section.title} className="faq-group">
                <h2 className="faq-group-title">{section.title}</h2>
                <div className="faq-card-grid">
                  {section.items.map((item) => (
                    <article key={item.question} className="faq-card">
                      <h3 className="faq-card-question">{item.question}</h3>
                      <p className="faq-card-answer">{item.answer}</p>
                    </article>
                  ))}
                </div>
              </section>
            ))}
          </div>

          <div className="faq-cta">
            <a href="/request-demo" className="btn-hero-primary">
              Request a Demo
            </a>
          </div>
        </section>
      </main>
      <Footer />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(webPageJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
    </>
  )
}
