'use client'

import AITSignIn from '@/design/AITSignIn'
import { useRouter } from 'next/navigation'

const DEMO_EMAIL = 'stawan@gmail.com'
const DEMO_REDIRECT_URL = 'https://all-india-taxes.pages.dev/demo'

export default function SignInPage() {
  const router = useRouter()

  const handleSuccess = (user: { email?: string } | undefined) => {
    const email = user?.email?.toLowerCase().trim()

    // Redirect demo user to demo environment
    if (email === DEMO_EMAIL) {
      window.location.href = DEMO_REDIRECT_URL
      return
    }

    // Default: navigate to dashboard
    router.push('/dashboard')
  }

  return (
    <AITSignIn
      onSuccess={handleSuccess}
      onSignUpClick={() => router.push('/sign-up')}
    />
  )
}
