import type { Metadata } from 'next'
import PrivacyAdminClient from '@/components/PrivacyAdminClient'

export const metadata: Metadata = {
  title: 'Privacy Admin',
  robots: { index: false, follow: false },
}

type PageProps = {
  searchParams: Promise<{ key?: string }>
}

export default async function PrivacyAdminPage({ searchParams }: PageProps) {
  const { key = '' } = await searchParams
  const expected = process.env.PRIVACY_ADMIN_KEY || ''
  const authorized = Boolean(expected) && key === expected

  if (!authorized) {
    return (
      <main className="legal-page">
        <div className="section-wrap legal-wrap">
          <div className="legal-doc">
            <h1 className="legal-title" style={{ textAlign: 'left', fontSize: 36 }}>Unauthorized</h1>
            <p>Provide a valid admin key query parameter.</p>
          </div>
        </div>
      </main>
    )
  }

  return <PrivacyAdminClient adminKey={key} />
}
