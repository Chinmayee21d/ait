import type { MetadataRoute } from 'next'

const primaryDomain = 'https://www.allindiataxes.com'

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date()
  const routes = [
    '/',
    '/faq',
    '/data-rights',
    '/data-rights/status',
    '/request-demo',
    '/pitch-deck',
    '/view-demo',
    '/sign-in',
    '/sign-up',
    '/legal',
    '/privacy',
    '/terms',
    '/cookie-policy',
    '/dpa',
    '/security-policy',
    '/acceptable-use',
    '/dpdp',
    '/eu-uk-privacy',
    '/sub-processors',
    '/privacy-admin',
  ]

  return routes.map((route) => ({
    url: `${primaryDomain}${route}`,
    lastModified: now,
    changeFrequency: route === '/' ? 'weekly' : 'monthly',
    priority: route === '/' ? 1 : 0.6,
    alternates: {
      languages: {
        'en-IN': `${primaryDomain}${route}`,
        'x-default': `${primaryDomain}${route}`,
      },
    },
  }))
}
