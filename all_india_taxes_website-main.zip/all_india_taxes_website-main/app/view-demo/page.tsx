import ViewDemoClient from '@/components/ViewDemoClient'
import { normalizeDemoRole } from '@/lib/site-links'

type ViewDemoPageProps = {
  searchParams: Promise<{ role?: string }>
}

export default async function ViewDemoPage({ searchParams }: ViewDemoPageProps) {
  const params = await searchParams
  const role = normalizeDemoRole(params?.role)

  return <ViewDemoClient role={role} />
}
