import { NextRequest, NextResponse } from 'next/server'
import { sendMail } from '@/lib/mailer'
import { getOtpCookieName, verifyOtp, verifyOtpToken } from '@/lib/otp-store'
import type { Purpose } from '@/lib/otp-store'
import { SALES_EMAIL } from '@/lib/site-links'

type LeadPayload = {
  name: string
  email: string
  phone?: string
  company?: string
  message?: string
  role?: string
  teamSize?: string
  currentSoftware?: string
  challenge?: string
}

function isPurpose(v: string): v is Purpose {
  return v === 'demo' || v === 'view_demo' || v === 'request_demo' || v === 'pitch' || v === 'signin' || v === 'signup'
}

function escapeHtml(input: string) {
  // Defensive escaping for interpolated email body content.
  return input
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null)
  const purpose = String(body?.purpose || '')
  const email = String(body?.email || '').trim().toLowerCase()
  const code = String(body?.code || '').trim()
  const payload = (body?.payload || {}) as LeadPayload

  if (!isPurpose(purpose) || !email || !code) {
    return NextResponse.json({ ok: false, error: 'Invalid request.' }, { status: 400 })
  }
  const token = req.cookies.get(getOtpCookieName(purpose))?.value || ''
  const tokenOk = token ? verifyOtpToken(token, email, purpose, code) : false
  const storeOk = verifyOtp(email, purpose, code)
  if (!tokenOk && !storeOk) {
    return NextResponse.json({ ok: false, error: 'Invalid or expired OTP.' }, { status: 401 })
  }

  if (purpose === 'signin' || purpose === 'signup') {
    // Auth flows only need OTP confirmation and a lightweight user echo.
    const authResponse = NextResponse.json({
      ok: true,
      user: {
        email,
        name: payload.name || '',
        company: payload.company || '',
      }
    })
    authResponse.cookies.set(getOtpCookieName(purpose), '', { maxAge: 0, path: '/' })
    return authResponse
  }

  const isViewDemo = purpose === 'view_demo'
  const isRequestDemo = purpose === 'request_demo' || purpose === 'demo'
  const isDemoFlow = isViewDemo || isRequestDemo
  const title = isDemoFlow ? (isViewDemo ? 'View Demo Lead' : 'Request Demo Lead') : 'Pitch Deck Download Lead'
  const source = isDemoFlow ? (isViewDemo ? 'View Demo Page' : 'Request Demo Page') : 'Pitch Deck Page'
  const html = `
    <div style="font-family:Arial,sans-serif;color:#0f1e3d;line-height:1.5;">
      <h2>${title}</h2>
      <p><strong>Name:</strong> ${escapeHtml(String(payload.name || ''))}</p>
      <p><strong>Email:</strong> ${escapeHtml(String(payload.email || email))}</p>
      <p><strong>Phone:</strong> ${escapeHtml(String(payload.phone || ''))}</p>
      <p><strong>Company:</strong> ${escapeHtml(String(payload.company || ''))}</p>
      <p><strong>Role:</strong> ${escapeHtml(String(payload.role || ''))}</p>
      <p><strong>Team Size:</strong> ${escapeHtml(String(payload.teamSize || ''))}</p>
      <p><strong>Current Software:</strong> ${escapeHtml(String(payload.currentSoftware || ''))}</p>
      <p><strong>Primary Challenge:</strong> ${escapeHtml(String(payload.challenge || ''))}</p>
      <p><strong>Message:</strong> ${escapeHtml(String(payload.message || ''))}</p>
      <p><strong>Source:</strong> ${source}</p>
      <p><strong>Timestamp:</strong> ${new Date().toISOString()}</p>
    </div>
  `

  const leadAlert = await sendMail({
    to: SALES_EMAIL,
    subject: `[AIT Website] ${title} - ${escapeHtml(String(payload.company || payload.name || email))}`,
    html
  })
  if (!leadAlert.ok) {
    console.error('[otp/verify] Failed to send sales lead email', {
      purpose,
      email,
      status: leadAlert.status,
      error: leadAlert.error
    })
    return NextResponse.json(
      { ok: false, error: 'Verification succeeded, but notification failed. Please try again.' },
      { status: 502 }
    )
  }

  const userName = escapeHtml(String(payload.name || 'there'))
  const safeRole = escapeHtml(String(payload.role || ''))
  const ackSubject = isViewDemo
    ? 'Thank You for viewing the AIT Demo'
    : isRequestDemo
      ? 'Thank you for requesting the AIT demo'
      : 'Your AIT pitch deck access is confirmed'
  const ackHtml =
    isViewDemo
      ? `
        <div style="font-family:Arial,sans-serif;color:#0f1e3d;line-height:1.6;">
          <p>Hi ${userName},</p>
          <p>Thank you for registering for and attending the AIT demo. I hope you found the session helpful and were able to see how All India Taxes can simplify and streamline your GST and TDS workflows.</p>
          <p>If you'd like a more detailed, customized walkthrough based on your exact GST or TDS processes, simply reply to this email. I'd be happy to arrange a tailored demo with our team so we can show you how AIT can fit your specific workflow.</p>
          <p>Thank you again for your interest in All India Taxes. We appreciate your time and look forward to assisting you.</p>
          <p style="margin-top:16px;">Warm regards,<br/><strong>Stawan Kamani</strong><br/>CEO, All India Taxes<br/>stawan@allindiataxes.com</p>
        </div>
      `
      : isRequestDemo
      ? `
        <div style="font-family:Arial,sans-serif;color:#0f1e3d;line-height:1.6;">
          <p>Hi ${userName},</p>
          <p>Thank you for registering for the AIT demo. We are excited to show a detailed, customized demo for your exact GST/TDS workflow. We will reach out to shortly to setup a time.</p>
          <p style="margin-top:16px;">Regards,<br/><strong>Stawan Kamani</strong><br/>CEO, All India Taxes<br/>stawan@allindiataxes.com</p>
        </div>
      `
      : `
        <div style="font-family:Arial,sans-serif;color:#0f1e3d;line-height:1.55;">
          <p>Hi ${userName},</p>
          <p>Thank you for confirming your email. Your AIT Compliance Infrastructure deck is now unlocked.</p>
          <p>If useful, reply to this email and I can have our team walk you through the most relevant sections for your business.</p>
          <p style="margin-top:16px;">Regards,<br/><strong>Stawan Kamani</strong><br/>CEO, All India Taxes</p>
        </div>
      `
  const ackText =
    isViewDemo
      ? `Hi ${String(payload.name || 'there')},\n\nThank you for registering for and attending the AIT demo. I hope you found the session helpful and were able to see how All India Taxes can simplify and streamline your GST and TDS workflows.\n\nIf you'd like a more detailed, customized walkthrough based on your exact GST or TDS processes, simply reply to this email. I'd be happy to arrange a tailored demo with our team so we can show you how AIT can fit your specific workflow.\n\nThank you again for your interest in All India Taxes. We appreciate your time and look forward to assisting you.\n\nWarm regards,\nStawan Kamani\nCEO, All India Taxes\nstawan@allindiataxes.com`
      : isRequestDemo
        ? `Hi ${String(payload.name || 'there')},\n\nThank you for registering for the AIT demo. We are excited to show a detailed, customized demo for your exact GST/TDS workflow. We will reach out to shortly to setup a time.\n\nRegards,\nStawan Kamani\nCEO, All India Taxes\nstawan@allindiataxes.com`
        : `Hi ${String(payload.name || 'there')},\n\nThank you for confirming your email. Your AIT Compliance Infrastructure deck is now unlocked.\n\nIf useful, reply to this email and our team can walk you through the most relevant sections.\n\nRegards,\nStawan Kamani\nCEO, All India Taxes`

  // Acknowledgement email is helpful but should not block the user flow.
  const ackResult = await sendMail({
    to: email,
    subject: ackSubject,
    html: ackHtml,
    text: ackText,
    from: 'Stawan Kamani <stawan@allindiataxes.com>',
    replyTo: 'stawan@allindiataxes.com'
  })
  if (!ackResult.ok) {
    console.warn('[otp/verify] User acknowledgement email failed', {
      purpose,
      email,
      status: ackResult.status
    })
  }

  if (purpose === 'pitch') {
    // Pitch flow returns a gated asset URL only after OTP verification.
    const pitchResponse = NextResponse.json({
      ok: true,
      downloadUrl: '/pitch_deck/AIT%20Compliance%20Infrastructure%20vF.pdf'
    })
    pitchResponse.cookies.set(getOtpCookieName(purpose), '', { maxAge: 0, path: '/' })
    return pitchResponse
  }

  const response = NextResponse.json({ ok: true })
  response.cookies.set(getOtpCookieName(purpose), '', { maxAge: 0, path: '/' })
  return response
}
