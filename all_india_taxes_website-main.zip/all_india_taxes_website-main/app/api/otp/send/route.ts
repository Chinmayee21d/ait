import { randomInt } from 'crypto'
import { NextRequest, NextResponse } from 'next/server'
import { sendMail } from '@/lib/mailer'
import { canSendOtp, createOtpToken, getOtpCookieName, setOtp } from '@/lib/otp-store'
import type { Purpose } from '@/lib/otp-store'

function isPurpose(v: string): v is Purpose {
  return v === 'demo' || v === 'view_demo' || v === 'request_demo' || v === 'pitch' || v === 'signin' || v === 'signup'
}

function otpEmailTemplate(purpose: Purpose, code: string) {
  if (purpose === 'demo' || purpose === 'view_demo' || purpose === 'request_demo') {
    return {
      subject: 'Confirm your demo request - AIT',
      preview: 'Your demo verification code is inside.',
      html: `
        <div style="font-family:Arial,sans-serif;line-height:1.55;color:#0f1e3d">
          <p style="margin:0 0 12px 0;font-size:12px;color:#6b7a94;">All India Taxes - Verification</p>
          <h2 style="margin:0 0 12px 0;">Confirm your demo request</h2>
          <p style="margin:0 0 12px 0;">Please use this one-time verification code to confirm your email and schedule your walkthrough:</p>
          <p style="font-size:32px;letter-spacing:4px;font-weight:800;margin:10px 0 14px 0;">${code}</p>
          <p style="margin:0 0 14px 0;">This code expires in 10 minutes.</p>
          <p style="margin:0 0 4px 0;">If you did not request this, you can ignore this email.</p>
        </div>
      `,
      text: `Your AIT demo verification code is ${code}. It expires in 10 minutes. If you did not request this, ignore this email.`
    }
  }

  if (purpose === 'pitch') {
    return {
      subject: 'Verify to download the AIT pitch deck',
      preview: 'Your pitch deck access code is inside.',
      html: `
        <div style="font-family:Arial,sans-serif;line-height:1.55;color:#0f1e3d">
          <p style="margin:0 0 12px 0;font-size:12px;color:#6b7a94;">All India Taxes - Verification</p>
          <h2 style="margin:0 0 12px 0;">Verify to download the AIT pitch deck</h2>
          <p style="margin:0 0 12px 0;">Use this one-time code to verify your email and unlock the deck download:</p>
          <p style="font-size:32px;letter-spacing:4px;font-weight:800;margin:10px 0 14px 0;">${code}</p>
          <p style="margin:0 0 14px 0;">This code expires in 10 minutes.</p>
          <p style="margin:0 0 4px 0;">If you did not request this, you can ignore this email.</p>
        </div>
      `,
      text: `Your AIT pitch deck verification code is ${code}. It expires in 10 minutes. If you did not request this, ignore this email.`
    }
  }

  const subjectMap: Record<Purpose, string> = {
    demo: 'Your OTP for Request a Demo',
    view_demo: 'Your OTP for Request a Demo',
    request_demo: 'Your OTP for Request a Demo',
    pitch: 'Your OTP to Access the AIT Pitch Deck',
    signin: 'Your OTP for AIT Sign In',
    signup: 'Your OTP for AIT Sign Up'
  }

  return {
    subject: subjectMap[purpose],
    preview: 'Your AIT OTP code',
    html: `
      <div style="font-family:Arial,sans-serif;line-height:1.5;color:#0f1e3d">
        <h2 style="margin:0 0 12px 0;">All India Taxes (AIT)</h2>
        <p>Your one-time password is:</p>
        <p style="font-size:28px;letter-spacing:4px;font-weight:700;margin:8px 0 12px 0;">${code}</p>
        <p>This OTP will expire in 10 minutes.</p>
      </div>
    `,
    text: `Your AIT OTP is ${code}. It expires in 10 minutes.`
  }
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null)
  const email = String(body?.email || '').trim().toLowerCase()
  const purpose = String(body?.purpose || '')

  if (!email || !isPurpose(purpose)) {
    return NextResponse.json({ ok: false, error: 'Invalid request.' }, { status: 400 })
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return NextResponse.json({ ok: false, error: 'Please enter a valid email.' }, { status: 400 })
  }
  if (!canSendOtp(email, purpose)) {
    // Cooldown prevents brute-force and accidental spam sends.
    return NextResponse.json({ ok: false, error: 'Please wait before requesting another OTP.' }, { status: 429 })
  }

  const code = String(randomInt(100000, 999999))
  setOtp(email, purpose, code)
  const token = createOtpToken(email, purpose, code)

  const template = otpEmailTemplate(purpose, code)
  const result = await sendMail({
    to: email,
    subject: template.subject,
    html: template.html,
    text: template.text,
    from: process.env.EMAIL_FROM_OTP || 'AIT Information Team <info@allindiataxes.com>',
    replyTo: 'stawan@allindiataxes.com'
  })
  if (!result.ok) {
    console.error('[otp/send] Failed to deliver OTP email', {
      purpose,
      to: email,
      status: result.status,
      error: result.error
    })
    return NextResponse.json(
      { ok: false, error: 'We could not send the OTP email. Please try again in a moment.' },
      { status: 502 }
    )
  }

  // Convenience for local testing; intentionally suppressed in production.
  const debugOtp = process.env.NODE_ENV === 'production' ? undefined : code
  const response = NextResponse.json({ ok: true, debugOtp })
  if (token) {
    response.cookies.set(getOtpCookieName(purpose), token, {
      httpOnly: true,
      secure: true,
      sameSite: 'lax',
      path: '/',
      maxAge: 10 * 60
    })
  }
  return response
}
