import { NextRequest, NextResponse } from 'next/server'
import { listPrivacyRequests, updatePrivacyRequestStatus, type PrivacyRequestStatus } from '@/lib/privacy-requests'

function isStatus(v: string): v is PrivacyRequestStatus {
  return v === 'submitted' || v === 'in_review' || v === 'completed' || v === 'rejected'
}

function hasAdminAccess(req: NextRequest, keyFromBody?: string) {
  const expected = process.env.PRIVACY_ADMIN_KEY || ''
  if (!expected) return false
  const key = String(keyFromBody || req.nextUrl.searchParams.get('key') || '').trim()
  return key && key === expected
}

export async function GET(req: NextRequest) {
  if (!hasAdminAccess(req)) {
    return NextResponse.json({ ok: false, error: 'Unauthorized.' }, { status: 401 })
  }
  const items = await listPrivacyRequests()
  return NextResponse.json({ ok: true, requests: items })
}

export async function PATCH(req: NextRequest) {
  const body = await req.json().catch(() => null)
  if (!hasAdminAccess(req, String(body?.key || ''))) {
    return NextResponse.json({ ok: false, error: 'Unauthorized.' }, { status: 401 })
  }

  const requestId = String(body?.requestId || '').trim()
  const status = String(body?.status || '').trim()
  const adminNote = String(body?.adminNote || '').trim()

  if (!requestId || !isStatus(status)) {
    return NextResponse.json({ ok: false, error: 'Invalid payload.' }, { status: 400 })
  }

  const updated = await updatePrivacyRequestStatus(requestId, status, adminNote)
  if (!updated) {
    return NextResponse.json({ ok: false, error: 'Request not found.' }, { status: 404 })
  }
  return NextResponse.json({ ok: true, request: updated })
}
