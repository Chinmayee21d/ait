import { NextRequest, NextResponse } from 'next/server'
import { findPrivacyRequest } from '@/lib/privacy-requests'

function isValidEmail(email: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null)
  const requestId = String(body?.requestId || '').trim()
  const email = String(body?.email || '').trim().toLowerCase()

  if (!requestId || !email || !isValidEmail(email)) {
    return NextResponse.json({ ok: false, error: 'Invalid request.' }, { status: 400 })
  }

  const record = await findPrivacyRequest(requestId)
  if (!record) {
    return NextResponse.json({ ok: false, error: 'Request not found.' }, { status: 404 })
  }
  const matches =
    record.email.toLowerCase() === email ||
    record.accountEmail.toLowerCase() === email
  if (!matches) {
    return NextResponse.json({ ok: false, error: 'Request not found for this email.' }, { status: 404 })
  }

  return NextResponse.json({
    ok: true,
    request: {
      requestId: record.requestId,
      requestType: record.requestType,
      status: record.status,
      createdAt: record.createdAt,
      updatedAt: record.updatedAt,
      adminNote: record.adminNote || '',
    },
  })
}
