import { randomUUID } from 'crypto'
import { NextRequest, NextResponse } from 'next/server'
import { sendMail } from '@/lib/mailer'
import { INFO_EMAIL } from '@/lib/site-links'
import { savePrivacyRequest, type PrivacyRequestType } from '@/lib/privacy-requests'
import { PRIVACY_SLA } from '@/lib/privacy-sla'

type RequestType = PrivacyRequestType

type DataRightsPayload = {
  requestType: RequestType
  fullName: string
  email: string
  company?: string
  accountEmail?: string
  details: string
  jurisdiction?: string
}

function escapeHtml(input: string) {
  return input
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
}

function isRequestType(v: string): v is RequestType {
  return v === 'access' || v === 'portability' || v === 'correction' || v === 'erasure' || v === 'grievance'
}

function isValidEmail(email: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
}

export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => null)) as DataRightsPayload | null

  const requestType = String(body?.requestType || '').trim().toLowerCase()
  const fullName = String(body?.fullName || '').trim()
  const email = String(body?.email || '').trim().toLowerCase()
  const company = String(body?.company || '').trim()
  const accountEmail = String(body?.accountEmail || '').trim().toLowerCase()
  const details = String(body?.details || '').trim()
  const jurisdiction = String(body?.jurisdiction || 'India').trim()

  if (!isRequestType(requestType) || !fullName || !email || !details) {
    return NextResponse.json({ ok: false, error: 'Invalid request payload.' }, { status: 400 })
  }
  if (!isValidEmail(email) || (accountEmail && !isValidEmail(accountEmail))) {
    return NextResponse.json({ ok: false, error: 'Please provide valid email addresses.' }, { status: 400 })
  }
  if (details.length < 20) {
    return NextResponse.json({ ok: false, error: 'Please provide more detail (minimum 20 characters).' }, { status: 400 })
  }

  const requestId = `AIT-DR-${new Date().toISOString().slice(0, 10).replaceAll('-', '')}-${randomUUID().slice(0, 8).toUpperCase()}`
  const now = new Date().toISOString()
  await savePrivacyRequest({
    requestId,
    requestType,
    fullName,
    email,
    accountEmail: accountEmail || email,
    company: company || '',
    jurisdiction,
    details,
    status: 'submitted',
    createdAt: now,
    updatedAt: now,
  })

  const subject = `[Data Rights] ${requestType.toUpperCase()} request ${requestId}`
  const html = `
    <div style="font-family:Arial,sans-serif;color:#0f1e3d;line-height:1.55;">
      <h2>Data Rights / Privacy Request</h2>
      <p><strong>Request ID:</strong> ${escapeHtml(requestId)}</p>
      <p><strong>Type:</strong> ${escapeHtml(requestType)}</p>
      <p><strong>Name:</strong> ${escapeHtml(fullName)}</p>
      <p><strong>Contact Email:</strong> ${escapeHtml(email)}</p>
      <p><strong>Account Email:</strong> ${escapeHtml(accountEmail || email)}</p>
      <p><strong>Company:</strong> ${escapeHtml(company || '-')}</p>
      <p><strong>Jurisdiction:</strong> ${escapeHtml(jurisdiction)}</p>
      <p><strong>Submitted At:</strong> ${new Date().toISOString()}</p>
      <hr />
      <p><strong>Details:</strong></p>
      <pre style="white-space:pre-wrap;font-family:Arial,sans-serif;background:#f7fafc;border:1px solid #e2e8f0;padding:12px;border-radius:8px;">${escapeHtml(details)}</pre>
    </div>
  `
  const text = [
    `Data Rights / Privacy Request`,
    `Request ID: ${requestId}`,
    `Type: ${requestType}`,
    `Name: ${fullName}`,
    `Contact Email: ${email}`,
    `Account Email: ${accountEmail || email}`,
    `Company: ${company || '-'}`,
    `Jurisdiction: ${jurisdiction}`,
    `Submitted At: ${new Date().toISOString()}`,
    ``,
    `Details:`,
    details,
  ].join('\n')

  const intakeResult = await sendMail({
    to: INFO_EMAIL,
    subject,
    html,
    text,
    replyTo: email,
    from: 'All India Taxes Privacy Desk <info@allindiataxes.com>',
  })

  if (!intakeResult.ok) {
    console.error('[privacy/requests] intake email failed', {
      requestId,
      status: intakeResult.status,
      error: intakeResult.error,
    })
    return NextResponse.json(
      { ok: false, error: 'Could not submit request right now. Please try again shortly.' },
      { status: 502 }
    )
  }

  // Non-blocking acknowledgement to requester.
  void sendMail({
    to: email,
    subject: `We received your request (${requestId})`,
    html: `
      <div style="font-family:Arial,sans-serif;color:#0f1e3d;line-height:1.6;">
        <p>Hi ${escapeHtml(fullName)},</p>
        <p>We have received your <strong>${escapeHtml(requestType)}</strong> request.</p>
        <p><strong>Request ID:</strong> ${escapeHtml(requestId)}</p>
        <p>Our privacy team will review this and respond from info@allindiataxes.com.</p>
        <p><strong>SLA maximums:</strong> human acknowledgment within ${PRIVACY_SLA.humanAcknowledgementHours} hours, first substantive update within ${PRIVACY_SLA.firstSubstantiveUpdateDays} calendar days, and final resolution within ${PRIVACY_SLA.finalResolutionDays} calendar days.</p>
        <p>If this concerns marketing consent, unsubscribe processing is completed within ${PRIVACY_SLA.marketingUnsubscribeBusinessDays} business days.</p>
        <p>Regards,<br/><strong>All India Taxes Privacy Desk</strong></p>
      </div>
    `,
    text: `Hi ${fullName},\n\nWe have received your ${requestType} request.\nRequest ID: ${requestId}\n\nOur privacy team will respond from info@allindiataxes.com.\n\nSLA maximums:\n- Human acknowledgment: within ${PRIVACY_SLA.humanAcknowledgementHours} hours\n- First substantive update: within ${PRIVACY_SLA.firstSubstantiveUpdateDays} calendar days\n- Final resolution: within ${PRIVACY_SLA.finalResolutionDays} calendar days\n- Marketing unsubscribe processing: within ${PRIVACY_SLA.marketingUnsubscribeBusinessDays} business days\n\nRegards,\nAll India Taxes Privacy Desk`,
    from: 'All India Taxes Privacy Desk <info@allindiataxes.com>',
  })

  return NextResponse.json({
    ok: true,
    requestId,
    message: 'Request submitted successfully. Keep your request ID for tracking.',
  })
}
