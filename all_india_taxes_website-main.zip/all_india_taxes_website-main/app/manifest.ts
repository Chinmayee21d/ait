import type { MetadataRoute } from 'next'

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'All India Taxes (AIT)',
    short_name: 'AIT',
    description: 'GST and TDS compliance, reconciliation, and filing infrastructure for Indian businesses and CA firms.',
    start_url: '/',
    display: 'standalone',
    background_color: '#ffffff',
    theme_color: '#0f1e3d',
    icons: [
      {
        src: '/brand/ait-logo-transparent.png',
        sizes: '512x512',
        type: 'image/png',
      },
    ],
  }
}
