import type { Metadata } from 'next'
import './globals.css'
import { globalStyles as authGlobalStyles } from '@/design/aitAuthUtils'
import AnalyticsTracker from '@/components/AnalyticsTracker'
import CookieConsent from '@/components/CookieConsent'
import GtmConsentLoader from '@/components/GtmConsentLoader'

const primaryDomain = 'https://www.allindiataxes.com'
const siteName = 'All India Taxes (AIT)'
const defaultTitle = 'All India Taxes (AIT) | GST and TDS Compliance and Filing Infrastructure'
const defaultDescription =
  'AIT orchestrates GST and TDS compliance with GSTR filing, TDS forms, reconciliation, e-invoicing, e-way bill workflows, CA collaboration, and vendor validation in one platform.'
const gtmId = process.env.NEXT_PUBLIC_GTM_ID || 'GTM-5VX7GXLJ'

export const metadata: Metadata = {
  metadataBase: new URL(primaryDomain),
  title: {
    default: defaultTitle,
    template: `%s | ${siteName}`
  },
  description: defaultDescription,
  applicationName: siteName,
  keywords: [
    'GST filing software India',
    'TDS return filing software India',
    'GST compliance platform',
    'TDS compliance platform',
    'GST and TDS automation',
    'GSTIN and TAN compliance',
    'GSTR-1 filing',
    'GSTR-3B filing',
    'GSTR-9 filing',
    'GSTR-9C filing',
    'GSTR-2A reconciliation',
    'GSTR-2B reconciliation',
    'GST return reconciliation',
    'ITC reconciliation',
    'ITC recovery',
    'input tax credit automation',
    'e-invoicing India',
    'IRN generation',
    'QR code invoice compliance',
    'e-way bill generation',
    'TDS filing',
    '24Q filing',
    '26Q filing',
    '27Q filing',
    '27EQ filing',
    'Form 16 generation',
    'Form 16A generation',
    'TDS return automation',
    'quarterly TDS returns',
    'ITNS 281 challan tracking',
    '26AS reconciliation',
    'AIS reconciliation',
    'NSDL TRACES compliance',
    'FVU file generation',
    'TDS challan compliance',
    'TRACES-ready TDS workflows',
    'input tax credit reconciliation',
    'CA compliance workflow',
    'chartered accountant collaboration software',
    'multi-client CA dashboard',
    'bulk GST filing',
    'maker checker workflow',
    'DSC filing workflow',
    'vendor compliance management',
    'vendor invoice validation',
    'Magic Link invoice submission',
    'vendor trust score',
    'compliance calendar reminders',
    'GST notice management',
    'TDS notice management',
    'ERP GST integration',
    'Tally GST integration',
    'Zoho Books GST integration',
    'SAP GST integration',
    'Oracle GST integration',
    'QuickBooks GST integration',
    'GST API and webhooks',
    'GSP-ready GST workflows',
    'GST notice management',
    'compliance workflow automation',
    'finance automation India',
    'India tax automation'
  ],
  alternates: {
    canonical: '/',
    languages: {
      'en-IN': '/',
      'x-default': '/'
    }
  },
  openGraph: {
    type: 'website',
    locale: 'en_IN',
    siteName,
    title: defaultTitle,
    description: defaultDescription,
    url: primaryDomain,
    images: [
      {
        url: '/brand/ait-logo-black.jpg',
        width: 1200,
        height: 630,
        alt: 'All India Taxes (AIT)'
      }
    ]
  },
  twitter: {
    card: 'summary_large_image',
    title: defaultTitle,
    description: defaultDescription,
    images: ['/brand/ait-logo-black.jpg']
  },
  icons: {
    icon: '/icon.svg',
    shortcut: '/icon.svg',
    apple: '/icon.svg'
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-image-preview': 'large',
      'max-snippet': -1,
      'max-video-preview': -1
    }
  },
  category: 'finance',
  referrer: 'origin-when-cross-origin'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const organizationJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: siteName,
    url: primaryDomain,
    sameAs: [primaryDomain],
    logo: `${primaryDomain}/brand/ait-logo-transparent.png`
  }

  const websiteJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: siteName,
    url: primaryDomain,
    inLanguage: 'en-IN',
    publisher: {
      '@type': 'Organization',
      name: siteName
    }
  }

  const serviceJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Service',
    serviceType: 'GST and TDS Compliance, Reconciliation, and Filing Automation',
    provider: {
      '@type': 'Organization',
      name: siteName,
      url: primaryDomain
    },
    areaServed: {
      '@type': 'Country',
      name: 'India'
    },
    description: defaultDescription,
    category: 'GST Filing, TDS Filing, Reconciliation, E-invoicing, E-way Bill, Vendor Validation, Compliance Automation'
  }

  const softwareApplicationJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'SoftwareApplication',
    name: siteName,
    applicationCategory: 'BusinessApplication',
    operatingSystem: 'Web',
    url: primaryDomain,
    description: defaultDescription,
    offers: {
      '@type': 'Offer',
      price: '0',
      priceCurrency: 'INR',
      availability: 'https://schema.org/InStock',
    },
    provider: {
      '@type': 'Organization',
      name: siteName,
      url: primaryDomain,
    },
    areaServed: {
      '@type': 'Country',
      name: 'India',
    },
  }

  return (
    <html lang="en-IN">
      <head>
        {/*
          STEP 1 — Consent default.
          Must be the very first script. Sets everything to denied.
          wait_for_update: 500 gives GtmConsentLoader's useEffect enough time
          to fire the update before GTM processes its tag queue.
        */}
        <script
          dangerouslySetInnerHTML={{
            __html: `
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag('consent', 'default', {
                'analytics_storage': 'denied',
                'ad_storage': 'denied',
                'ad_user_data': 'denied',
                'ad_personalization': 'denied',
                'wait_for_update': 500
              });
            `
          }}
        />
        {/*
          STEP 2 — GTM snippet (inline, not dynamic).
          Loads GTM immediately after the consent default is set.
          GTM will wait up to 500ms for a consent update before firing tags.
          GtmConsentLoader (in <body>) pushes the update via useEffect,
          which fires within that 500ms window on all normal connections.
        */}
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
              new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
              j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
              'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
              })(window,document,'script','dataLayer','${gtmId}');
            `
          }}
        />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=Outfit:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap"
          rel="stylesheet"
        />
        <link rel="alternate" hrefLang="en-IN" href={primaryDomain} />
        <link rel="alternate" hrefLang="x-default" href={primaryDomain} />
        <style id="ait-auth-styles" dangerouslySetInnerHTML={{ __html: authGlobalStyles }} />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationJsonLd) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteJsonLd) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(serviceJsonLd) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(softwareApplicationJsonLd) }}
        />
      </head>
      <body>
        {/*
          GtmConsentLoader no longer injects GTM — it only pushes consent
          update signals to the already-loaded GTM instance above.
        */}
        <GtmConsentLoader gtmId={gtmId} />
        <AnalyticsTracker />
        <CookieConsent />
        {children}
      </body>
    </html>
  )
}
