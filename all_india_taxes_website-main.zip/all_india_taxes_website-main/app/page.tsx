'use client'

import Nav from '@/components/Nav'
import Hero from '@/components/Hero'
import PainSection from '@/components/PainSection'
import HowItWorks from '@/components/HowItWorks'
import AISection from '@/components/AISection'
import DashboardShowcase from '@/components/DashboardShowcase'
import PersonaSection from '@/components/PersonaSection'
import MagicSection from '@/components/MagicSection'
import AITHubSection from '@/components/AITHubSection'
import PricingSection from '@/components/PricingSection'
import CompareSection from '@/components/CompareSection'
import CTASection from '@/components/CTASection'
import Footer from '@/components/Footer'
import { useEffect } from 'react'

export default function Home() {
  useEffect(() => {
    // Scroll reveal
    const ro = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (e.isIntersecting) {
          e.target.classList.add('visible')
          ro.unobserve(e.target)
        }
      })
    }, { threshold: 0.12 })
    document.querySelectorAll('.reveal').forEach(el => ro.observe(el))

    // Stat counters
    const so = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (e.isIntersecting) {
          const el = e.target as HTMLElement
          const target = parseFloat(el.dataset.target || '0')
          const isDecimal = String(target).includes('.')
          const start = performance.now()
          const dur = 2200
          const tick = (now: number) => {
            const p = Math.min((now - start) / dur, 1)
            const ease = 1 - Math.pow(1 - p, 4)
            const cur = target * ease
            el.textContent = isDecimal ? cur.toFixed(1) : Math.floor(cur).toLocaleString('en-IN')
            if (p < 1) requestAnimationFrame(tick)
            else el.textContent = isDecimal ? target.toFixed(1) : target.toLocaleString('en-IN')
          }
          requestAnimationFrame(tick)
          so.unobserve(el)
        }
      })
    }, { threshold: 0.5 })
    document.querySelectorAll('[data-target]').forEach(el => so.observe(el))

    return () => { ro.disconnect(); so.disconnect() }
  }, [])

  return (
    <>
      <Nav />
      <Hero />
      <PainSection />
      <HowItWorks />
      <AISection />
      <DashboardShowcase />
      <PersonaSection />
      <MagicSection />
      <AITHubSection />
      <PricingSection />
      <CompareSection />
      <CTASection />
      <Footer />
    </>
  )
}
