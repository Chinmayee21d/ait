import type { MetadataRoute } from 'next'

const primaryDomain = 'https://www.allindiataxes.com'

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: '*',
        allow: '/',
      },
    ],
    sitemap: `${primaryDomain}/sitemap.xml`,
    host: primaryDomain,
  }
}
