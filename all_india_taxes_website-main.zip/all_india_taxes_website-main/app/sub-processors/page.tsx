import { redirect } from 'next/navigation'

export default function SubProcessorsRedirectPage() {
  redirect('/legal/sub-processors')
}
