'use client'

import AITPitchDeckDownload from '@/design/AITPitchDeckDownload'

export default function PitchDeckPage() {
  return (
    <AITPitchDeckDownload
      deckUrl="/pitch_deck/AIT%20Compliance%20Infrastructure%20vF.pdf"
      onSuccess={() => {}}
    />
  )
}
