import type { Metadata } from 'next'
import DataRightsPortal from '@/components/DataRightsPortal'

export const metadata: Metadata = {
  title: 'Data Rights Portal',
  description: 'Submit privacy and data rights requests for access, export, correction, erasure, or grievance.',
  alternates: { canonical: '/data-rights' },
}

export default function DataRightsPage() {
  return <DataRightsPortal />
}
