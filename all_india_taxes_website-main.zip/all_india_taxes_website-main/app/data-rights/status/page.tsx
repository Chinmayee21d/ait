import type { Metadata } from 'next'
import DataRightsStatus from '@/components/DataRightsStatus'

export const metadata: Metadata = {
  title: 'Track Data Rights Request',
  description: 'Track the status of your privacy and data rights request using request ID and email.',
  alternates: { canonical: '/data-rights/status' },
}

export default function DataRightsStatusPage() {
  return <DataRightsStatus />
}
