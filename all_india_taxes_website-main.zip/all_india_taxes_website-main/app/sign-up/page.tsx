
'use client'

import { useEffect, useState } from 'react'
import AITSignUp from '@/design/AITSignUp'
import { useRouter } from 'next/navigation'

export default function SignUpPage() {
  const router = useRouter()
  const [redirectTarget, setRedirectTarget] = useState('')

  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const next = params.get('next') || ''

    const isSafeLocalPath = next.startsWith('/') && !next.startsWith('//')
    const isAllowedAbsoluteDemo = next.startsWith('https://apps.allindiataxes.com/demo/')

    if (isSafeLocalPath || isAllowedAbsoluteDemo) {
      setRedirectTarget(next)
    }
  }, [])

  return (
    <AITSignUp
      onSuccess={() => {
        if (!redirectTarget) return
        window.location.href = redirectTarget
      }}
      onSignInClick={() => router.push('/sign-in')}
    />
  )
}
