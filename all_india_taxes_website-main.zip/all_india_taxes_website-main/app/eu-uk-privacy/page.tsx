import { redirect } from 'next/navigation'

export default function EuUkPrivacyRedirectPage() {
  redirect('/legal/eu-uk-privacy')
}
