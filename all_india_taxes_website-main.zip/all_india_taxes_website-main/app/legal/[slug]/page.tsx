import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import LegalDocView from '@/components/LegalDocView'
import { LEGAL_DOCS, getLegalDocContent, getLegalDocMeta } from '@/lib/legal-docs'

type PageProps = {
  params: Promise<{ slug: string }>
}

export async function generateStaticParams() {
  return LEGAL_DOCS.map((doc) => ({ slug: doc.slug }))
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params
  const doc = getLegalDocMeta(slug)
  if (!doc) return {}
  return {
    title: doc.title,
    alternates: { canonical: `/legal/${doc.slug}` },
  }
}

export default async function LegalDocPage({ params }: PageProps) {
  const { slug } = await params
  const doc = await getLegalDocContent(slug)
  if (!doc) notFound()
  return <LegalDocView title={doc.meta.title} content={doc.content} />
}
