import Link from 'next/link'
import { LEGAL_DOCS } from '@/lib/legal-docs'

export default function LegalIndexPage() {
  return (
    <main className="legal-page">
      <div className="section-wrap legal-wrap">
        <div className="section-tag" style={{ justifyContent: 'center' }}>Legal</div>
        <h1 className="legal-title">Legal and Compliance</h1>
        <div className="legal-index">
          {LEGAL_DOCS.map((doc) => (
            <Link key={doc.slug} href={`/legal/${doc.slug}`} className="legal-index-link">
              {doc.title}
            </Link>
          ))}
        </div>
      </div>
    </main>
  )
}
