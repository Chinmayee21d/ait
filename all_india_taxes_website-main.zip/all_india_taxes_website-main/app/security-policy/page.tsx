import { redirect } from 'next/navigation'

export default function SecurityPolicyRedirectPage() {
  redirect('/legal/security-policy')
}
