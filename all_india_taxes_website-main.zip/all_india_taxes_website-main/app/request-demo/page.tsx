'use client'

import AITRequestDemo from '@/design/AITRequestDemo'
import { useRouter } from 'next/navigation'

export default function RequestDemoPage() {
  const router = useRouter()
  return (
    <AITRequestDemo
      onSuccess={() => {}}
      onSignInClick={() => router.push('/sign-in')}
    />
  )
}
