import { redirect } from 'next/navigation'

export default function AcceptableUseRedirectPage() {
  redirect('/legal/acceptable-use')
}
