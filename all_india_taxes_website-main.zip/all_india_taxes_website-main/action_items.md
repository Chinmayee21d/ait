# Action Items

## Legal and Security Operations

| Item | Owner | Due Date | Status | Notes |
|---|---|---|---|---|
| Create `legal@allindiataxes.com` mailbox | Founder Ops | 2026-03-10 | Pending | Must be monitored daily for notices, DPA, and regulatory correspondence. |
| Route `legal@` to legal counsel + founder escalation | Founder Ops | 2026-03-10 | Pending | Define backup owner and weekend coverage. |
| Create `security@allindiataxes.com` mailbox | Engineering Lead | 2026-03-10 | Pending | Required for vulnerability disclosure and breach communication intake. |
| Route `security@` to security incident channel and pager | Engineering Lead | 2026-03-10 | Pending | Include on-call + escalation matrix. |
| Publish mailbox ownership and escalation SOP | Compliance Owner | 2026-03-11 | Pending | Keep SOP in internal ops handbook and review quarterly. |

## Privacy SLA Workflow Maximums

| Workflow Step | Maximum Allowed Time | Owner | Status |
|---|---|---|---|
| Human acknowledgment of request | 48 hours | Privacy Desk | Active |
| First substantive update | 7 calendar days | Privacy Desk | Active |
| Final resolution (access/portability/correction/erasure/grievance) | 30 calendar days | Privacy Desk | Active |
| Marketing unsubscribe processing | 5 business days | Marketing Ops | Active |
