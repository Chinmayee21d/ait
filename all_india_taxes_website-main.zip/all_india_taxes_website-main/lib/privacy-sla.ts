export const PRIVACY_SLA = {
  humanAcknowledgementHours: 48,
  firstSubstantiveUpdateDays: 7,
  finalResolutionDays: 30,
  marketingUnsubscribeBusinessDays: 5,
} as const
