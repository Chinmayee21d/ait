const appBase = process.env.NEXT_PUBLIC_APP_BASE_URL || ''

// Default to local routes so links still work before the external app domain is ready.
export const APP_BASE_URL = appBase || '/sign-in'
export const APP_SIGNIN_URL = appBase ? `${appBase.replace(/\/$/, '')}/login` : '/sign-in'
export const APP_SIGNUP_URL = appBase ? `${appBase.replace(/\/$/, '')}/signup` : '/sign-up'

export const SALES_EMAIL = 'sales@allindiataxes.com'
export const INFO_EMAIL = 'info@allindiataxes.com'

export const BUSINESS_DEMO_URL = 'https://apps.allindiataxes.com/demo/business'
export const CA_DEMO_URL = 'https://apps.allindiataxes.com/demo/ca'
export const ENTERPRISE_DEMO_URL = BUSINESS_DEMO_URL

export type DemoRole = 'business' | 'enterprise' | 'ca'

export function normalizeDemoRole(value: string | null | undefined): DemoRole | null {
  const role = String(value || '').trim().toLowerCase()
  if (role === 'business' || role === 'enterprise' || role === 'ca') return role
  return null
}

export function getDemoUrlForRole(role: DemoRole): string {
  if (role === 'ca') return CA_DEMO_URL
  if (role === 'enterprise') return ENTERPRISE_DEMO_URL
  return BUSINESS_DEMO_URL
}

export function getSignUpUrlForDemoRole(role: DemoRole): string {
  const next = encodeURIComponent(getDemoUrlForRole(role))
  return `/sign-up?intent=view-demo&role=${encodeURIComponent(role)}&next=${next}`
}
