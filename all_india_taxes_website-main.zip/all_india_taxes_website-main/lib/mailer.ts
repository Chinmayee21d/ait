type SendMailInput = {
  to: string | string[]
  subject: string
  html: string
  text?: string
  replyTo?: string
  from?: string
}

export type SendMailResult = {
  ok: boolean
  status?: number
  error?: string
}

export async function sendMail(input: SendMailInput) {
  const apiKey = process.env.BREVO_API_KEY
  const from = input.from || process.env.EMAIL_FROM || 'Stawan Kamani <stawan@allindiataxes.com>'

  if (!apiKey) {
    console.warn('[mail] BREVO_API_KEY is missing. Email not sent.', { to: input.to, subject: input.subject })
    return { ok: false, error: 'BREVO_API_KEY is missing.' } satisfies SendMailResult
  }

  const fromMatch = from.match(/^(.*)<(.+)>$/)
  const sender = fromMatch
    ? { name: fromMatch[1].trim().replace(/^"|"$/g, ''), email: fromMatch[2].trim() }
    : { name: 'All India Taxes', email: from.trim() }

  const to = Array.isArray(input.to) ? input.to : [input.to]
  const res = await fetch('https://api.brevo.com/v3/smtp/email', {
    method: 'POST',
    headers: {
      'api-key': apiKey,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      sender,
      to: to.map((email) => ({ email })),
      subject: input.subject,
      htmlContent: input.html,
      textContent: input.text,
      replyTo: input.replyTo ? { email: input.replyTo } : undefined
    })
  })

  if (!res.ok) {
    const body = await res.text().catch(() => '')
    return {
      ok: false,
      status: res.status,
      error: body || `Email provider rejected request with status ${res.status}.`
    } satisfies SendMailResult
  }

  return { ok: true, status: res.status } satisfies SendMailResult
}
