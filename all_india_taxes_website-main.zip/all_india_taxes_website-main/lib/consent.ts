export type ConsentState = {
  essential: true
  analytics: boolean
  marketing: boolean
  ai_training: boolean
  updatedAt: string
  version: string
}

export const CONSENT_VERSION = '2026-03-07-v1'
export const CONSENT_STORAGE_KEY = 'ait_cookie_consent_v1'
export const CONSENT_EVENT_NAME = 'ait-consent-updated'

export function getDefaultConsent(): ConsentState {
  return {
    essential: true,
    analytics: false,
    marketing: false,
    ai_training: false,
    updatedAt: new Date().toISOString(),
    version: CONSENT_VERSION,
  }
}
