'use client'

import { CONSENT_EVENT_NAME, CONSENT_STORAGE_KEY, getDefaultConsent, type ConsentState } from '@/lib/consent'

export function readConsent(): ConsentState | null {
  if (typeof window === 'undefined') return null
  const raw = window.localStorage.getItem(CONSENT_STORAGE_KEY)
  if (!raw) return null
  try {
    const parsed = JSON.parse(raw) as ConsentState
    if (typeof parsed?.analytics !== 'boolean') return null
    if (typeof parsed?.marketing !== 'boolean') return null
    if (typeof parsed?.ai_training !== 'boolean') return null
    return {
      ...getDefaultConsent(),
      ...parsed,
      essential: true,
    }
  } catch {
    return null
  }
}

export function writeConsent(next: Omit<ConsentState, 'updatedAt' | 'version' | 'essential'> & { updatedAt?: string; version?: string }) {
  if (typeof window === 'undefined') return
  const payload: ConsentState = {
    essential: true,
    analytics: Boolean(next.analytics),
    marketing: Boolean(next.marketing),
    ai_training: Boolean(next.ai_training),
    updatedAt: next.updatedAt || new Date().toISOString(),
    version: next.version || getDefaultConsent().version,
  }
  window.localStorage.setItem(CONSENT_STORAGE_KEY, JSON.stringify(payload))
  window.dispatchEvent(new CustomEvent(CONSENT_EVENT_NAME, { detail: payload }))
}
