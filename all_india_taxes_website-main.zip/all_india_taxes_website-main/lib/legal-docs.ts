import legalDocsContent from '@/lib/legal-docs-content.json'

export type LegalDocSlug =
  | 'privacy'
  | 'terms'
  | 'cookie-policy'
  | 'dpa'
  | 'acceptable-use'
  | 'security-policy'
  | 'dpdp'
  | 'eu-uk-privacy'
  | 'sub-processors'

export type LegalDocMeta = {
  slug: LegalDocSlug
  title: string
  file: string
}

export const LEGAL_DOCS: LegalDocMeta[] = [
  { slug: 'privacy', title: 'Privacy Policy', file: '01_privacy_policy.md' },
  { slug: 'terms', title: 'Terms of Service', file: '02_terms_of_service.md' },
  { slug: 'cookie-policy', title: 'Cookie Policy', file: '04_cookie_policy.md' },
  { slug: 'dpa', title: 'Data Processing Agreement', file: '03_data_processing_agreement.md' },
  { slug: 'acceptable-use', title: 'Acceptable Use Policy', file: '05_acceptable_use_policy.md' },
  { slug: 'security-policy', title: 'Security Policy', file: '06_security_policy.md' },
  { slug: 'dpdp', title: 'DPDP Compliance Statement', file: '07_dpdp_compliance_statement.md' },
  { slug: 'eu-uk-privacy', title: 'EU/UK Privacy Notice', file: '08_eu_uk_privacy_notice.md' },
  { slug: 'sub-processors', title: 'Sub-Processors and AI Transparency', file: '09_sub_processors_ai_transparency.md' },
]

export function getLegalDocMeta(slug: string): LegalDocMeta | null {
  return LEGAL_DOCS.find((doc) => doc.slug === slug) ?? null
}

export async function getLegalDocContent(slug: string): Promise<{ meta: LegalDocMeta; content: string } | null> {
  const meta = getLegalDocMeta(slug)
  if (!meta) return null
  const content = legalDocsContent[meta.file as keyof typeof legalDocsContent]
  if (!content) return null
  return { meta, content }
}
