import { mkdir, readFile, writeFile } from 'fs/promises'
import path from 'path'

export type PrivacyRequestType = 'access' | 'portability' | 'correction' | 'erasure' | 'grievance'
export type PrivacyRequestStatus = 'submitted' | 'in_review' | 'completed' | 'rejected'

export type PrivacyRequestRecord = {
  requestId: string
  requestType: PrivacyRequestType
  fullName: string
  email: string
  accountEmail: string
  company: string
  jurisdiction: string
  details: string
  status: PrivacyRequestStatus
  createdAt: string
  updatedAt: string
  adminNote?: string
}

const dataDir = path.join(process.cwd(), 'data')
const dataFile = path.join(dataDir, 'privacy-requests.json')

async function readAll(): Promise<PrivacyRequestRecord[]> {
  try {
    const raw = await readFile(dataFile, 'utf8')
    const parsed = JSON.parse(raw)
    return Array.isArray(parsed) ? parsed : []
  } catch {
    return []
  }
}

async function writeAll(items: PrivacyRequestRecord[]) {
  await mkdir(dataDir, { recursive: true })
  await writeFile(dataFile, JSON.stringify(items, null, 2), 'utf8')
}

export async function savePrivacyRequest(record: PrivacyRequestRecord) {
  const all = await readAll()
  all.unshift(record)
  await writeAll(all.slice(0, 5000))
}

export async function findPrivacyRequest(requestId: string) {
  const all = await readAll()
  return all.find((item) => item.requestId === requestId) || null
}

export async function listPrivacyRequests() {
  return readAll()
}

export async function updatePrivacyRequestStatus(
  requestId: string,
  nextStatus: PrivacyRequestStatus,
  adminNote: string
) {
  const all = await readAll()
  const idx = all.findIndex((item) => item.requestId === requestId)
  if (idx < 0) return null
  const current = all[idx]
  const updated: PrivacyRequestRecord = {
    ...current,
    status: nextStatus,
    adminNote: adminNote || current.adminNote || '',
    updatedAt: new Date().toISOString(),
  }
  all[idx] = updated
  await writeAll(all)
  return updated
}
