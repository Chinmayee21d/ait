import { createHmac, timingSafeEqual } from 'crypto'

export type Purpose = 'demo' | 'view_demo' | 'request_demo' | 'pitch' | 'signin' | 'signup'

type OtpEntry = {
  code: string
  expiresAt: number
  sentAt: number
}

const TTL_MS = 10 * 60 * 1000
const RESEND_COOLDOWN_MS = 45 * 1000

// Keep OTP state in-memory for the current worker/process lifecycle.
// This is sufficient for simple gating flows, but not durable across restarts.
const globalStore = globalThis as unknown as { __aitOtpStore?: Map<string, OtpEntry> }
const store = globalStore.__aitOtpStore || new Map<string, OtpEntry>()
globalStore.__aitOtpStore = store

function key(email: string, purpose: Purpose) {
  // Namespacing by purpose avoids OTP collisions between parallel flows.
  return `${purpose}:${email.toLowerCase()}`
}

export function canSendOtp(email: string, purpose: Purpose) {
  const existing = store.get(key(email, purpose))
  if (!existing) return true
  return Date.now() - existing.sentAt > RESEND_COOLDOWN_MS
}

export function setOtp(email: string, purpose: Purpose, code: string) {
  store.set(key(email, purpose), {
    code,
    expiresAt: Date.now() + TTL_MS,
    sentAt: Date.now()
  })
}

export function verifyOtp(email: string, purpose: Purpose, code: string) {
  const k = key(email, purpose)
  const existing = store.get(k)
  if (!existing) return false
  if (Date.now() > existing.expiresAt) {
    // Remove expired entries eagerly to keep the store small.
    store.delete(k)
    return false
  }
  const ok = existing.code === code
  // One-time semantics: consume OTP on success.
  if (ok) store.delete(k)
  return ok
}

function base64UrlEncode(input: string) {
  return Buffer.from(input, 'utf8')
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/g, '')
}

function base64UrlDecode(input: string) {
  const padded = input + '==='.slice((input.length + 3) % 4)
  const base64 = padded.replace(/-/g, '+').replace(/_/g, '/')
  return Buffer.from(base64, 'base64').toString('utf8')
}

function sign(payloadB64: string) {
  const secret = process.env.OTP_TOKEN_SECRET
  if (!secret) return ''
  return createHmac('sha256', secret).update(payloadB64).digest('base64url')
}

export function getOtpCookieName(purpose: Purpose) {
  return `ait_otp_${purpose}`
}

export function createOtpToken(email: string, purpose: Purpose, code: string) {
  const secret = process.env.OTP_TOKEN_SECRET
  if (!secret) return null
  const payload = {
    e: email.toLowerCase(),
    p: purpose,
    c: code,
    exp: Date.now() + TTL_MS
  }
  const payloadB64 = base64UrlEncode(JSON.stringify(payload))
  const sig = sign(payloadB64)
  if (!sig) return null
  return `${payloadB64}.${sig}`
}

export function verifyOtpToken(token: string, email: string, purpose: Purpose, code: string) {
  const secret = process.env.OTP_TOKEN_SECRET
  if (!secret) return false
  const [payloadB64, signature] = token.split('.')
  if (!payloadB64 || !signature) return false
  const expected = sign(payloadB64)
  if (!expected) return false

  const sigA = Buffer.from(signature)
  const sigB = Buffer.from(expected)
  if (sigA.length !== sigB.length || !timingSafeEqual(sigA, sigB)) return false

  let payload: { e: string; p: Purpose; c: string; exp: number }
  try {
    payload = JSON.parse(base64UrlDecode(payloadB64))
  } catch {
    return false
  }

  if (Date.now() > payload.exp) return false
  if (payload.e !== email.toLowerCase()) return false
  if (payload.p !== purpose) return false
  if (payload.c !== code) return false
  return true
}
