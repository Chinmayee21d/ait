export type AnalyticsPayload = Record<string, string | number | boolean | null | undefined>

declare global {
  interface Window {
    dataLayer?: Array<Record<string, unknown>>
  }
}

/**
 * Push a custom event onto dataLayer.
 * Always checks localStorage for analytics consent before pushing —
 * this is a belt-and-braces check on top of GTM's own consent mode.
 * Does not depend on NEXT_PUBLIC_REQUIRE_ANALYTICS_CONSENT env var,
 * which was previously causing events to be silently dropped when unset.
 */
export function pushAnalyticsEvent(event: string, payload: AnalyticsPayload = {}) {
  if (typeof window === 'undefined') return

  try {
    const raw = window.localStorage.getItem('ait_cookie_consent_v1')
    if (!raw) return // No consent record — user hasn't seen banner yet
    const consent = JSON.parse(raw) as { analytics?: boolean }
    if (!consent.analytics) return // User declined analytics
  } catch {
    return
  }

  window.dataLayer = window.dataLayer || []
  window.dataLayer.push({ event, ...payload })
}
