# All India Taxes (AIT) — Next.js Website

## Setup & Run all

### Prerequisites
- Node.js 18+ 
- npm or yarn

### Installation

```bash
# Install dependencies
npm install

# Run development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### Build for Production

```bash
npm run build
npm start
```

## Project Structure

```
ait-website/
├── app/
│   ├── globals.css      # All global styles
│   ├── layout.tsx       # Root layout (fonts, metadata)
│   └── page.tsx         # Main page (orchestrates all sections)
├── components/
│   ├── Nav.tsx          # Navigation bar
│   ├── Hero.tsx         # Hero section with chat UI
│   ├── PainSection.tsx  # Problem statement
│   ├── HowItWorks.tsx   # 5-step process flow
│   ├── AISection.tsx    # AI Intelligence features
│   ├── PersonaSection.tsx # Who it's for
│   ├── MagicSection.tsx # Vendor Magic Link
│   ├── NetworkSection.tsx # Network canvas animation
│   ├── PricingSection.tsx # Pricing tabs
│   ├── CompareSection.tsx # Comparison table
│   ├── CTASection.tsx   # Call to action
│   └── Footer.tsx       # Footer
├── package.json
├── next.config.js
└── tsconfig.json
```

## Tech Stack

- **Next.js 14** (App Router)
- **TypeScript**
- **CSS** (global CSS, no Tailwind required)
- Google Fonts: DM Serif Display, Outfit, JetBrains Mono

## Features Converted from HTML

- ✅ Animated hero grid background
- ✅ Floating orb animations
- ✅ Hero AI chat card UI
- ✅ Floating alert/success cards
- ✅ Animated stat counters (IntersectionObserver)
- ✅ Scroll reveal animations
- ✅ Network canvas animation (Canvas API)
- ✅ Pricing tab switcher (React state)
- ✅ Fully responsive design
- ✅ All sections: Pain, How It Works, AI, Personas, Magic Link, Network, Pricing, Compare, CTA, Footer

## OTP Email Delivery (Production)

OTP emails use Resend via `app/api/otp/send` and `app/api/otp/verify`.

### Required environment variables

Set these in your deployment environment (Cloudflare Worker/Pages variables and local `.env.local`):

```bash
BREVO_API_KEY=re_xxxxx
EMAIL_FROM="Stawan Kamani <stawan@allindiataxes.com>"
```

### Domain and sender requirements

To send from `stawan@allindiataxes.com`, the sending domain must be verified in Resend:

1. Add `allindiataxes.com` in Brevo Senders & Domains.
2. Add the DNS records Resend provides (SPF/DKIM/verification).
3. Wait for domain status to become `Verified`.
4. Use `EMAIL_FROM` exactly as above.

If these are not configured, OTP APIs now return an error instead of silently succeeding.

## OTP + Sender Configuration (Brevo)

Set these in Cloudflare and local `.env`:

```bash
BREVO_API_KEY=xkeysib-...
OTP_TOKEN_SECRET=use-a-long-random-secret-32-plus-chars
EMAIL_FROM_OTP="AIT Information Team <info@allindiataxes.com>"
EMAIL_FROM_CEO="Stawan Kamani <stawan@allindiataxes.com>"
```

Notes:
- OTP emails are sent from `EMAIL_FROM_OTP`.
- Thank-you acknowledgement emails are sent from `EMAIL_FROM_CEO`.
- OTP verification now uses a signed cookie token, so it works across serverless instances.
